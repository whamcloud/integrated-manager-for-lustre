'use strict';

var a = 'a';
