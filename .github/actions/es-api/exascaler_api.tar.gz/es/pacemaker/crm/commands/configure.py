# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing 'crm configure' command.
"""


from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand
from es.pacemaker.crm.commands.crm_command_parser import CrmParser

COMMAND = 'crm configure %(subcmd)s'


class CrmConfigureExecutor(CmdExecutor):
    """ Class for 'crm configure <subcmd>' command execution.
    """

    def __init__(self, command):
        """ Command output parser initialization.
        """

        super(CrmConfigureExecutor, self).__init__(command, CrmParser)

    def execute_command(self, subcmd):
        """ 'crm configure <subcmd>' command execution.
        :param subcmd: crm configure subcommand.
        """

        args = dict(subcmd=subcmd)

        return CmdExecutor.execute(self, args=args)


_crm_configure_executor = CrmConfigureExecutor(StringCommand(COMMAND))


def crm_configure_cib_object(cib_object):
    """ Run 'crm configure <cib_object>' command.
    :param cib_object: CIB object
    """

    return _crm_configure_executor.execute_command(str(cib_object))


def crm_configure_verify():
    """ Run 'crm configure verify' command.
    """

    return _crm_configure_executor.execute_command('verify')


def crm_configure_load_update_cib(cib):
    """ Run 'crm configure load ' command.
    :param cib: CIB file name
    """

    subcmd = 'load update {0}'.format(cib)
    return _crm_configure_executor.execute_command(subcmd)
