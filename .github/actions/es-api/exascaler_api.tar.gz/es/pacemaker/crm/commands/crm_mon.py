# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing 'crm_mon' command.
"""


from scalers.utils.cmd import CmdExecutor, CmdOutputParser
from scalers.utils.command import StringCommand
from lxml import etree


COMMAND = 'crm_mon --inactive -c --as-xml'


class CrmMonParser(CmdOutputParser):
    """ Class for parsing 'crm_mon --inactive -c --as-xml' commands output.
    """

    @staticmethod
    def _parse_summary(summary_directive):
        """ Parse summary directive.
        """

        result = dict()
        for directive in list(summary_directive):
            result[directive.tag] = dict(directive.items())
        return result

    @staticmethod
    def _parse_nodes(nodes_directive):
        """ Parse nodes directive.
        """

        return [dict(node_directive.items()) for node_directive in nodes_directive.findall('node')]

    @staticmethod
    def _parse_node_attributes(node_attributes_directive):
        """ Parse node attributes directive.
        """

        result = dict()
        for node_attribute_directive in node_attributes_directive.findall('node'):
            result[node_attribute_directive.get('name')] = [dict(attribute_directive.items()) for attribute_directive
                                                            in node_attribute_directive.findall('attribute')]
        return result

    @staticmethod
    def _parse_node_history(node_history_directive):
        """ Parse node history directive.
        """

        nodes = dict()

        for node_attribute_directive in node_history_directive.findall('node'):

            node_name = node_attribute_directive.get('name')

            resource_history = list()

            for item in node_attribute_directive.findall('resource_history'):

                resource_history_item = dict(item.items())
                resource_history_item['operation_history'] = \
                    [dict(operation_item.items()) for operation_item in item.findall('operation_history')]

                resource_history.append(resource_history_item)

            nodes[node_name] = resource_history

        return nodes

    @staticmethod
    def _parse_resources(resources_directive):
        """ Parse resources directive.
        """

        main_resources = list()
        for resource_directive in resources_directive.findall('resource'):
            resource = dict(resource_directive.items())
            resource['nodes'] = [dict(node_directive.items()) for node_directive in resource_directive.findall('node')]
            main_resources.append(resource)

        clones = list()
        for clone_directive in resources_directive.findall('clone'):

            clone = dict(clone_directive.items())

            resources = list()
            for resource_directive in clone_directive.findall('resource'):
                resource = dict(resource_directive.items())
                resource['nodes'] = [dict(node_directive.items()) for
                                     node_directive in resource_directive.findall('node')]
                resources.append(resource)

            clone['resources'] = resources
            clones.append(clone)

        return main_resources, clones

    @staticmethod
    def _parse_bans(bans_directive):
        """ Parse bans directive.
        """

        return [dict(node_directive.items()) for node_directive in bans_directive.findall('ban')]

    @staticmethod
    def _parse_tickets(tickets_directive):
        """ Parse tickets directive.
        """

        return [dict(ticket_directive.items()) for ticket_directive in tickets_directive.findall('ticket')]

    @staticmethod
    def _parse_failures(failures_directive):
        """ Parse bans directive.
        """

        if failures_directive is None:
            return list()

        return [dict(failure_directive.items()) for failure_directive in failures_directive.findall('failure')]

    def _parse(self, output):
        """ Parse 'crm_mon --inactive -c --as-xml' command output.
        """

        root = etree.fromstringlist(output.splitlines())

        result = dict()

        summary_directive = root.find('summary')
        result['summary'] = self._parse_summary(summary_directive)

        nodes_directive = root.find('nodes')
        nodes = self._parse_nodes(nodes_directive)

        node_attributes_directive = root.find('node_attributes')
        node_attributes = self._parse_node_attributes(node_attributes_directive)

        node_history_directive = root.find('node_history')
        node_history = self._parse_node_history(node_history_directive)

        for node in nodes:
            node_name = node['name']
            if node_name in node_attributes:
                node['attributes'] = node_attributes[node_name]
            if node_name in node_history:
                node['history'] = node_history[node_name]

        result['nodes'] = nodes

        bans_directive = root.find('bans')
        result['bans'] = self._parse_bans(bans_directive)

        failures_directive = root.find('failures')
        result['failures'] = self._parse_failures(failures_directive)

        tickets_directive = root.find('tickets')
        result['tickets'] = self._parse_tickets(tickets_directive)

        resources_directive = root.find('resources')
        result['resources'], result['clones'] = self._parse_resources(resources_directive)

        return result


class CrmMonExecutor(CmdExecutor):
    """ Class for 'crm_mon --as-xml' command execution.
    """

    def __init__(self, command):
        """ Command output parser initialization.
        """

        super(CrmMonExecutor, self).__init__(command, CrmMonParser)


_crm_mon_executor = CrmMonExecutor(StringCommand(COMMAND))


def crm_mon(host_to_run=None):
    """ Run 'crm_mon --as-xml' command.
    """

    return _crm_mon_executor.execute(node=host_to_run)
