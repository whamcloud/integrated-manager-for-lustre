# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing 'crm cib' command.
"""


from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand
from es.pacemaker.crm.commands.crm_command_parser import CrmParser

COMMAND = 'crm cib %(subcmd)s'


class CrmCibExecutor(CmdExecutor):
    """ Class for 'crm cib <subcmd>' command execution.
    """

    def __init__(self, command):
        """ Command output parser initialization.
        """

        super(CrmCibExecutor, self).__init__(command, CrmParser)

    def execute_command(self, subcmd):
        """ 'crm cib <subcmd>' command execution.
        :param subcmd: crm cib subcommand.
        """

        args = dict(subcmd=subcmd)

        return CmdExecutor.execute(self, args=args)


_crm_cib_executor = CrmCibExecutor(StringCommand(COMMAND))


def crm_cib_new(cib_name):
    """ Run 'crm cib new <cib_name>' command.
    :param cib_name: CIB name
    """

    subcmd = 'new {0}'.format(cib_name)
    return _crm_cib_executor.execute_command(subcmd)


def crm_cib_commit(cib_name):
    """ Run 'crm cib commit <cib_name>' command.
    :param cib_name: CIB name
    """

    subcmd = 'commit {0}'.format(cib_name)
    return _crm_cib_executor.execute_command(subcmd)


def crm_cib_delete(cib_name):
    """ Run 'crm cib delete <cib_name>' command.
    :param cib_name: CIB name
    """

    subcmd = 'delete {0}'.format(cib_name)
    return _crm_cib_executor.execute_command(subcmd)


def crm_cib_list():
    """ Run 'crm cib list' command.
    """

    return _crm_cib_executor.execute_command('list')
