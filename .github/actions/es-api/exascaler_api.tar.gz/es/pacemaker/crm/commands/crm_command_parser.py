# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************


""" Functionality for parsing crm shell commands.
"""

from scalers.errors import ScalersCommandError
from scalers.utils.cmd import CmdOutputParser
from scalers.utils.command import CommandResult


class CrmParser(CmdOutputParser):
    """ Class for parsing crm commands output.
    """

    def _parse(self, output):
        """ Parse crm command output.
        """

        lines = output.split('\n')
        for line in lines:
            if line.startswith('ERROR:'):
                result = CommandResult(self.cmd, stdout=output)
                raise ScalersCommandError('Command failed', result)

        return output
