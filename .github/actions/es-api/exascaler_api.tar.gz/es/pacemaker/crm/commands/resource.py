# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing 'crm cib' command.
"""


from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand
from es.pacemaker.crm.commands.crm_command_parser import CrmParser

COMMAND = 'crm resource %(subcmd)s'


class CrmResourceExecutor(CmdExecutor):
    """ Class for 'crm resource <subcmd>' command execution.
    """

    def __init__(self, command):
        """ Command output parser initialization.
        """

        super(CrmResourceExecutor, self).__init__(command, CrmParser)

    def execute_command(self, subcmd, node_to_execute=None):
        """ 'crm resource <subcmd>' command execution.
        :param node_to_execute: node to execute
        :param subcmd: crm resource subcommand.
        """

        args = dict(subcmd=subcmd)

        return CmdExecutor.execute(self, args=args, node=node_to_execute)


_crm_resource_executor = CrmResourceExecutor(StringCommand(COMMAND))


def cleanup(resource, node=None, node_to_execute=None):
    """ Run 'cleanup <rsc> [<node>]' command.
    :param resource: resource
    :param node_to_execute: node to execute
    :param node: node
    """

    if node is None:
        subcmd = 'cleanup {0}'.format(resource)
        return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)
    else:
        subcmd = 'cleanup {0} {1}'.format(resource, node)
        return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)


def demote(resource, node_to_execute=None):
    """ Run 'demote <rsc>' command.
    :param node_to_execute: node to execute
    :param resource: resource
    """

    subcmd = 'demote {0}'.format(resource)
    return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)


def manage(resource, node_to_execute=None):
    """ Run 'manage <rsc>' command.
    :param node_to_execute: node to execute
    :param resource: resource
    """

    subcmd = 'manage {0}'.format(resource)
    return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)


def unmanage(resource, node_to_execute=None):
    """ Run 'unmanage <rsc>' command.
    :param node_to_execute: node to execute
    :param resource: resource
    """

    subcmd = 'unmanage {0}'.format(resource)
    return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)


def start(resource, node_to_execute=None):
    """ Run 'start <rsc>' command.
    :param node_to_execute: node to execute
    :param resource: resource
    """

    subcmd = 'start {0}'.format(resource)
    return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)


def restart(resource, node_to_execute=None):
    """ Run 'restart <rsc>' command.
    :param node_to_execute: node to execute
    :param resource: resource
    """

    subcmd = 'restart {0}'.format(resource)
    return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)


def stop(resource, node_to_execute=None):
    """ Run 'stop <rsc>' command.
    :param node_to_execute: node to execute
    :param resource: resource
    """

    subcmd = 'stop {0}'.format(resource)
    return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)


def status(resource, node_to_execute=None):
    """ Run 'status <rsc>' command.
    :param node_to_execute: node to execute
    :param resource: resource
    """

    subcmd = 'status {0}'.format(resource)
    return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)


def reprobe(resource, node_to_execute=None):
    """ Run 'reprobe <rsc>' command.
    :param node_to_execute: node to execute
    :param resource: resource
    """

    subcmd = 'reprobe {0}'.format(resource)
    return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)


def unmigrate(resource, node_to_execute=None):
    """ Run 'unmigrate  <rsc>' command.
    :param node_to_execute: node to execute
    :param resource: resource
    """

    subcmd = 'unmigrate {0}'.format(resource)
    return _crm_resource_executor.execute_command(subcmd, node_to_execute=node_to_execute)
