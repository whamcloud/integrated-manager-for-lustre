# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for ms description.
"""

from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm.entities.common.attributes import TaggedAttributesListWithId
from es.pacemaker.crm.entities.common.description import Description
from scalers.errors import ScalersException


class Ms(CrmObject):
    """ Ms entity.
    """

    def __init__(self, name, resource):
        """ Basic initialization.
        """

        self.name = name
        self.resource = resource
        self.description = None
        self._meta = TaggedAttributesListWithId('meta')
        self._params = TaggedAttributesListWithId('params')

    @property
    def meta(self):
        """ Get meta.
        """

        return self._meta

    @property
    def params(self):
        """ Get params.
        """

        return self._params

    def _verify(self):
        """ Verify object.
        """

        if self.name is None:
            raise ScalersException('Name is missed in ms description.')

        if self.resource is None:
            raise ScalersException('Resource is missed in ms description.')

    def __str__(self):
        """ String representation.
        """

        self._verify()

        return ' '.join(filter(None, [
            'ms',
            self.name,
            self.resource,
            None if self.description is None else str(Description(self.description)),
            str(self._meta) if self._meta.is_content_present() else None,
            str(self._params) if self._params.is_content_present() else None,
        ]))
