# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for rule description.
"""


from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm.entities.common.id import Id
from es.pacemaker.crm.entities.common.score import Score
from scalers.errors import ScalersException


class Expression(CrmObject):
    """ Expression entity.
    """

    _VALUE_TYPE_EMPTY = 0
    _VALUE_TYPE_SIMPLE_EXPRESSION = 1
    _VALUE_TYPE_BOOL_OPERATOR = 2

    def __init__(self):
        """ Basic initialization.
        """

        self._parts = list()
        self._last_value_type = self._VALUE_TYPE_EMPTY

    def add_simple_expression(self, expression):
        """ Add simple expression.
        @type expression: SimpleExpression
        """

        if not isinstance(expression, SimpleExpression):
            raise ScalersException('Simple expression should be an instance of SimpleExpression class.')

        if self._last_value_type != self._VALUE_TYPE_SIMPLE_EXPRESSION:
            self._parts.append(expression)
            self._last_value_type = self._VALUE_TYPE_SIMPLE_EXPRESSION
        else:
            raise ScalersException('Simple expression could be added only as the first part or after bool operator.')

    def add_bool_operator(self, bool_operator):
        """ Add bool operator.
        @type bool_operator: str
        """

        possible_values = ('or', 'and', )

        if bool_operator not in possible_values:
            raise ScalersException("Incorrect bool operator '{0}'. Possible values are: {1}".format(
                bool_operator,
                ' '.join(possible_values),
            ))

        if self._last_value_type in (self._VALUE_TYPE_EMPTY, self._VALUE_TYPE_BOOL_OPERATOR, ):
            raise ScalersException('Bool operator could be added only after simple expression.')

        self._parts.append(bool_operator)
        self._last_value_type = self._VALUE_TYPE_BOOL_OPERATOR

    def _verify(self):
        """ Verify object.
        """

        if self._last_value_type == self._VALUE_TYPE_BOOL_OPERATOR:
            raise ScalersException('Bool operator could not be the last part.')

        if self._last_value_type == self._VALUE_TYPE_EMPTY:
            raise ScalersException('Expression could not be empty.')

    def __str__(self):
        """ String representation.
        """

        self._verify()

        return ' '.join([str(part) for part in self._parts])


class SimpleExpression(CrmObject):
    """ Base class for simple expressions.
    """

    pass


class SimpleExpressionBinary(SimpleExpression):
    """ Simple expression with binary operation.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self.attribute = None
        self.type = None
        self.binary_op = None
        self.value = None

    def _verify(self):
        """ Verify object.
        """

        if self.attribute is None:
            raise ScalersException('Attribute is missed in simple expression.')

        if self.value is None:
            raise ScalersException('Value is missed in simple expression.')

        if self.binary_op is None:
            raise ScalersException('Binary operator is missed in simple expression.')

        possible_values = ('lt', 'gt', 'lte', 'gte', 'eq', 'ne', )
        if self.binary_op not in possible_values:
            raise ScalersException("Incorrect binary operator '{0}' in simple expression. Possible values are: {1}.".
                                   format(self.binary_op, ' '.join(possible_values)))

        possible_values = ('string', 'version', 'number', )
        if (self.type is not None) and (self.type not in possible_values):
            raise ScalersException("Incorrect type '{0}' in simple expression. Possible values are: {1}.".format(
                self.type,
                ' '.join(possible_values),
            ))

    def __str__(self):
        """ String representation.
        """

        self._verify()

        return ' '.join(filter(None, [
            self.attribute,
            self.binary_op if self.type is None else '{0}:{1}'.format(self.type, self.binary_op),
            self.value,
        ]))


class SimpleExpressionUnary(SimpleExpression):
    """ Simple expression with unary operation.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self.unary_op = None
        self.attribute = None

    def _verify(self):
        """ Verify object.
        """

        if self.attribute is None:
            raise ScalersException('Attribute is missed in simple expression.')

        if self.unary_op is None:
            raise ScalersException('Unary operator is missed in simple expression.')

        possible_values = ('defined', 'not_defined', )
        if self.unary_op not in possible_values:
            raise ScalersException("Incorrect unary operator in simple expression. Possible values are: {1}.".format(
                self.unary_op,
                ' '.join(possible_values),
            ))

    def __str__(self):
        """ String representation.
        """

        self._verify()

        return ' '.join([self.unary_op, str(self.attribute)])


class SimpleExpressionDate(SimpleExpression):
    """ Simple expression with date.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self._value = None

    def date_lt(self, end):
        """ Set date less than.
        :param end: end date
        """

        self._value = 'lt {0}'.format(str(end))

    def date_gt(self, start):
        """ Set date grater than.
        :param start: start date
        """

        self._value = 'gt {0}'.format(str(start))

    def date_start_end(self, start, end):
        """ Set period by start and end dates.
        :param start: start date
        :param end: end date
        """

        self._value = 'in start={0} end={1}'.format(str(start), str(end))

    def date_start_duration(self, start, duration_type, duration_value):
        """ Set period by start date and duration.
        :param start: start date
        :param duration_type: duration type
        :param duration_value: duration value
        """

        possible_values = ('hours', 'monthdays', 'weekdays', 'yearsdays', 'months', 'weeks',
                           'years', 'weekyears', 'moon', )
        if duration_type not in possible_values:
            raise ScalersException("Incorrect duration type '{0}' in simple expression. Possible values are: {1}.".
                                   format(duration_type, ' '.join(possible_values)))

        self._value = 'in start={0} {1}={2}'.format(str(start), str(duration_type), str(duration_value))

    def date_spec(self, spec_type, spec_value):
        """ Set date spec.
        :param spec_type: spec type
        :param spec_value: spec value
        """

        possible_values = ('hours', 'monthdays', 'weekdays', 'yearsdays', 'months', 'weeks',
                           'years', 'weekyears', 'moon', )
        if spec_type not in possible_values:
            raise ScalersException("Incorrect spec type '{0}' in simple expression. Possible values are: {1}.".
                                   format(spec_type, ' '.join(possible_values)))

        self._value = 'spec {0}={1}'.format(str(spec_type), str(spec_value))

    def __str__(self):
        """ String representation.
        """

        if self._value is None:
            raise ScalersException('Simple expression with date could not be empty.')

        return self._value


class Rule(CrmObject):
    """ Rule entity.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self.id = None
        self.score = None
        self.role = None
        self._expression = Expression()

    @property
    def expression(self):
        """ Get expression.
        """

        return self._expression

    def __str__(self):
        """ String representation.
        """

        return ' '.join(filter(None, [
            'rule',
            None if self.id is None else str(Id(self.id)),
            None if self.role is None else '$role={0}'.format(str(self.role)),
            None if self.score is None else str(Score(self.score)),
            str(self._expression),
        ]))
