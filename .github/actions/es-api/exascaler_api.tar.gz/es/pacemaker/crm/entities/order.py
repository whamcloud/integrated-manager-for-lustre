# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for order description.
"""


from es.pacemaker.crm.entities.common import CrmObject
from scalers.errors import ScalersException

from collections import OrderedDict


class Order(CrmObject):
    """ Order entity.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self.id = None

        self.kind = None
        self.score = None

        self._resources = OrderedDict()
        self.symmetrical = None

    def add_resource(self, res, action=None):
        """ Add resource with action(optional).
        :param res: resource
        :param action: appropriate action(optional)
        """

        self._resources[res] = action

    def _verify(self):
        """ Verify object.
        """

        if self.id is None:
            raise ScalersException('Id is missed in order description.')

        if len(self._resources) < 2:
            raise ScalersException('At least two resources should be specified in order description.')

        possible_values = ('Mandatory', 'Optional', 'Serialize', )
        if (self.kind is not None) and (self.kind not in possible_values):
            raise ScalersException("Incorrect kind value '{0}' in order description. Possible values are: {1}".format(
                self.kind,
                ','.join(possible_values),
            ))

        if (self.kind is not None) and (self.score is not None):
            raise ScalersException('Kind and score are mutually exclusive in order description.')

    def __str__(self):
        """ String representation.
        """

        self._verify()

        return ' '.join(filter(None, [
            'order',
            self.id,
            None if self.kind is None else '{0}:'.format(str(self.kind)),
            None if self.score is None else '{0}:'.format(str(self.score)),
            ' '.join([str(key) if value is None else '{0}:{1}'.format(str(key), str(value))
                      for (key, value) in self._resources.items()]),
            None if self.symmetrical is None else 'symmetrical={0}'.format(str(self.symmetrical))
        ]))
