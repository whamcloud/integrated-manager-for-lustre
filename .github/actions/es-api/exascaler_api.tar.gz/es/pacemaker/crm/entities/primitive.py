# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for primitive representation.
"""

from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm.entities.common.attributes import (
    AttributesList,
    TaggedAttributesListWithMetaAndRules,
)
from es.pacemaker.crm.entities.common.description import Description
from es.pacemaker.crm.entities.common.template import Template
from scalers.errors import ScalersException

OP_TYPE_START = 'start'
OP_TYPE_STOP = 'stop'
OP_TYPE_MONITOR = 'monitor'
OP_TYPE_PROMOTE = 'promote'
OP_TYPE_DEMOTE = 'demote'
OP_TYPES = (OP_TYPE_START, OP_TYPE_STOP, OP_TYPE_MONITOR, OP_TYPE_PROMOTE, OP_TYPE_DEMOTE, )


class Op(AttributesList):
    """ Op entity.
    """

    def __init__(self, op_type):
        """ Basic initialization.
        """

        super(Op, self).__init__()

        self.type = op_type

    def __str__(self):
        """ String representation.
        """

        return ' '.join(filter(None, [
            'op',
            self.type,
            super(Op, self).__str__(),
        ]))


class Primitive(CrmObject):
    """ Primitive entity.
    """

    def __init__(self, resource, primitive_type=None, primitive_template=None):
        """ Basic initialization.
        """

        self.resource = resource

        self.cls = None
        self.provider = None
        self.type = primitive_type

        self.template = primitive_template

        self.description = None

        self._params = list()
        self._meta = TaggedAttributesListWithMetaAndRules('meta')
        self._utilization = TaggedAttributesListWithMetaAndRules('utilization')

        self._ops = list()

    def add_params(self, params):
        """ Add params.
        """

        self._params.append(params)

    @property
    def meta(self):
        """ Get meta.
        """

        return self._meta

    @property
    def utilization(self):
        """ Get utilization.
        """

        return self._utilization

    def add_op(self, op_type, **kwargs):
        """ Add op.
        :param op_type: type of op
        """

        if op_type not in OP_TYPES:
            raise ScalersException("Incorrect op type.")

        op = Op(op_type)
        for (attr, value) in sorted(kwargs.items()):
            if attr == 'on_fail':
                attr = 'on-fail'
            op.add_attribute(attr, value)

        self._ops.append(op)

    def _verify(self):
        """ Verify object.
        """

        if self.resource is None:
            raise ScalersException("Resource field is missed in primitive description.")

        if (self.type is None) and (self.template is None):
            raise ScalersException("Type or template field is required in primitive description.")

        if (self.type is not None) and (self.template is not None):
            raise ScalersException("Type and template fields are mutually exclusive in primitive description.")

        if (self.template is None) and (self.type is not None) and \
                (self.cls is None) and (self.provider is not None):
            raise ScalersException("Provider field is specified without class field in primitive description.")

    def __str__(self):
        """ String representation.
        """

        self._verify()

        type_str = ''.join(filter(None, [
            None if self.cls is None else '{0}:'.format(str(self.cls)),
            None if self.provider is None else '{0}:'.format(str(self.provider)),
            None if self.type is None else str(self.type),
        ])) if self.template is None else str(Template(self.template))

        return ' '.join(filter(None, [
            'primitive',
            self.resource,
            type_str,
            None if self.description is None else str(Description(self.description)),
            None if len(self._params) == 0 else ' '.join([str(param) for param in self._params]),
            str(self._meta) if self._meta.is_content_present() else None,
            str(self._utilization) if self._utilization.is_content_present() else None,
            ' '.join([str(op) for op in self._ops]),
        ]))
