# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Classes for list of attributes.
"""

from collections import OrderedDict

from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm .entities.common.score import Score
from es.pacemaker.crm.entities.common.id import Id
from scalers.errors import ScalersException


class AttributesList(CrmObject):
    """ List of attributes.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self._attributes = OrderedDict()

    def add_attribute(self, attr, value):
        """ Add attribute.
        :param attr: parameter's name
        :param value: value of the parameter
        """

        self._attributes[attr] = value

    def __len__(self):
        """ Size of list.
        """

        return len(self._attributes)

    def __str__(self):
        """ String representation.
        """

        return ' '.join(['{0}={1}'.format(str(param), str(value)) for (param, value) in self._attributes.items()])


class AttributesListWithMeta(AttributesList):
    """ List of attributes with additional metadata.
    """

    def __init__(self):
        """ Basic initialization.
        """

        super(AttributesListWithMeta, self).__init__()

        self.id = None
        self.score = None

    def _verify(self):
        """ Verify object.
        """
        if len(self._attributes) == 0:
            raise ScalersException('At least one attribute should be specified.')

    def __str__(self):
        """ String representation.
        """

        self._verify()

        meta = ' '.join(filter(None, [
            None if self.id is None else str(Id(self.id)),
            None if self.score is None else str(Score(self.score))]))

        attributes = super(AttributesListWithMeta, self).__str__()

        return ' '.join(filter(None, [meta, attributes]))

    def is_content_present(self):
        """ Is any filed of the object is set.
        """

        return (self.id is not None) or (self.score is not None) or (len(self._attributes) > 0)


class AttributesListWithMetaAndRules(AttributesListWithMeta):
    """ List of attributes with additional metadata and rules.
    """

    def __init__(self):
        """ Basic initialization.
        """

        super(AttributesListWithMetaAndRules, self).__init__()

        self.rules = list()

    def __str__(self):
        """ String representation.
        """

        self._verify()

        meta = ' '.join(filter(None, [
            None if self.id is None else str(Id(self.id)),
            None if self.score is None else str(Score(self.score)),
            None if len(self.rules) == 0 else ' '.join([str(rule) for rule in self.rules])
        ]))

        attributes = super(AttributesListWithMeta, self).__str__()

        return ' '.join(filter(None, [meta, attributes]))

    def is_content_present(self):
        """ Is any filed of the object is set.
        """

        return (self.id is not None) or (self.score is not None) or (len(self._attributes) > 0) or (len(self.rules) > 0)


class AttributesListWithId(AttributesList):
    """ List of attributes with id.
    """

    def __init__(self):
        """ Basic initialization.
        """

        super(AttributesListWithId, self).__init__()

        self.id = None

    def _verify(self):
        """ Verify object.
        """
        if len(self._attributes) == 0:
            raise ScalersException('At least one attribute should be specified.')

    def __str__(self):
        """ String representation.
        """

        self._verify()

        meta = None if self.id is None else str(Id(self.id))

        attributes = super(AttributesListWithId, self).__str__()

        return ' '.join(filter(None, [meta, attributes]))

    def is_content_present(self):
        """ Is any filed of the object is set.
        """

        return (self.id is not None) or (len(self._attributes) > 0)


class AttributesListWithSetId(AttributesListWithId):
    """ List of attributes with set-id.
    """

    def __str__(self):
        """ String representation.
        """

        meta = None if self.id is None else '{0}:'.format(str(self.id))

        attributes = super(AttributesListWithId, self).__str__()

        return ' '.join(filter(None, [meta, attributes]))


class TaggedAttributesListWithMeta(AttributesListWithMeta):
    """ Tagged list of attributes with additional metadata.
    """

    def __init__(self, tag):
        """ Basic initialization.
        """

        super(TaggedAttributesListWithMeta, self).__init__()
        self._tag = tag

    def __str__(self):
        """ String representation.
        """

        return ' '.join([self._tag, super(TaggedAttributesListWithMeta, self).__str__()])


class TaggedAttributesListWithMetaAndRules(AttributesListWithMetaAndRules):
    """ Tagged list of attributes with additional metadata and rules.
    """

    def __init__(self, tag):
        """ Basic initialization.
        """

        super(TaggedAttributesListWithMetaAndRules, self).__init__()
        self._tag = tag

    def __str__(self):
        """ String representation.
        """

        return ' '.join([self._tag, super(TaggedAttributesListWithMetaAndRules, self).__str__()])


class TaggedAttributesListWithId(AttributesListWithId):
    """ Tagged list of attributes with id.
    """

    def __init__(self, tag):
        """ Basic initialization.
        """

        super(TaggedAttributesListWithId, self).__init__()
        self._tag = tag

    def __str__(self):
        """ String representation.
        """

        return ' '.join([self._tag, super(TaggedAttributesListWithId, self).__str__()])


class TaggedAttributesListWithSetId(AttributesListWithSetId):
    """ Tagged list of attributes with id.
    """

    def __init__(self, tag):
        """ Basic initialization.
        """

        super(TaggedAttributesListWithSetId, self).__init__()
        self._tag = tag

    def __str__(self):
        """ String representation.
        """

        return ' '.join([self._tag, super(TaggedAttributesListWithSetId, self).__str__()])
