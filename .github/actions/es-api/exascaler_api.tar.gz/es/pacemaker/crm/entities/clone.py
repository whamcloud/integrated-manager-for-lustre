# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for clone description.
"""

from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm.entities.common.attributes import TaggedAttributesListWithId
from es.pacemaker.crm.entities.common.description import Description


class Clone(CrmObject):
    """ Clone entity.
    """

    def __init__(self, name, resource):
        """ Basic initialization.
        """

        self.name = name
        self.resource = resource
        self.description = None
        self._params = TaggedAttributesListWithId('params')
        self._meta = TaggedAttributesListWithId('meta')

    @property
    def params(self):
        """ Get params.
        """

        return self._params

    @property
    def meta(self):
        """ Get meta.
        """

        return self._meta

    def __str__(self):
        """ String representation.
        """

        return ' '.join(filter(None, [
            'clone',
            self.name,
            self.resource,
            None if self.description is None else str(Description(self.description)),
            str(self._meta) if self._meta.is_content_present() else None,
            str(self._params) if self._params.is_content_present() else None,
        ]))
