# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for node-pref description.
"""

from es.pacemaker.crm.entities.common import CrmObject


class NodePref(CrmObject):
    """ node-pref entity.
    """

    def __init__(self, score, node):
        """ Basic initialization.
        """

        self.score = score
        self.node = node

    def __str__(self):
        """ String representation.
        """

        return '{0}: {1}'.format(self.score, self.node)
