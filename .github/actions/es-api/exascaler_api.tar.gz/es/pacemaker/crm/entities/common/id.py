# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for id representation.
"""

from es.pacemaker.crm.entities.common import CrmObject


class Id(CrmObject):
    """ Id representation.
    """

    __slots__ = ['id', ]

    def __init__(self, value):
        """ Basic initialization.
        """

        self.id = value

    def __str__(self):
        """ String representation.
        """

        return '$id={0}'.format(self.id)
