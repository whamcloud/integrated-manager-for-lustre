# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for colocation description.
"""

from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm.entities.common.score import Score
from scalers.errors import ScalersException

from collections import OrderedDict


class Colocation(CrmObject):
    """ Colocation description.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self.id = None
        self.score = None
        self._resources = OrderedDict()
        self.node_attribute = None

    def add_resource(self, name, role=None):
        """ Add resource.
        :param name: resource name
        :param role: resource role
        """

        self._resources[name] = role

    def _verify(self):
        """ Verify object.
        """

        if self.id is None:
            raise ScalersException('Id is missed in colocation description.')

        if self.score is None:
            raise ScalersException('Score is missed in colocation description.')

        if len(self._resources) == 0:
            raise ScalersException('At least one resource should be specified in colocation description.')

    def __str__(self):
        """ String representation.
        """

        self._verify()

        return ' '.join(filter(None, [
            'colocation',
            str(self.id),
            str(Score(self.score)),
            ' '.join([str(key) if value is None else '{0}:{1}'.format(str(key), str(value))
                      for (key, value) in self._resources.items()]),
            None if self.node_attribute is None else 'node-attribute={0}'.format(str(self.node_attribute)),
        ]))
