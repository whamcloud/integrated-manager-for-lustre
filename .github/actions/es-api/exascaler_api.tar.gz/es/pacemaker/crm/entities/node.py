# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for node description.
"""

from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm.entities.common.attributes import TaggedAttributesListWithMeta
from es.pacemaker.crm.entities.common.type import Type
from es.pacemaker.crm.entities.common.id import Id
from es.pacemaker.crm.entities.common.description import Description


class Node(CrmObject):
    """ Node entity.
    """

    def __init__(self, uname):
        """ Basic initialization.
        """

        self.id = None
        self.uname = uname
        self.type = None
        self.description = None
        self._attributes = TaggedAttributesListWithMeta('attributes')
        self._utilization = TaggedAttributesListWithMeta('utilization')

    @property
    def attributes(self):
        """ Get attributes.
        """

        return self._attributes

    @property
    def utilization(self):
        """ Get utilization.
        """

        return self._utilization

    def __str__(self):
        """ String representation.
        """

        name_and_type = ''.join(filter(None, [
            self.uname,
            None if self.type is None else str(Type(self.type)),
        ]))

        return ' '.join(filter(None, [
            'node',
            None if self.id is None else str(Id(self.id)),
            name_and_type,
            None if self.description is None else str(Description(self.description)),
            str(self._attributes) if self._attributes.is_content_present() else None,
            str(self._utilization) if self._utilization.is_content_present() else None,
        ]))
