# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for location description.
"""


from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm.entities.common.node_pref import NodePref
from es.pacemaker.crm.entities.common.rule import Rule

from scalers.errors import ScalersException


class Location(CrmObject):
    """ Location entity.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self.id = None
        self.resource = None
        self._rules = list()
        self.node_pref = None
        self.resource_discovery_attribute = None

    def add_rule(self, rule):
        """ Add rule.
        @type rule: Rule
        """

        if not isinstance(rule, Rule):
            raise ScalersException('Rule should be an instance of Rule class.')

        self._rules.append(rule)

    def _verify(self):
        """ Verify object.
        """

        if self.id is None:
            raise ScalersException('Id is missed in location description.')

        if self.resource is None:
            raise ScalersException('Resource is missed in location description.')

        if len(self._rules) == 0 and self.node_pref is None:
            raise ScalersException('At least one rule or node_pref should be specified in location description.')

        if len(self._rules) > 0 and self.node_pref is not None:
            raise ScalersException('Rules and node_pref option are mutually exclusive  in location description.')

        if (self.resource_discovery_attribute is not None) and (
                    self.resource_discovery_attribute not in ('always', 'never', 'exclusive', )):
            raise ScalersException("Invalid resource discovery attribute '{0}'. Possible values are: "
                                   "'always', 'never', 'exclusive'.".format(self.resource_discovery_attribute))

    def __str__(self):
        """ String representation.
        """

        self._verify()

        return ' '.join(filter(None, [
            'location',
            str(self.id),
            str(self.resource),
            None if self.resource_discovery_attribute is None else 'resource-discovery={0}'.format(
                self.resource_discovery_attribute),
            None if self.node_pref is None else str(self.node_pref),
            ' '.join([str(rule) for rule in self._rules]),
        ]))
