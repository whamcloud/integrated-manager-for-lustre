# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for group description.
"""

from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm.entities.common.attributes import TaggedAttributesListWithId
from es.pacemaker.crm.entities.common.description import Description
from scalers.errors import ScalersException


class Group(CrmObject):
    """ Group entity.
    """

    def __init__(self, name):
        """ Basic initialization.
        """

        self.name = name
        self._resources = list()
        self.description = None
        self._meta = TaggedAttributesListWithId('meta')
        self._params = TaggedAttributesListWithId('params')

    def add_resource(self, resource):
        """ Add resource.
        :param resource: resource description
        """

        self._resources.append(resource)

    @property
    def meta(self):
        """ Get meta.
        """

        return self._meta

    @property
    def params(self):
        """ Get params.
        """

        return self._params

    def _verify(self):
        """ Verify object.
        """

        if self.name is None:
            raise ScalersException('Name is missed in group description.')

        if len(self._resources) == 0:
            raise ScalersException('At least one resource should be specified in group description.')

    def __str__(self):
        """ String representation.
        """
        self._verify()

        return ' '.join(filter(None, [
            'group',
            self.name,
            ' '.join([str(resource) for resource in self._resources]),
            None if self.description is None else str(Description(self.description)),
            str(self._meta) if self._meta.is_content_present() else None,
            str(self._params) if self._params.is_content_present() else None,
        ]))
