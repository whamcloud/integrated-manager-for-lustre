# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for rsc_defaults description.
"""


from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm.entities.common.rule import Rule
from es.pacemaker.crm.entities.common.attributes import AttributesList

from scalers.errors import ScalersException


class RscDefaults(CrmObject):
    """ RscDefaults entity.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self.id = None
        self.resource = None
        self._rule = None
        self._options = AttributesList()

    @property
    def rule(self):
        """ Get rule.
        """

        if self._rule is None:
            self._rule = Rule()

        return self._rule

    @property
    def options(self):
        """ Get options.
        """

        return self._options

    def _verify(self):
        """ Verify object.
        """

        if len(self._options) == 0:
            raise ScalersException('At least one option should be specified in rsc_defaults description.')

    def __str__(self):
        """ String representation.
        """

        self._verify()

        return ' '.join(filter(None, [
            'rsc_defaults',
            None if self.id is None else '{0}:'.format(str(self.id)),
            None if self._rule is None else str(self._rule),
            str(self._options),
        ]))
