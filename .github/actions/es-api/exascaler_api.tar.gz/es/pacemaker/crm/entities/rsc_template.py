# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for rsc_template description.
"""

from es.pacemaker.crm.entities.common import CrmObject
from es.pacemaker.crm.entities.common.attributes import TaggedAttributesListWithId, AttributesList
from es.pacemaker.crm.entities.common.description import Description
from scalers.errors import ScalersException

OP_TYPE_START = 'start'
OP_TYPE_STOP = 'stop'
OP_TYPE_MONITOR = 'monitor'
OP_TYPES = (OP_TYPE_START, OP_TYPE_STOP, OP_TYPE_MONITOR, )


class Op(AttributesList):
    """ Op entity.
    """

    def __init__(self, op_type):
        """ Basic initialization.
        """

        super(Op, self).__init__()

        self.type = op_type

    def __str__(self):
        """ String representation.
        """

        return ' '.join(filter(None, [
            'op',
            self.type,
            super(Op, self).__str__(),
        ]))


class RscTemplate(CrmObject):
    """ RscTemplate entity.
    """

    def __init__(self, template_name, template_type):
        """ Basic initialization.
        """

        self.name = template_name
        self.cls = None
        self.provider = None
        self.type = template_type
        self.description = None
        self._params = TaggedAttributesListWithId('params')
        self._meta = TaggedAttributesListWithId('meta')
        self._utilization = TaggedAttributesListWithId('utilization')
        self._ops = list()

    @property
    def params(self):
        """ Get params.
        """

        return self._params

    @property
    def meta(self):
        """ Get meta.
        """

        return self._meta

    @property
    def utilization(self):
        """ Get utilization.
        """

        return self._utilization

    def add_op(self, op_type, **kwargs):
        """ Add op.
        :param op_type: type of op
        """

        if op_type not in OP_TYPES:
            raise ScalersException("Incorrect op type.")

        op = Op(op_type)
        for (attr, value) in sorted(kwargs.items()):
            op.add_attribute(attr, value)

        self._ops.append(op)

    def _verify(self):
        """ Verify object.
        """

        if self.name is None:
            raise ScalersException("Name field is missed in resource template description.")

        if self.type is None:
            raise ScalersException("Type field is missed in resource template description.")

        if (self.cls is None) and (self.provider is not None):
            raise ScalersException("Provider field is specified without class field in resource template description.")

    def __str__(self):
        """ String representation.
        """

        self._verify()

        type_str = ''.join(filter(None, [
            None if self.cls is None else '{0}:'.format(str(self.cls)),
            None if self.provider is None else '{0}:'.format(str(self.provider)),
            None if self.type is None else str(self.type),
        ]))

        return ' '.join(filter(None, [
            'rsc_template',
            self.name,
            type_str,
            None if self.description is None else str(Description(self.description)),
            str(self._params) if self._params.is_content_present() else None,
            str(self._meta) if self._meta.is_content_present() else None,
            str(self._utilization) if self._utilization.is_content_present() else None,
            ' '.join([str(op) for op in self._ops]),
        ]))
