# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for rsc_ticket description.
"""

from es.pacemaker.crm.entities.common import CrmObject
from scalers.errors import ScalersException

from collections import OrderedDict


LOSS_POLICY_ACTION_STOP = 'stop'
LOSS_POLICY_ACTION_DEMOTE = 'demote'
LOSS_POLICY_ACTION_FENCE = 'fence'
LOSS_POLICY_ACTION_FREEZE = 'freeze'
LOSS_POLICY_ACTIONS = (LOSS_POLICY_ACTION_STOP, LOSS_POLICY_ACTION_DEMOTE,
                       LOSS_POLICY_ACTION_FENCE, LOSS_POLICY_ACTION_FREEZE, )


class RscTicket(CrmObject):
    """ RscTicket entity.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self.id = None
        self.ticket_id = None
        self._resources = OrderedDict()
        self.loss_policy = None

    def add_resource(self, res, role=None):
        """ Add resource with role.
        :param res: resource name
        :param role: resource role(optional)
        """

        self._resources[res] = role

    def _verify(self):
        """ Verify object.
        """

        if self.id is None:
            raise ScalersException('Id is missed in rsc_ticket description.')

        if self.ticket_id is None:
            raise ScalersException('Ticket id is missed in rsc_ticket description.')

        if len(self._resources) == 0:
            raise ScalersException('At least one resource should be specified in rsc_ticket description.')

        if (self.loss_policy is not None) and (self.loss_policy not in LOSS_POLICY_ACTIONS):
            raise ScalersException("Incorrect loss policy action '{0}' in rsc_ticket description.".format(
                self.loss_policy
            ))

    def __str__(self):
        """ String representation.
        """

        self._verify()

        return ' '.join(filter(None, [
            'rsc_ticket',
            str(self.id),
            '{0}:'.format(str(self.ticket_id)),
            ' '.join([str(key) if value is None else '{0}:{1}'.format(str(key), str(value))
                      for (key, value) in self._resources.items()]),
            None if self.loss_policy is None else 'loss-policy={0}'.format(str(self.loss_policy))
        ]))
