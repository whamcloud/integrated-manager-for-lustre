# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Class for template representation.
"""

from es.pacemaker.crm.entities.common import CrmObject


class Template(CrmObject):
    """ Template representation.
    """

    __slots__ = ['template', ]

    def __init__(self, value):
        """ Basic initialization.
        """

        self.template = value

    def __str__(self):
        """ String representation.
        """

        return '@{0}'.format(self.template)
