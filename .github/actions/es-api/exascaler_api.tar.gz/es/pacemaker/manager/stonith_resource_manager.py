# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Resource manager for stonith resources.
"""

from es.pacemaker.crm.commands.crm_mon import crm_mon
from es.pacemaker.manager.resource_manager import BaseResourceManager


class StonithResourceManager(BaseResourceManager):
    """ Resource manager for stonith resources.
    """

    def get_resources_list(self, host=None, fs=None, resource_type=None):
        """ List all stonith resources for given host.
        """

        return [res['id'] for res in crm_mon(host)['resources'] if res['id'].startswith('stonith')]
