# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Resource manager for Lustre resources.
"""

import time
import multiprocessing

from es.pacemaker.crm.commands.resource import stop, start
from es.pacemaker.crm.commands.crm_mon import crm_mon
from es.pacemaker.manager.lvm_resource_manager import LvmResourceManager
from es.utils import get_hostname
from scalers.errors import ScalersException
from scalers.utils.command import CommandExecutor, StringCommand


class LustreResourceManager(object):
    """ Resource manager for Lustre resources.
    """

    def __init__(self, config):
        """ Basic initialization.
        """

        self.config = config

    @staticmethod
    def is_ticket_active(ticket_id, host=None):
        """ Check if ticket active on given host.
        """

        tickets = crm_mon(host)['tickets']
        for ticket in tickets:
            if ticket['id'] != ticket_id:
                continue
            return ticket['status'] == 'granted'

        raise ScalersException('Unable to find ticket {0} on host {1}'.format(ticket_id, host))

    @staticmethod
    def is_all_filesystem_resources_active(fs_resource, host=None, resource_type=None):
        """ Check if resources related to filesystem resource active on given host.
        """

        resource_types = ['mdt', 'ost', ] if resource_type is None else [resource_type, ]

        resources = crm_mon(host)['resources']

        for res in resources:
            if any([res['id'].startswith(resource_type) for resource_type in resource_types])\
                    and res['id'].endswith(fs_resource):
                if res['active'] != 'true':
                    return False

        return True

    @staticmethod
    def is_all_filesystem_resources_not_active(fs_resource, host=None, resource_type=None):
        """ Check if resources related to filesystem resource not active on given host.
        """

        resource_types = ['mdt', 'ost', ] if resource_type is None else [resource_type, ]

        resources = crm_mon(host)['resources']

        for res in resources:
            if any([res['id'].startswith(resource_type) for resource_type in resource_types]) \
                    and res['id'].endswith(fs_resource):
                if res['active'] == 'true':
                    return False
        return True

    @staticmethod
    def is_mgs_resources_active(host=None):
        """ Check if MGT resource active on given host.
        """

        resources = crm_mon(host)['resources']
        for res in resources:
            if res['id'] == 'mgs':
                if res['active'] == 'true':
                    return True
        return False

    def stop_filesystem_ticket_resource(self, resource_id, host=None, timeout=600, perform_checks=True,
                                        dry_run=False, need_status=True):
        """ Stop filesystem ticket resource.
        """

        ticket_id = '{0}-allocated'.format(resource_id)
        is_action_performed = False

        if host is None:
            if get_hostname() in self.config.fs_settings[resource_id].host_list:
                if dry_run:
                    print 'crm resource stop {0}'.format(resource_id)
                    return
                else:
                    stop(resource_id, host)
                    is_action_performed = True
        else:
            if host in self.config.fs_settings[resource_id].host_list:
                if dry_run:
                    print 'ssh {0} crm resource stop {1}'.format(host, resource_id)
                    return
                else:
                    stop(resource_id, host)
                    is_action_performed = True

        if not is_action_performed:
            return

        start_time = time.time()
        if perform_checks:
            while True:
                if not self.is_ticket_active(ticket_id, host) and \
                        self.is_all_filesystem_resources_not_active(resource_id, host):
                    return
                if need_status:
                    print 'Waiting for {0} to stop'.format(resource_id)
                if time.time() - start_time > timeout:
                    raise ScalersException("Stop operation for resource {0} exceeds timeout.".format(resource_id))
                time.sleep(1)

    def start_filesystem_ticket_resource(self, resource_id, host=None, timeout=600, perform_checks=True,
                                         dry_run=False, need_status=True):
        """ Start filesystem ticket resource.
        """

        ticket_id = '{0}-allocated'.format(resource_id)
        is_action_performed = False

        if host is None:
            if get_hostname() in self.config.fs_settings[resource_id].host_list:
                if dry_run:
                    print 'crm resource start {0}'.format(resource_id)
                    return
                else:
                    start(resource_id, host)
                    is_action_performed = True
        else:
            if host in self.config.fs_settings[resource_id].host_list:
                if dry_run:
                    print 'ssh {0} crm resource start {1}'.format(host, resource_id)
                    return
                else:
                    start(resource_id, host)
                    is_action_performed = True

        if not is_action_performed:
            return
        
        start_time = time.time()
        if perform_checks:
            while True:
                if self.is_ticket_active(ticket_id, host) and \
                        self.is_all_filesystem_resources_active(resource_id, host):
                    return
                if need_status:
                    print 'Waiting for {0} to start'.format(resource_id)
                if time.time() - start_time > timeout:
                    raise ScalersException("Start operation for resource {0} exceeds timeout.".format(resource_id))
                time.sleep(1)

    def check_filesystem_resources_availability(self, host=None):
        """ Check Lustre resources availability for given host.
        """

        result = dict()
        filesystems = self.config.fs_settings.keys()
        result['mgs_presented'] = False
        result['filesystems'] = dict()
        for fs in filesystems:
            result['filesystems'][fs] = dict()
            result['filesystems'][fs]['mdt_presented'] = False
            result['filesystems'][fs]['ost_presented'] = False

        resources = crm_mon(host)['resources']
        for res in resources:
            if res['id'] == 'mgs':
                result['mgs_presented'] = True
                continue

            for fs in filesystems:
                if res['id'].startswith('mdt') and res['id'].endswith(fs):
                    result['filesystems'][fs]['mdt_presented'] = True
                    break
                if res['id'].startswith('ost') and res['id'].endswith(fs):
                    result['filesystems'][fs]['ost_presented'] = True
                    break

        return result

    def stop_lustre_ticket_resource(self, host=None, timeout=600, perform_checks=True,
                                    dry_run=False, need_status=True):
        """ Stop lustre ticket resource.
        """

        ticket_id = 'lustre-allocated'

        if dry_run:
            if host is None:
                print 'crm resource stop lustre'
            else:
                print 'ssh {0} crm resource stop lustre'.format(host)
            return
        stop('lustre', host)
        start_time = time.time()
        if perform_checks:
            while True:
                if not self.is_ticket_active(ticket_id, host) and not self.is_mgs_resources_active(host):
                    return
                if need_status:
                    print 'Waiting for lustre to stop'
                if time.time() - start_time > timeout:
                    raise ScalersException("Stop operation for resource lustre exceeds timeout.")
                time.sleep(1)

    def start_lustre_ticket_resource(self, host=None, timeout=600, perform_checks=True, check_mgs=False,
                                     dry_run=False, need_status=True):
        """ Start lustre ticket resource.
        """

        ticket_id = 'lustre-allocated'

        if dry_run:
            if host is None:
                print 'crm resource start lustre'
            else:
                print 'ssh {0} crm resource start lustre'.format(host)
            return
        start('lustre', host)
        start_time = time.time()
        if perform_checks:
            while True:
                if self.is_ticket_active(ticket_id, host):
                    if check_mgs:
                        if self.is_mgs_resources_active(host):
                            return
                    else:
                        return
                if need_status:
                    print 'Waiting for lustre to start'
                if time.time() - start_time > timeout:
                    raise ScalersException("Start operation for resource lustre exceeds timeout.")
                time.sleep(1)

    def start(self, fs=None, resource_type=None, timeout=600, perform_checks=True, dry_run=False):
        """ Start all mentioned resources for cluster.
        """

        LvmResourceManager(self.config).start(timeout=timeout, perform_checks=perform_checks, dry_run=dry_run)

        ha_groups = self.config.ha_settings.ha_groups[:]

        availability = dict()
        for ha_group in ha_groups:
            if get_hostname() in ha_group:
                availability[None] = self.check_filesystem_resources_availability()
            else:
                for host in ha_group:
                    if CommandExecutor(StringCommand('uptime')).run(node=host).exit_code == 0:
                        availability[host] = self.check_filesystem_resources_availability(host)
                        break
                    else:
                        raise ScalersException('HA group({0}) is unreachable.'.format(','.join(ha_group)))

        for host, value in availability.items():
            if value['mgs_presented']:
                self.start_lustre_ticket_resource(host=host, timeout=timeout, perform_checks=perform_checks,
                                                  check_mgs=True, dry_run=dry_run)
                break
        for host, value in availability.items():
            if not value['mgs_presented']:
                self.start_lustre_ticket_resource(host=host, timeout=timeout, perform_checks=perform_checks,
                                                  check_mgs=False, dry_run=dry_run)

        filesystems = self.config.fs_settings.keys() if fs is None else [fs, ]

        for fs in filesystems:
            order = list()
            for host, value in availability.items():
                if value['filesystems'][fs]['mdt_presented']:
                    order.append(host)
            for host, value in availability.items():
                if not value['filesystems'][fs]['mdt_presented']:
                    order.append(host)
            for item in order:
                self.start_filesystem_ticket_resource(fs, host=item, timeout=timeout, perform_checks=perform_checks,
                                                      dry_run=dry_run)

    def stop(self, fs=None, resource_type=None, timeout=600, perform_checks=True, dry_run=False):
        """ Stop all mentioned resources for cluster.
        """

        ha_groups = self.config.ha_settings.ha_groups[:]

        filesystems = self.config.fs_settings.keys() if fs is None else [fs, ]

        availability = dict()
        for ha_group in ha_groups:
            if get_hostname() in ha_group:
                availability[None] = self.check_filesystem_resources_availability()
            else:
                availability[ha_group[0]] = self.check_filesystem_resources_availability(ha_group[0])

        for fs in filesystems:
            order = list()
            for host, value in availability.items():
                if not value['filesystems'][fs]['mdt_presented'] and value['filesystems'][fs]['ost_presented']:
                    order.append(host)
            for host, value in availability.items():
                if value['filesystems'][fs]['mdt_presented'] and value['filesystems'][fs]['ost_presented']:
                    order.append(host)
            for host, value in availability.items():
                if value['filesystems'][fs]['mdt_presented'] and not value['filesystems'][fs]['ost_presented']:
                    order.append(host)
            for host, value in availability.items():
                if not value['filesystems'][fs]['mdt_presented'] and not value['filesystems'][fs]['ost_presented']:
                    order.append(host)

            for item in order:
                self.stop_filesystem_ticket_resource(fs, host=item, timeout=timeout, perform_checks=perform_checks,
                                                     dry_run=dry_run)

        for host, value in availability.items():
            if not value['mgs_presented']:
                self.stop_lustre_ticket_resource(host=host, timeout=timeout, perform_checks=perform_checks,
                                                 dry_run=dry_run)
        for host, value in availability.items():
            if value['mgs_presented']:
                self.stop_lustre_ticket_resource(host=host, timeout=timeout, perform_checks=perform_checks,
                                                 dry_run=dry_run)

    class ResourceOperationProcess(multiprocessing.Process):
        """ Class for pacemaker resource operation execution in separate process.
        """

        def __init__(self, function, *args, **kwargs):
            """Basic initialization.
            """

            multiprocessing.Process.__init__(self)

            self.args = args
            self.kwargs = kwargs
            self.function = function
            manager = multiprocessing.Manager()
            self.output = manager.Value(str, '')
            self.return_code = manager.Value(int, 0)

        def run(self):
            """ Process execution.
            """

            try:
                self.output.value = self.function(*self.args, **self.kwargs)
            except Exception as e:
                self.output.value = str(e)
                self.return_code.value = 1

    @staticmethod
    def _run_tasks(task_list):
        """ Run tasks in separate processes.
        """
        task_errors = list()

        for task in task_list:
            task.start()

        for task in task_list:
            task.join()
            if task.return_code.value != 0:
                task_errors.append(task.output.value)

        if len(task_errors) > 0:
            raise ScalersException('\n'.join(task_errors))

    def start_async(self, fs=None, resource_type=None, timeout=600):
        """ Start all mentioned resources for cluster.
        """

        LvmResourceManager(self.config).start_async(timeout=timeout, perform_checks=True)

        ha_groups = self.config.ha_settings.ha_groups[:]

        availability = dict()
        for ha_group in ha_groups:
            if get_hostname() in ha_group:
                availability[None] = self.check_filesystem_resources_availability()
            else:
                for host in ha_group:
                    if CommandExecutor(StringCommand('uptime')).run(node=host).exit_code == 0:
                        availability[host] = self.check_filesystem_resources_availability(host)
                        break
                    else:
                        raise ScalersException('HA group({0}) is unreachable.'.format(','.join(ha_group)))

        for host, value in availability.items():
            if value['mgs_presented']:
                self.start_lustre_ticket_resource(host=host, timeout=timeout,
                                                  perform_checks=True, check_mgs=True, need_status=False)
                break

        self._run_tasks([self.ResourceOperationProcess(
            self.start_lustre_ticket_resource,
            host=host,
            timeout=timeout,
            perform_checks=True,
            check_mgs=False,
            need_status=False
        ) for host, value in availability.items() if not value['mgs_presented']])

        filesystems = self.config.fs_settings.keys() if fs is None else [fs, ]

        for fs in filesystems:
            order = list()
            for host, value in availability.items():
                if value['filesystems'][fs]['mdt_presented']:
                    order.append(host)
            self._run_tasks([self.ResourceOperationProcess(
                self.start_filesystem_ticket_resource,
                fs,
                host=host,
                timeout=timeout,
                perform_checks=True,
                need_status=False) for host in order])

        for fs in filesystems:
            order = list()
            for host, value in availability.items():
                if not value['filesystems'][fs]['mdt_presented']:
                    order.append(host)
            self._run_tasks([self.ResourceOperationProcess(
                self.start_filesystem_ticket_resource,
                fs,
                host=host,
                timeout=timeout,
                perform_checks=False,
                need_status=False) for host in order])

    def stop_async(self, fs=None, resource_type=None, timeout=600):
        """ Stop all mentioned resources for cluster.
        """

        ha_groups = self.config.ha_settings.ha_groups[:]

        filesystems = self.config.fs_settings.keys() if fs is None else [fs, ]

        availability = dict()
        for ha_group in ha_groups:
            if get_hostname() in ha_group:
                availability[None] = self.check_filesystem_resources_availability()
            else:
                availability[ha_group[0]] = self.check_filesystem_resources_availability(ha_group[0])

        for fs in filesystems:
            order = list()
            for host, value in availability.items():
                if not value['filesystems'][fs]['mdt_presented'] and value['filesystems'][fs]['ost_presented']:
                    order.append(host)
            self._run_tasks([self.ResourceOperationProcess(
                self.stop_filesystem_ticket_resource,
                fs,
                host=host,
                timeout=timeout,
                need_status=False) for host in order])
        for fs in filesystems:
            order = list()
            for host, value in availability.items():
                if value['filesystems'][fs]['mdt_presented'] and value['filesystems'][fs]['ost_presented']:
                    order.append(host)
            self._run_tasks([self.ResourceOperationProcess(
                self.stop_filesystem_ticket_resource,
                fs,
                host=host,
                timeout=timeout,
                need_status=False) for host in order])
        for fs in filesystems:
            order = list()
            for host, value in availability.items():
                if value['filesystems'][fs]['mdt_presented'] and not value['filesystems'][fs]['ost_presented']:
                    order.append(host)
            self._run_tasks([self.ResourceOperationProcess(
                self.stop_filesystem_ticket_resource,
                fs,
                host=host,
                timeout=timeout,
                need_status=False) for host in order])

        for fs in filesystems:
            order = list()
            for host, value in availability.items():
                if not value['filesystems'][fs]['mdt_presented'] and not value['filesystems'][fs]['ost_presented']:
                    order.append(host)
            self._run_tasks([self.ResourceOperationProcess(
                self.stop_filesystem_ticket_resource,
                fs,
                host=host,
                timeout=timeout,
                need_status=False) for host in order])

        self._run_tasks([self.ResourceOperationProcess(
            self.stop_lustre_ticket_resource,
            host=host,
            timeout=timeout,
            need_status=False
        ) for host, value in availability.items() if not value['mgs_presented']])

        for host, value in availability.items():
            if value['mgs_presented']:
                self.stop_lustre_ticket_resource(host=host, timeout=timeout, need_status=False)
                break
