# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Resource manager for LVM resources.
"""

from es.pacemaker.crm.commands.crm_mon import crm_mon
from es.pacemaker.manager.resource_manager import BaseResourceManager


class ZfsResourceManager(BaseResourceManager):
    """ Resource manager for LVM resources.
    """

    def get_resources_list(self, host=None, fs=None, resource_type=None):
        """ List all LVM resources for given host.
        """

        results = list()
        for res in crm_mon(host)['resources']:
            if res['id'].endswith('-zpool'):
                if resource_type is not None:
                    if not res['id'].startswith(resource_type):
                        continue
                if fs is not None:
                    if not res['id'].endswith('{0}-zpool'.format(fs)):
                        continue
                results.append(res['id'])

        return results
