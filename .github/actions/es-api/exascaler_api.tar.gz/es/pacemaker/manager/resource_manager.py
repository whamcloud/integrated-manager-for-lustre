# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Base resource manager for all pacemaker resources.
"""

import abc
import time
import multiprocessing

from es.pacemaker.crm.commands.crm_mon import crm_mon
from es.pacemaker.crm.commands.resource import stop, start
from es.utils import get_hostname
from scalers.errors import ScalersException
from scalers.utils.command import CommandExecutor, StringCommand


class BaseResourceManager(object):
    """ Base resource manager for all pacemaker resources.
    """

    class ResourceOperationProcess(multiprocessing.Process):
        """ Class for pacemaker resource operation execution in separate process.
        """

        def __init__(self, function, *args, **kwargs):
            """Basic initialization.
            """

            multiprocessing.Process.__init__(self)

            self.args = args
            self.kwargs = kwargs
            self.function = function
            manager = multiprocessing.Manager()
            self.output = manager.Value(str, '')
            self.return_code = manager.Value(int, 0)

        def run(self):
            """ Process execution.
            """

            try:
                self.output.value = self.function(*self.args, **self.kwargs)
            except Exception as e:
                self.output.value = str(e)
                self.return_code.value = 1

    def __init__(self, config):
        """ Basic initialization.
        """

        self.config = config

    @staticmethod
    def is_resource_active(resource_id, host=None):
        """ Check if resource active.
        """

        resources = crm_mon(host)['resources']
        for res in resources:
            if res['id'] != resource_id:
                continue
            return res['active'] == 'true'

        raise ScalersException('Unable to find resource {0} on host {1}'.format(resource_id, host))

    @staticmethod
    def is_resource_non_active(resource_id, host=None):
        """ Check if resource non active.
        """

        resources = crm_mon(host)['resources']
        for res in resources:
            if res['id'] != resource_id:
                continue
            return res['active'] == 'false'

        raise ScalersException('Unable to find resource {0} on host {1}'.format(resource_id, host))

    def stop_resource(self, resource_id, host=None, timeout=600, perform_checks=True, dry_run=False, need_status=True):
        """ Stop pacemaker resource.
        """

        if dry_run:
            if host is None:
                print 'crm resource stop {0}'.format(resource_id)
            else:
                print 'ssh {0} crm resource stop {1}'.format(host, resource_id)
            return

        stop(resource_id, host)
        start_time = time.time()
        if perform_checks:
            while True:
                if self.is_resource_non_active(resource_id, host):
                    return
                if need_status:
                    print 'Waiting for {0} to stop'.format(resource_id)
                if time.time() - start_time > timeout:
                    raise ScalersException("Stop operation for resource {0} exceeds timeout.".format(resource_id))
                time.sleep(1)

    def start_resource(self, resource_id, host=None, timeout=600, perform_checks=True, dry_run=False, need_status=True):
        """ Start pacemaker resource.
        """

        if dry_run:
            if host is None:
                print 'crm resource start {0}'.format(resource_id)
            else:
                print 'ssh {0} crm resource start {1}'.format(host, resource_id)
            return

        start(resource_id, host)
        start_time = time.time()
        if perform_checks:
            while True:
                if self.is_resource_active(resource_id, host):
                    return
                if need_status:
                    print 'Waiting for {0} to start'.format(resource_id)
                if time.time() - start_time > timeout:
                    raise ScalersException("Start operation for resource {0} exceeds timeout.".format(resource_id))
                time.sleep(1)

    @abc.abstractmethod
    def get_resources_list(self, host=None, fs=None, resource_type=None):
        """ List all mentioned pacemaker resources for given host.
        """

        pass

    def stop_all_resources(self, host=None, fs=None, resource_type=None, timeout=600,
                           perform_checks=True, dry_run=False):
        """ Stop all mentioned pacemaker resources for given host.
        """

        for res in self.get_resources_list(host, fs, resource_type):
            self.stop_resource(res, host, timeout, perform_checks, dry_run)

    def start_all_resources(self, host=None, fs=None, resource_type=None, timeout=600, perform_checks=True,
                            dry_run=False):
        """ Start all mentioned resources for given host.
        """

        for res in self.get_resources_list(host, fs, resource_type):
            self.start_resource(res, host, timeout, perform_checks, dry_run)

    def start(self, fs=None, resource_type=None, timeout=600, perform_checks=True, dry_run=False):
        """ Start all mentioned resources for cluster.
        """

        ha_groups = self.config.ha_settings.ha_groups[:]

        for ha_group in ha_groups:
            if get_hostname() in ha_group:
                self.start_all_resources(fs=fs, resource_type=resource_type, timeout=timeout,
                                         perform_checks=perform_checks, dry_run=dry_run)
            else:
                for host in ha_group:
                    if CommandExecutor(StringCommand('uptime')).run(node=host).exit_code == 0:
                        self.start_all_resources(host=host, fs=fs, resource_type=resource_type, timeout=timeout,
                                                 perform_checks=perform_checks, dry_run=dry_run)
                        break
                    else:
                        raise ScalersException('HA group({0}) is unreachable.'.format(','.join(ha_group)))

    def stop(self, fs=None, resource_type=None, timeout=600, perform_checks=True, dry_run=False):
        """ Stop all mentioned resources for cluster.
        """

        ha_groups = self.config.ha_settings.ha_groups[:]

        for ha_group in ha_groups:
            if get_hostname() in ha_group:
                self.stop_all_resources(fs=fs, resource_type=resource_type, timeout=timeout,
                                        perform_checks=perform_checks, dry_run=dry_run)
            else:
                for host in ha_group:
                    if CommandExecutor(StringCommand('uptime')).run(node=host).exit_code == 0:
                        self.stop_all_resources(host=host, fs=fs, resource_type=resource_type, timeout=timeout,
                                                perform_checks=perform_checks, dry_run=dry_run)
                        break
                    else:
                        raise ScalersException('HA group({0}) is unreachable.'.format(','.join(ha_group)))

    @staticmethod
    def _run_tasks(task_list):
        """ Run tasks in separate processes.
        """
        task_errors = list()

        for task in task_list:
            task.start()

        for task in task_list:
            task.join()
            if task.return_code.value != 0:
                task_errors.append(task.output.value)

        if len(task_errors) > 0:
            raise ScalersException('\n'.join(task_errors))

    def start_async(self, fs=None, resource_type=None, timeout=600, perform_checks=True):
        """ Start all mentioned resources for cluster.
        """

        ha_groups = self.config.ha_settings.ha_groups[:]

        tasks = list()

        for ha_group in ha_groups:
            if get_hostname() in ha_group:
                for res in self.get_resources_list(get_hostname(), fs, resource_type):
                    tasks.append(self.ResourceOperationProcess(self.start_resource, res, host=get_hostname(),
                                                               timeout=timeout, perform_checks=perform_checks,
                                                               need_status=False))
            else:
                for host in ha_group:
                    if CommandExecutor(StringCommand('uptime')).run(node=host).exit_code == 0:
                        for res in self.get_resources_list(host, fs, resource_type):
                            tasks.append(
                                self.ResourceOperationProcess(self.start_resource, res, host=host, timeout=timeout,
                                                              perform_checks=perform_checks, need_status=False))
                        break
                    else:
                        raise ScalersException('HA group({0}) is unreachable.'.format(','.join(ha_group)))

        self._run_tasks(tasks)

    def stop_async(self, fs=None, resource_type=None, timeout=600, perform_checks=False):
        """ Stop all mentioned resources for cluster.
        """

        ha_groups = self.config.ha_settings.ha_groups[:]

        tasks = list()

        for ha_group in ha_groups:
            if get_hostname() in ha_group:
                for res in self.get_resources_list(get_hostname(), fs, resource_type):
                    tasks.append(self.ResourceOperationProcess(self.stop_resource, res, host=get_hostname(),
                                                               timeout=timeout, perform_checks=perform_checks,
                                                               need_status=False))
            else:
                for host in ha_group:
                    if CommandExecutor(StringCommand('uptime')).run(node=host).exit_code == 0:
                        for res in self.get_resources_list(host, fs, resource_type):
                            tasks.append(
                                self.ResourceOperationProcess(self.stop_resource, res, host=host, timeout=timeout,
                                                              perform_checks=perform_checks, need_status=False))
                        break
                    else:
                        raise ScalersException('HA group({0}) is unreachable.'.format(','.join(ha_group)))

        self._run_tasks(tasks)