# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Resource manager for clones resources.
"""

from es.pacemaker.crm.commands.crm_mon import crm_mon
from es.pacemaker.manager.resource_manager import BaseResourceManager
from scalers.errors import ScalersException


class ClonesResourceManager(BaseResourceManager):
    """ Resource manager for clones resources.
    """

    @staticmethod
    def is_resource_active(resource_id, host=None):
        """ Check if clone resource active.
        """

        clones = crm_mon(host)['clones']
        for clone in clones:
            if clone['id'] != resource_id:
                continue
            is_active = False
            for res in clone['resources']:
                resource_active = (res['active'] == 'true')
                if not resource_active:
                    return False
                else:
                    is_active = True
            return is_active
        raise ScalersException('Unable to find clone resource {0} on host {1}'.format(resource_id, host))

    @staticmethod
    def is_resource_non_active(resource_id, host=None):
        """ Check if clone resource non active.
        """

        clones = crm_mon(host)['clones']
        for clone in clones:
            if clone['id'] != resource_id:
                continue
            for res in clone['resources']:
                if res['active'] == 'true':
                    return False
            return True

        raise ScalersException('Unable to find clone resource {0} on host {1}'.format(resource_id, host))

    def get_resources_list(self, host=None, fs=None, resource_type=None):
        """ List all clones resources for given host.
        """

        if resource_type is None:
            # This ignores clones ending with "-client" to skip Hotpools client clone mount
            return [clone['id'] for clone in crm_mon(host)['clones']
                    if not clone['id'].endswith('-client')]
        else:
            return [clone['id'] for clone in crm_mon(host)['clones']
                    if clone['id'].startswith('cl-{0}'.format(resource_type))]
