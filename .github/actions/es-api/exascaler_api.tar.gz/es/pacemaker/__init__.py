# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Pacemaker related EXAScaler API package.
"""

import os
import re
from itertools import chain, combinations
from collections import OrderedDict

from es.pacemaker.crm.commands.cib import crm_cib_new, crm_cib_commit, crm_cib_delete
from es.pacemaker.crm.commands.configure import (
    crm_configure_cib_object,
    crm_configure_load_update_cib,
    crm_configure_verify,
)
from es.pacemaker.crm.entities.common.node_pref import NodePref
from es.pacemaker.crm.entities.common.attributes import TaggedAttributesListWithMetaAndRules
from es.pacemaker.crm.entities.common.rule import Rule, SimpleExpressionUnary, SimpleExpressionBinary
from es.pacemaker.crm.entities.clone import Clone
from es.pacemaker.crm.entities.colocation import Colocation
from es.pacemaker.crm.entities.group import Group
from es.pacemaker.crm.entities.location import Location
from es.pacemaker.crm.entities.node import Node
from es.pacemaker.crm.entities.order import Order
from es.pacemaker.crm.entities.property import Property
from es.pacemaker.crm.entities.primitive import Primitive
from es.pacemaker.crm.entities.op_defaults import OpDefaults
from es.pacemaker.crm.entities.rsc_defaults import RscDefaults
from es.pacemaker.crm.entities.rsc_template import RscTemplate
from es.pacemaker.crm.entities.rsc_ticket import RscTicket
from es.lustre.entities.targets_storage import TargetsStorageBuilder
from es.lustre.entities.backbone import get_backbone_device_cls
from scalers.errors import ScalersException
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand


def _get_backbone_device_type(backfs_type, target_type):
    return get_backbone_device_cls(backfs_type, target_type).device_type


class Pacemaker(object):
    """ Base pacemaker entity.
    """

    @classmethod
    def get_version(cls):
        """ Get pacemaker version.
        """

        output = CmdExecutor(StringCommand('cibadmin --query | grep validate-with')).execute(shell=True)
        pacemaker_version_re = re.compile(r'^.*\svalidate-with="pacemaker-(?P<major>\d+).(?P<minor>\d+)"\s.*$')
        match = pacemaker_version_re.match(output)
        if match:
            return int(match.group('major')), int(match.group('minor'))
        else:
            raise ScalersException('Unable to determine pacemaker version.')

    @classmethod
    def cibadmin_force_upgrade(cls):
        """ Run 'cibadmin --upgrade --force'.
        """

        CmdExecutor(StringCommand('cibadmin --upgrade --force')).execute()

    @classmethod
    def print_rules(cls, rules_list):
        """ Print rules.
        :param rules_list: list of pacemaker rules.
        """

        print '\n'.join(str(rule) for rule in rules_list)

    @classmethod
    def save_rules_to_file(cls, rules_list, file_name):
        """ Save rules.
        :param file_name: file to save
        :param rules_list: list of pacemaker rules.
        """

        with open(file_name, 'w') as f:
            for rule in rules_list:
                f.write('{0}\n'.format(rule))

    @classmethod
    def create_shadow_cib(cls):
        """ Create shadow cib.
        """

        crm_cib_new('updates')

    @classmethod
    def commit_shadow_cib(cls):
        """ Apply shadow cib.
        """

        crm_configure_verify()
        crm_cib_commit('updates')
        crm_cib_delete('updates')

    @classmethod
    def load_cib_to_shadow_config(cls, cib):
        """ Load a single cib file into the shadow cib.
        """

        os.environ['CIB_shadow'] = 'updates'
        crm_configure_load_update_cib(cib)
        del os.environ['CIB_shadow']

    @classmethod
    def disable_stonith(cls):
        """ Disable stonith.
        """

        stonith_enabled_property = Property()
        stonith_enabled_property.add_attribute('stonith-enabled', 'false')
        crm_configure_cib_object(stonith_enabled_property)


class EXAScalerPacemaker(Pacemaker):
    """ EXAScaler pacemaker entity.
    """

    def __init__(self, exascaler_config):
        """ Basic initialization.
        """

        self._es_config = exascaler_config
        self._targets_storage_builder = TargetsStorageBuilder(self._es_config)
        self.generate_simple_clone_rules = False
        self.generate_multirail_clone_rules = False
        self._lnet_groups = {}

        for fs in self._es_config.global_settings.fs_list:
            self._lnet_groups[fs] = self._generate_fs_target_lnet_groups(fs)
            if len(self._es_config.fs_settings[fs].ost_lnet_list) > 0:
                self.generate_multirail_clone_rules = True
            else:
                self.generate_simple_clone_rules = True

    def _generate_fs_target_lnet_groups(self, fs):
        """ Generate groups of targets by lnets via which they are accessible.
        """

        _hosts = self._es_config.fs_settings[fs].ost_list.iterkeys()
        _lnets = sorted(set(chain.from_iterable(self._es_config.hosts_settings[h].lnet_members.keys() for h in _hosts)))
        ignored_group_name = '-'.join(_lnets)  # Targets accessible via all lnets should be ignored

        lnets_data = OrderedDict(sorted((k, set(v)) for (k, v) in self._es_config.fs_settings[fs].ost_lnet_list.iteritems()))
        lnet_groups = dict()
        for lnet_group_size in xrange(len(lnets_data), 0, -1):
            for group_lnets in combinations(lnets_data.iteritems(), lnet_group_size):
                group_targets = frozenset(reduce((lambda s1, s2: s1 & s2), (v for (k, v) in group_lnets)))
                if group_targets:
                    for lnet_name in lnets_data:
                        lnets_data[lnet_name].difference_update(group_targets)
                    group_name = '-'.join(k for (k, v) in group_lnets)
                    if group_name != ignored_group_name:
                        lnet_groups[group_name] = sorted(group_targets)
        return lnet_groups

    def generate_stonith_rules(self, host_name):
        """ Generate stonith related pacemaker rules for specified host.
        :param host_name: host name.
        """

        rules = list()

        ha_group_idx = self._es_config.hosts_settings[host_name].ha_group_idx

        for host in self._es_config.ha_settings.ha_groups[ha_group_idx]:

            stonith_type = self._es_config.hosts_settings[host].stonith_type

            if stonith_type in ('ipmi', 'ipmi-slow'):

                primitive = Primitive('stonith-{0}'.format(host), 'fence_ipmilan')
                primitive.cls = 'stonith'
                params = TaggedAttributesListWithMetaAndRules('params')
                params.add_attribute('pcmk_host_list', host)
                params.add_attribute('ipaddr', self._es_config.hosts_settings[host].nics['ipmi'].ip)
                params.add_attribute('login', self._es_config.hosts_settings[host].stonith_user)
                params.add_attribute('passwd', self._es_config.hosts_settings[host].stonith_pass)
                params.add_attribute('lanplus', 'true')
                params.add_attribute('auth', 'md5')
                params.add_attribute('power_wait', self._es_config.hosts_settings[host].ipmi_power_wait)
                params.add_attribute('method', self._es_config.hosts_settings[host].ipmi_method)
                params.add_attribute('delay', self._es_config.hosts_settings[host].ipmi_delay)
                params.add_attribute('privlvl', 'OPERATOR')
                params.add_attribute('pcmk_host_check', 'static-list')
                primitive.add_params(params)
                primitive.add_op('monitor', interval=self._es_config.hosts_settings[host].ipmi_monitor, timeout=240)
                primitive.meta.add_attribute('priority', 9000)
                primitive.meta.add_attribute('failure-timeout', 20)

            elif stonith_type == 'sfa10ke':

                primitive = Primitive('stonith-{0}'.format(host), 'fence_ddn_sfa10ke')
                primitive.cls = 'stonith'
                params = TaggedAttributesListWithMetaAndRules('params')
                params.add_attribute('pcmk_host_list', host)
                params.add_attribute('targetvm', host)
                params.add_attribute('pcmk_host_check', 'static-list')
                primitive.add_params(params)
                primitive.add_op('monitor', interval=20, timeout=20)
                primitive.meta.add_attribute('failure-timeout', 20)

            elif stonith_type == 'sfa_vm':

                sfa = self._es_config.hosts_settings[host].host_sfa_list[0]
                sfa_list = self._es_config.sfa_settings[sfa].controllers

                primitive = Primitive('stonith-{0}'.format(host), 'fence_sfa_vm')
                primitive.cls = 'stonith'
                params = TaggedAttributesListWithMetaAndRules('params')
                params.add_attribute('pcmk_host_list', host)
                params.add_attribute('targetvm', host)
                params.add_attribute('ip_addr', sfa_list[0])
                if len(sfa_list) > 1:
                    params.add_attribute('alt_ip_addr', sfa_list[1])
                if self._es_config.global_settings.password_policy == 'plain-text':
                    params.add_attribute('passwd', self._es_config.hosts_settings[host].stonith_pass)
                params.add_attribute('pcmk_host_check', 'static-list')
                primitive.add_params(params)
                primitive.add_op('monitor', interval=20, timeout=20)
                primitive.meta.add_attribute('failure-timeout', 20)

            elif stonith_type == 'ssh':

                primitive = Primitive('stonith-{0}'.format(host), 'fence_ddn_ssh')
                primitive.cls = 'stonith'
                params = TaggedAttributesListWithMetaAndRules('params')
                params.add_attribute('ip_addr', host)
                params.add_attribute('pcmk_host_list', host)
                params.add_attribute('pcmk_host_argument', 'none')
                primitive.add_params(params)
                primitive.add_op('monitor', interval=20, timeout=240)
                primitive.meta.add_attribute('failure-timeout', 20)

            else:
                continue

            rules.append(primitive)

            for run_host in self._es_config.ha_group_list(host):

                score = '100'

                if (len(self._es_config.hosts_settings[host].stonith_primary_peers) > 0) or \
                        (len(self._es_config.hosts_settings[host].stonith_secondary_peers) > 0):
                    score = '-inf'

                if run_host in self._es_config.hosts_settings[host].stonith_primary_peers:
                    score = '100'

                if run_host in self._es_config.hosts_settings[host].stonith_secondary_peers:
                    score = '90'

                if run_host == host:
                    score = '-inf'

                location = Location()
                location.id = 'location-stonith-{0}.{1}'.format(host, run_host)
                location.resource = 'stonith-{0}'.format(host)
                location.node_pref = NodePref(score, run_host)

                rules.append(location)

        return rules

    def generate_attributes_rules(self, host_name):
        """ Generate node attributes.
        """

        rules = list()

        ha_group_idx = self._es_config.hosts_settings[host_name].ha_group_idx

        for host in self._es_config.ha_settings.ha_groups[ha_group_idx]:

            node = Node(host)
            if (self._es_config.hosts_settings[host].stonith_type in ('sfa10ke', 'sfa_vm')) or (
                        self._es_config.hosts_settings[host].oid is not None):
                node.attributes.add_attribute('system-type', 'embedded')
            else:
                node.attributes.add_attribute('system-type', 'block')

            node.attributes.add_attribute('standby', 'off')

            netmap_keys = list()
            if self.generate_simple_clone_rules:
                if self._es_config.global_settings.lnet_mr_fault_sensitive:
                    for element in self._es_config.hosts_settings[host].host_lnets():
                        netmap_keys.append('lnet-{0}={1}'.format(element[1], element[0]))
                else:
                    netmap_keys.append('lnet-{0}={1}'.format(
                        '-'.join([element[1] for element in self._es_config.hosts_settings[host].host_lnets()]),
                        ','.join([element[0] for element in self._es_config.hosts_settings[host].host_lnets()])))

            if self.generate_multirail_clone_rules:
                for element in self._es_config.hosts_settings[host].host_lnets():
                    netmap_keys.append('lnet-{0}={1}'.format(element[1], element[0]))

            node.attributes.add_attribute('netmap', '"{0}"'.format(';'.join(netmap_keys)))

            rules.append(node)

        return rules

    def generate_cluster_rules(self, host_name):
        """ Generate common cluster rules.
        """

        rules = list()

        op_defaults = OpDefaults()
        op_defaults.id = 'op-options'
        op_defaults.add_attribute('record-pending', 'false')
        rules.append(op_defaults)

        rsc_defaults = RscDefaults()
        rsc_defaults.id = 'rsc_options'
        rsc_defaults.options.add_attribute('allow-migrate', 'false')
        rsc_defaults.options.add_attribute('failure-timeout', '30m')
        rsc_defaults.options.add_attribute('migration-threshold', 'INFINITY')
        rsc_defaults.options.add_attribute('multiple-active', 'stop_start')
        rsc_defaults.options.add_attribute('priority', '0')
        rsc_defaults.options.add_attribute('resource-stickiness', '0')
        rules.append(rsc_defaults)

        cib_bootstrap_options = Property()
        cib_bootstrap_options.id = 'cib-bootstrap-options'
        cib_bootstrap_options.add_attribute('batch-limit', '16')
        cib_bootstrap_options.add_attribute('dc-deadtime', '20s')
        cib_bootstrap_options.add_attribute('cluster-infrastructure', 'corosync')
        cib_bootstrap_options.add_attribute('cluster-recheck-interval', '1m')
        cib_bootstrap_options.add_attribute('maintenance-mode', 'false')
        cib_bootstrap_options.add_attribute('no-quorum-policy', self._es_config.ha_settings.no_quorum_policy)
        cib_bootstrap_options.add_attribute('node-action-limit', '4')
        cib_bootstrap_options.add_attribute('placement-strategy', 'default')
        cib_bootstrap_options.add_attribute('stop-all-resources', 'false')
        cib_bootstrap_options.add_attribute('symmetric-cluster', 'true')
        cib_bootstrap_options.add_attribute('stonith-timeout', '{0}s'.
                                            format(self._es_config.ha_settings.stonith_timeout))
        if (self._es_config.hosts_settings[host_name].stonith_type is None) or (
                    self._es_config.hosts_settings[host_name].stonith_type == 'none'):
            cib_bootstrap_options.add_attribute('stonith-enabled', 'false')
        else:
            cib_bootstrap_options.add_attribute('stonith-enabled', 'true')
        # cib_bootstrap_options.add_attribute('stonith-watchdog-timeout', '120')
        rules.append(cib_bootstrap_options)

        return rules

    def generate_clones_rules(self, host_name):
        """ Generate rules for cloned resources.
        """

        rules = list()
        if self._es_config.global_settings.pingd:
            rules.extend(self._generate_ifspeed_ping_rules(host_name))
        rules.extend(self._generate_sfa_home_vd_rules())
        if 'zfs' in self._es_config.global_settings.used_backfs_types:
            rules.extend(self._generate_multipathd_rules())
        return list(set([rule.__str__() for rule in rules]))

    def generate_esui_rules(self, host_name):
        """ Generate rules for ES UI docker resources.
        """

        rules = list()

        if self._es_config.esui_settings is None or not self._es_config.esui_settings.enabled:
            return rules

        group = Group('esui-docker-grp')

        primitive = Primitive('esui-ip', 'IPaddr2')
        primitive.cls = 'ocf'
        primitive.provider = 'heartbeat'
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('ip', self._es_config.esui_settings.ip)
        if self._es_config.esui_settings.nic:
            params.add_attribute('nic', self._es_config.esui_settings.nic)
        if self._es_config.esui_settings.cidr:
            params.add_attribute('cidr_netmask', self._es_config.esui_settings.cidr)
        primitive.add_params(params)
        primitive.add_op('monitor', timeout=30, interval=30)
        rules.append(primitive)
        group.add_resource(primitive.resource)

        primitive = Primitive('esui-fs', 'Filesystem')
        primitive.cls = 'ocf'
        primitive.provider = 'heartbeat'
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('device', '"%s"' % self._targets_storage_builder.mgs.ui_device.path)
        params.add_attribute('directory', '/ui_data')
        params.add_attribute('fstype', 'ext4')
        primitive.add_params(params)
        primitive.add_op('monitor', timeout=60, interval=30)
        rules.append(primitive)
        group.add_resource(primitive.resource)

        primitive = Primitive('docker', 'docker.service')
        primitive.cls = 'systemd'
        primitive.add_op('start', timeout=120, interval=0)
        primitive.add_op('stop', timeout=120, interval=0)
        primitive.add_op('monitor', timeout=120, interval=30)
        rules.append(primitive)
        group.add_resource(primitive.resource)

        primitive = Primitive('esui-docker', 'iml-docker.service')
        primitive.cls = 'systemd'
        primitive.add_op('start', timeout=900, interval=0)
        primitive.add_op('stop', timeout=360, interval=0)
        primitive.add_op('monitor', timeout=120, interval=60)
        rules.append(primitive)
        group.add_resource(primitive.resource)

        # group in stopped state?
        rules.append(group)

        colocation = Colocation()
        colocation.id = 'esui-docker-with-mgs-vg'
        colocation.score = 'inf'
        colocation.add_resource('esui-docker-grp')
        colocation.add_resource('mgs-vg')
        rules.append(colocation)

        order = Order()
        order.id = 'esui-docker-after-mgs-vg'
        order.score = 'inf'
        order.add_resource('mgs-vg')
        order.add_resource('esui-docker-grp')
        rules.append(order)

        return rules

    def generate_lustre_rules(self, host_name):
        """ Generate rules for lustre resources.
        """

        rules = list()

        rules.extend(self._generate_lustre_rules(host_name))

        if self._es_config.ha_settings.ha_group_count == 1:

            for fs in self._es_config.global_settings.fs_list:
                rules.extend(self._generate_fs_specific_lustre_rules(fs, True))
            rules.extend(self._generate_mgs_rules(host_name))

            rules.append(self._generate_mdt_prefer_master_node_location())
            rules.append(self._generate_mdt_prefer_home_node_location())
            for backfs in self._es_config.global_settings.used_backfs_types:
                rules.append(self._generate_ost_prefer_master_node_location(backfs))
                rules.append(self._generate_ost_prefer_home_node_location(backfs))

            for fs in self._es_config.global_settings.fs_list:
                rules.extend(self._generate_mdt_rules(fs, host_name, True))
            for fs in self._es_config.global_settings.fs_list:
                rules.extend(self._generate_ost_rules(fs, host_name, True, True))
            rules.extend(self._generate_mdt_require_home_zone_location())
            rules.extend(self._generate_ost_require_home_zone_location())
        else:

            global_mdt_exists = False
            global_ost_exists = False

            ha_group_idx = self._es_config.hosts_settings[host_name].ha_group_idx
            ha_group = self._es_config.ha_settings.ha_groups[ha_group_idx]

            for fs in self._es_config.global_settings.fs_list:
                mgs_exists = False
                mdt_exists = False
                ost_exists = False

                for host in ha_group:
                    if host in self._es_config.fs_settings[fs].mgs_list:
                        mgs_exists = True

                    if host in self._es_config.fs_settings[fs].mds_list:
                        mdt_exists = True
                    if host in self._es_config.fs_settings[fs].oss_list:
                        ost_exists = True

                if mgs_exists:
                    rules.extend(self._generate_mgs_rules(host_name))
                if mgs_exists or mdt_exists or ost_exists:
                    rules.extend(self._generate_fs_specific_lustre_rules(fs, mgs_exists))
                if mdt_exists:
                    rules.extend(self._generate_mdt_rules(fs, host_name, mgs_exists))
                    global_mdt_exists = True
                if ost_exists:
                    rules.extend(self._generate_ost_rules(fs, host_name, mgs_exists, mdt_exists))
                    global_ost_exists = True

            if global_mdt_exists:
                rules.append(self._generate_mdt_prefer_master_node_location())
                rules.append(self._generate_mdt_prefer_home_node_location())
                rules.extend(self._generate_mdt_require_home_zone_location())
            if global_ost_exists:
                for backfs in self._es_config.global_settings.used_backfs_types:
                    rules.append(self._generate_ost_prefer_master_node_location(backfs))
                    rules.append(self._generate_ost_prefer_home_node_location(backfs))
                rules.extend(self._generate_ost_require_home_zone_location())
        return rules

    def __generate_ifspeed_ping_rules(self, netmap_key, lnet_list_key):
        """ Generate ifspeed and ping related rules.
        """

        rules = list()

        ifspeed_primitive = Primitive('ifspeed-{0}'.format(netmap_key), 'ifspeed')
        ifspeed_primitive.cls = 'ocf'
        ifspeed_primitive.provider = 'ddn'
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('name', '"ifspeed-{0}"'.format(netmap_key))
        params.add_attribute('netmap_key', '"{0}"'.format(netmap_key))
        params.add_attribute('dampen', str(self._es_config.ha_settings.dampen_ifspeed))
        ifspeed_primitive.add_params(params)
        ifspeed_primitive.add_op('monitor', interval='10', timeout='60', on_fail='ignore')
        ifspeed_primitive.add_op('start', interval='0', timeout='60')
        ifspeed_primitive.add_op('stop', interval='0', timeout='60')
        rules.append(ifspeed_primitive)

        ifspeed_clone = Clone('cl-ifspeed-{0}'.format(netmap_key), 'ifspeed-{0}'.format(netmap_key))
        ifspeed_clone.meta.add_attribute('priority', '400')
        ifspeed_clone.meta.add_attribute('interleave', 'true')
        rules.append(ifspeed_clone)

        ping_primitive = Primitive('ping-{0}'.format(netmap_key), 'lnet-ping')
        ping_primitive.cls = 'ocf'
        ping_primitive.provider = 'ddn'
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('name', '"ping-{0}"'.format(netmap_key))
        params.add_attribute('lnet_list', '"{0}"'.format(lnet_list_key))
        params.add_attribute('multiplier', '1000')
        params.add_attribute('timeout', '2')
        params.add_attribute('dampen', str(self._es_config.ha_settings.dampen_ping))
        ping_primitive.add_params(params)
        ping_primitive.add_op('monitor', interval='10', timeout='60', on_fail='ignore')
        ping_primitive.add_op('start', interval='0', timeout='60')
        ping_primitive.add_op('stop', interval='0', timeout='60')
        rules.append(ping_primitive)

        ping_clone = Clone('cl-ping-{0}'.format(netmap_key), 'ping-{0}'.format(netmap_key))
        ping_clone.meta.add_attribute('priority', '400')
        ping_clone.meta.add_attribute('interleave', 'true')
        rules.append(ping_clone)

        return list(set([rule.__str__() for rule in rules]))

    def _generate_ifspeed_ping_rules(self, host_name):
        """ Generate ifspeed and ping related rules.
        """

        rules = list()

        if self.generate_simple_clone_rules:

            if self._es_config.global_settings.lnet_mr_fault_sensitive:
                for lnet in (element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()):
                    netmap_key = 'lnet-{0}'.format(lnet)
                    lnet_list_key = lnet
                    rules.extend(self.__generate_ifspeed_ping_rules(netmap_key, lnet_list_key))
            else:
                netmap_key = 'lnet-{0}'.format(
                    '-'.join([element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()]))

                lnet_list_key = ','.join(self._es_config.hosts_settings[host_name].lnet_members.keys())

                rules.extend(self.__generate_ifspeed_ping_rules(netmap_key, lnet_list_key))

        if self.generate_multirail_clone_rules:
            for lnet in (element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()):
                netmap_key = 'lnet-{0}'.format(lnet)
                lnet_list_key = lnet
                rules.extend(self.__generate_ifspeed_ping_rules(netmap_key, lnet_list_key))

        return list(set([rule.__str__() for rule in rules]))

    @classmethod
    def _generate_sfa_home_vd_rules(cls):
        """ Generate rules for sfa_home_vd resource agent.
        """

        rules = list()

        primitive = Primitive('sfa-home-vd', 'sfa-home-vd')
        primitive.cls = 'ocf'
        primitive.provider = 'ddn'
        primitive.add_op('monitor', interval='3600', timeout='300', on_fail='ignore')
        primitive.add_op('start', interval='0', timeout='300')
        primitive.add_op('stop', interval='0', timeout='300')
        params1 = TaggedAttributesListWithMetaAndRules('params')
        params1.score = 3
        rule1 = Rule()
        seu = SimpleExpressionUnary()
        seu.attribute = 'system-type'
        seu.unary_op = 'defined'
        seb = SimpleExpressionBinary()
        seb.attribute = 'system-type'
        seb.binary_op = 'eq'
        seb.value = 'block'
        rule1.expression.add_simple_expression(seu)
        rule1.expression.add_bool_operator('and')
        rule1.expression.add_simple_expression(seb)
        params1.rules.append(rule1)
        params1.add_attribute('system_type', 'block')
        primitive.add_params(params1)
        params2 = TaggedAttributesListWithMetaAndRules('params')
        params2.score = 2
        rule2 = Rule()
        seu = SimpleExpressionUnary()
        seu.attribute = 'system-type'
        seu.unary_op = 'defined'
        seb = SimpleExpressionBinary()
        seb.attribute = 'system-type'
        seb.binary_op = 'eq'
        seb.value = 'embedded'
        rule2.expression.add_simple_expression(seu)
        rule2.expression.add_bool_operator('and')
        rule2.expression.add_simple_expression(seb)
        params2.rules.append(rule2)
        params2.add_attribute('system_type', 'embedded')
        primitive.add_params(params2)
        params3 = TaggedAttributesListWithMetaAndRules('params')
        params3.score = 1
        params3.add_attribute('system_type', 'invalid')
        primitive.add_params(params3)
        rules.append(primitive)

        clone = Clone('cl-sfa-home-vd', 'sfa-home-vd')
        clone.meta.add_attribute('priority', '410')
        clone.meta.add_attribute('interleave', 'true')
        rules.append(clone)

        return rules

    @classmethod
    def _generate_multipathd_rules(cls):
        """ Generate rules for eszfs-mpath resource agent.
        """

        rules = list()

        primitive = Primitive('multipathd', 'systemd-resource')
        primitive.cls = 'ocf'
        primitive.provider = 'ddn'
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('service', 'multipathd')
        params.add_attribute('process_name', 'multipathd')
        primitive.add_params(params)
        primitive.add_op('monitor', interval='30', timeout='15')
        primitive.add_op('start', interval='0', timeout='20')
        primitive.add_op('stop', interval='0', timeout='60')
        rules.append(primitive)

        clone = Clone('cl-multipathd', 'multipathd')
        clone.meta.add_attribute('priority', '460')
        clone.meta.add_attribute('interleave', 'true')
        rules.append(clone)

        return rules

    @staticmethod
    def _generate_fs_specific_lustre_rules(fs, mgs_exists):
        """ Generate Lustre related rules specific for given filesystem.
        """

        rules = list()

        primitive = Primitive(fs, 'Ticketer')
        primitive.cls = 'ocf'
        primitive.provider = 'ddn'
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('name', '{0}-allocated'.format(fs))
        primitive.add_params(params)
        primitive.add_op('start', timeout=30, interval=0)
        primitive.add_op('stop', timeout=30, interval=0)
        primitive.add_op('monitor', timeout=30, interval=30)
        primitive.meta.add_attribute('priority', 299)
        primitive.meta.add_attribute('allow-migrate', 'true')
        primitive.meta.add_attribute('target-role', 'Stopped')
        rules.append(primitive)

        if mgs_exists:
            order = Order()
            order.id = '{0}-after-mgs'.format(fs)
            order.score = 0
            order.add_resource('mgs', 'start')
            order.add_resource(fs, 'start')
            rules.append(order)

        rsc_ticket = RscTicket()
        rsc_ticket.id = 'ticket-lustre-allocated-{0}'.format(fs)
        rsc_ticket.ticket_id = 'lustre-allocated'
        rsc_ticket.add_resource(fs)
        rsc_ticket.loss_policy = 'stop'
        rules.append(rsc_ticket)

        location = Location()
        location.id = '{0}-placement'.format(fs)
        location.resource = fs
        location.resource_discovery_attribute = 'never'
        rule = Rule()
        rule.score = '-inf'
        seb = SimpleExpressionBinary()
        seb.attribute = '#kind'
        seb.binary_op = 'ne'
        seb.value = 'cluster'
        rule.expression.add_simple_expression(seb)
        location.add_rule(rule)
        rules.append(location)

        location_prefer = Location()
        location_prefer.id = '{0}-prefer-block'.format(fs)
        location_prefer.resource = fs
        rule = Rule()
        rule.score = '100'
        seu = SimpleExpressionUnary()
        seu.attribute = 'system-type'
        seu.unary_op = 'defined'
        seb = SimpleExpressionBinary()
        seb.attribute = 'system-type'
        seb.binary_op = 'eq'
        seb.value = 'block'
        rule.expression.add_simple_expression(seu)
        rule.expression.add_bool_operator('and')
        rule.expression.add_simple_expression(seb)
        location_prefer.add_rule(rule)
        rules.append(location_prefer)

        return rules

    def _generate_lustre_rules(self, host_name):
        """ Generate Lustre related rules.
        """

        rules = list()

        ha_group_idx = self._es_config.hosts_settings[host_name].ha_group_idx

        for host in self._es_config.ha_settings.ha_groups[ha_group_idx]:

            node = Node(host)
            local_targets = self._targets_storage_builder.create_local_storage(host=host).target_list
            failover_targets = self._targets_storage_builder.create_failover_storage(host=host).target_list

            if not self._es_config.hosts_settings[host].host_sfa_list:
                node.attributes.add_attribute('zone', 'default')
            else:
                for sfa in self._es_config.hosts_settings[host].host_sfa_list:
                    node.attributes.add_attribute('zone', sfa)

            for target in local_targets + failover_targets:
                if target.type == 'mgs':
                    node.attributes.add_attribute('mgs-placement', 'true')
                elif target.type == 'mdt':
                    node.attributes.add_attribute('mdt-{0}-placement'.format(target.fs), 'true')
                elif target.type == 'ost':
                    if self._lnet_groups[target.fs]:
                        target_lnet = None

                        for lnet, indexes in self._lnet_groups[target.fs].iteritems():
                            if target.idx in indexes:
                                target_lnet = lnet
                                break

                        if target_lnet is None:
                            raise ScalersException('Ost with index {0} was not mentioned in'
                                                   ' ost_lnet_list for filesystem {1}'.format(target.idx, target.fs))
                        node.attributes.add_attribute('ost-{0}-{1}-placement'.format(target.fs, target_lnet), 'true')
                    else:
                        node.attributes.add_attribute('ost-{0}-placement'.format(target.fs), 'true')

            rules.append(node)

        primitive = Primitive('lustre', 'Ticketer')
        primitive.cls = 'ocf'
        primitive.provider = 'ddn'
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('name', 'lustre-allocated')
        primitive.add_params(params)
        primitive.add_op('start', timeout=30, interval=0)
        primitive.add_op('stop', timeout=30, interval=0)
        primitive.add_op('monitor', timeout=30, interval=30)
        primitive.meta.add_attribute('priority', 399)
        primitive.meta.add_attribute('allow-migrate', 'true')
        primitive.meta.add_attribute('target-role', 'Stopped')
        rules.append(primitive)

        location = Location()
        location.id = 'lustre-placement'
        location.resource = 'lustre'
        location.resource_discovery_attribute = 'never'
        rule = Rule()
        rule.score = '-inf'
        seb = SimpleExpressionBinary()
        seb.attribute = '#kind'
        seb.binary_op = 'ne'
        seb.value = 'cluster'
        rule.expression.add_simple_expression(seb)
        location.add_rule(rule)
        rules.append(location)

        location_prefer = Location()
        location_prefer.id = 'lustre-prefer-block'
        location_prefer.resource = 'lustre'
        rule = Rule()
        rule.score = '100'
        seu = SimpleExpressionUnary()
        seu.attribute = 'system-type'
        seu.unary_op = 'defined'
        seb = SimpleExpressionBinary()
        seb.attribute = 'system-type'
        seb.binary_op = 'eq'
        seb.value = 'block'
        rule.expression.add_simple_expression(seu)
        rule.expression.add_bool_operator('and')
        rule.expression.add_simple_expression(seb)
        location_prefer.add_rule(rule)
        rules.append(location_prefer)

        return rules

    def _generate_mdt_backbone_dev_template(self, fs, options=None):
        backfs_type = self._es_config.fs_settings[fs].backfs
        if backfs_type == 'ldiskfs':
            return self._generate_mdt_vg_template(fs)
        elif backfs_type == 'zfs':
            return self._generate_mdt_zpool_template(fs, options)

    @staticmethod
    def _generate_mdt_vg_template(fs):
        """ Generate MDT resource vg template.
        """

        vg_template = RscTemplate('lustre-{0}-mdt-vg'.format(fs), 'LVM')
        vg_template.cls = 'ocf'
        vg_template.provider = 'heartbeat'
        vg_template.params.add_attribute('exclusive', 'true')
        vg_template.params.add_attribute('tag', 'exascaler')
        vg_template.add_op('start', **{'timeout': 120, 'interval': 0, 'record-pending': 'true'})
        vg_template.add_op('stop', **{'timeout': 120, 'interval': 0, 'record-pending': 'true'})
        vg_template.add_op('monitor', **{'timeout': 60, 'interval': 60})
        vg_template.meta.add_attribute('priority', 101)
        return vg_template

    def _generate_mdt_zpool_template(self, fs, options=None):
        """ Generate MDT resource vg template.
        """

        zpool_template = RscTemplate('lustre-{0}-mdt-zpool'.format(fs), 'zpool')
        zpool_template.cls = 'ocf'
        zpool_template.provider = 'ddn'
        if options is not None:
            zpool_template.params.add_attribute('importargs', options)
        zpool_template.add_op('start', **{'timeout': 120, 'interval': 0, 'record-pending': 'true'})
        zpool_template.add_op('stop', **{'timeout': 120, 'interval': 0, 'record-pending': 'true'})
        zpool_template.add_op(
            'monitor', **{'timeout': self._es_config.ha_settings.zpool_monitor_timeout, 'interval': 60})
        zpool_template.meta.add_attribute('priority', 101)
        return zpool_template

    def _generate_mdt_template(self, fs, options=None):
        """ Generate MDT resource template.
        """

        backfs_type = self._es_config.fs_settings[fs].backfs
        lustre_resource_type = 'mdt' if backfs_type == 'zfs' else 'ddn'

        template = RscTemplate('lustre-{0}-mdt'.format(fs), 'lustre-server')
        template.cls = 'ocf'
        template.provider = 'ddn'
        template.params.add_attribute('lustre_resource_type', lustre_resource_type)
        template.params.add_attribute('manage_directory', '1')
        if options is not None:
            template.params.add_attribute('options', options)
        template.utilization.add_attribute('lustre-object', '1')
        template.add_op('start', **{'timeout': self._es_config.ha_settings.lustre_start_timeout,
                                    'interval': 0, 'record-pending': 'true'})
        template.add_op('stop', **{'timeout': 300, 'interval': 0, 'record-pending': 'true'})
        template.add_op('monitor', **{'timeout': 300, 'interval': 30})
        template.meta.add_attribute('priority', 100)
        return template

    def _generate_mdt_backbone_dev_location(self, fs):
        """ Generate MDT resource vg location.
        """

        backbone_dev_type = _get_backbone_device_type(
            self._es_config.fs_settings[fs].backfs,
            'mdt'
        )

        dev_location = Location()
        dev_location.id = 'mdt-{0}-{1}-placement'.format(fs, backbone_dev_type)
        dev_location.resource = 'lustre-{0}-mdt-{1}'.format(fs, backbone_dev_type)
        dev_location.resource_discovery_attribute = 'never'
        rule = Rule()
        rule.score = '-inf'
        seu = SimpleExpressionUnary()
        seu.attribute = 'mdt-{0}-placement'.format(fs)
        seu.unary_op = 'not_defined'
        seb = SimpleExpressionBinary()
        seb.attribute = 'mdt-{0}-placement'.format(fs)
        seb.binary_op = 'ne'
        seb.value = 'true'
        rule.expression.add_simple_expression(seu)
        rule.expression.add_bool_operator('or')
        rule.expression.add_simple_expression(seb)
        dev_location.add_rule(rule)
        return dev_location

    @staticmethod
    def _generate_ost_zpool_template(fs, config, options=None):
        """ Generate MDT resource zpool template.
        """

        zpool_template = RscTemplate('lustre-{0}-ost-zpool'.format(fs), 'zpool')
        zpool_template.cls = 'ocf'
        zpool_template.provider = 'ddn'
        if options is not None:
            zpool_template.params.add_attribute('importargs', options)
        zpool_template.add_op('start', **{'timeout': 120, 'interval': 0, 'record-pending': 'true'})
        zpool_template.add_op('stop', **{'timeout': 120, 'interval': 0, 'record-pending': 'true'})
        zpool_template.add_op('monitor', **{'timeout': config.ha_settings.zpool_monitor_timeout, 'interval': 60})
        zpool_template.meta.add_attribute('priority', 101)
        return zpool_template

    @staticmethod
    def _generate_ost_zpool_location(fs):
        """ Generate OST resource zpool location.
        """

        zpool_location = Location()
        zpool_location.id = 'ost-{0}-zpool-placement'.format(fs)
        zpool_location.resource = 'lustre-{0}-ost-zpool'.format(fs)
        zpool_location.resource_discovery_attribute = 'never'
        rule = Rule()
        rule.score = '-inf'
        seu = SimpleExpressionUnary()
        seu.attribute = 'ost-{0}-placement'.format(fs)
        seu.unary_op = 'not_defined'
        seb = SimpleExpressionBinary()
        seb.attribute = 'ost-{0}-placement'.format(fs)
        seb.binary_op = 'ne'
        seb.value = 'true'
        rule.expression.add_simple_expression(seu)
        rule.expression.add_bool_operator('or')
        rule.expression.add_simple_expression(seb)
        zpool_location.add_rule(rule)
        return zpool_location


    @staticmethod
    def _generate_mdt_prefer_master_node_location():
        """ Generate MDT resource preferable location for master node.
        """

        master_location = Location()
        master_location.id = 'mdt-prefer-master-node'
        master_location.resource = '/mdt([[:digit:]]{4})-(.+)-(vg|zpool)/'
        rule = Rule()
        rule.score = 'mdt%1-%2-preference-config'
        seu = SimpleExpressionUnary()
        seu.attribute = 'mdt%1-%2-preference-config'
        seu.unary_op = 'defined'
        rule.expression.add_simple_expression(seu)
        master_location.add_rule(rule)
        return master_location

    @staticmethod
    def _generate_mdt_prefer_home_node_location():
        """ Generate MDT resource preferable location for home node.
        """

        home_location = Location()
        home_location.id = 'mdt-prefer-home-node'
        home_location.resource = '/mdt([[:digit:]]{4})-(.+)-(vg|zpool)/'
        rule = Rule()
        rule.score = 'mdt%1-%2-preference-auto'
        seu = SimpleExpressionUnary()
        seu.attribute = 'mdt%1-%2-preference-auto'
        seu.unary_op = 'defined'
        rule.expression.add_simple_expression(seu)
        home_location.add_rule(rule)
        return home_location

    @staticmethod
    def _generate_mdt_require_home_zone_location():
        """ Generate MDT resource require home zone location.
        """

        rules = list()

        zone_location = Location()
        zone_location.id = 'mdt-require-home-zone'
        zone_location.resource = '/mdt([[:digit:]]{4})-(.+)/'
        rule = Rule()
        rule.score = '-inf'
        seu = SimpleExpressionUnary()
        seu.unary_op = 'not_defined'
        seu.attribute = 'zone'
        seb = SimpleExpressionBinary()
        seb.attribute = 'zone'
        seb.binary_op = 'ne'
        seb.value = 'meta{zone}'
        rule.expression.add_simple_expression(seu)
        rule.expression.add_bool_operator('or')
        rule.expression.add_simple_expression(seb)
        zone_location.add_rule(rule)
        rules.append(zone_location)

        return rules

    @staticmethod
    def __generate_mdt_ifspeed_location(location_id, resource, lnets_str):
        """ Generate MDT resource location for ifspeed.
        """

        honor_ifspeed_location = Location()
        honor_ifspeed_location.id = location_id
        honor_ifspeed_location.resource = resource
        rule = Rule()
        rule.score = 'ifspeed-lnet-{0}'.format(lnets_str)
        seu = SimpleExpressionUnary()
        seu.attribute = 'ifspeed-lnet-{0}'.format(lnets_str)
        seu.unary_op = 'defined'
        rule.expression.add_simple_expression(seu)
        honor_ifspeed_location.add_rule(rule)
        return honor_ifspeed_location

    def _generate_mdt_ifspeed_locations(self, fs, host_name):
        """ Generate MDT resource locations for ifspeed.
        """

        rules = list()
        fs_settings = self._es_config.fs_settings[fs]
        backbone_device_type = _get_backbone_device_type(fs_settings.backfs, 'mdt')

        if fs_settings.ost_lnet_list:
            for element in self._es_config.hosts_settings[host_name].host_lnets():
                lnet = element[1]
                rules.append(self.__generate_mdt_ifspeed_location(
                    'mdt-{0}-{1}-honor-ifspeed-{2}'.format(fs, backbone_device_type, lnet),
                    'lustre-{0}-mdt-{1}'.format(fs, backbone_device_type),
                    lnet))
        else:
            if self._es_config.global_settings.lnet_mr_fault_sensitive:
                for element in self._es_config.hosts_settings[host_name].host_lnets():
                    lnet = element[1]
                    rules.append(self.__generate_mdt_ifspeed_location(
                        'mdt-{0}-{1}-honor-ifspeed-{2}'.format(fs, backbone_device_type, lnet),
                        'lustre-{0}-mdt-{1}'.format(fs, backbone_device_type),
                        lnet))
            else:
                lnets_str = '-'.join([element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()])
                rules.append(self.__generate_mdt_ifspeed_location(
                    'mdt-{0}-{1}-honor-ifspeed'.format(fs, backbone_device_type),
                    'lustre-{0}-mdt-{1}'.format(fs, backbone_device_type),
                    lnets_str))

        return list(set([rule.__str__() for rule in rules]))

    @staticmethod
    def __generate_mdt_ping_location(location_id, resource, lnets_str):
        """ Generate MDT resource location for ping.
        """

        honor_ifspeed_location = Location()
        honor_ifspeed_location.id = location_id
        honor_ifspeed_location.resource = resource
        rule = Rule()
        rule.score = 'ping-lnet-{0}'.format(lnets_str)
        seu = SimpleExpressionUnary()
        seu.attribute = 'ping-lnet-{0}'.format(lnets_str)
        seu.unary_op = 'defined'
        rule.expression.add_simple_expression(seu)
        honor_ifspeed_location.add_rule(rule)
        return honor_ifspeed_location

    def _generate_mdt_ping_locations(self, fs, host_name):
        """ Generate MDT resource locations for ping.
        """

        rules = list()
        fs_settings = self._es_config.fs_settings[fs]
        backbone_device_type = _get_backbone_device_type(fs_settings.backfs, 'mdt')

        if fs_settings.ost_lnet_list:
            for element in self._es_config.hosts_settings[host_name].host_lnets():
                lnet = element[1]
                rules.append(self.__generate_mdt_ping_location(
                    'mdt-{0}-{1}-honor-ping-{2}'.format(fs, backbone_device_type, lnet),
                    'lustre-{0}-mdt-{1}'.format(fs, backbone_device_type),
                    lnet))
        else:
            if self._es_config.global_settings.lnet_mr_fault_sensitive:
                for element in self._es_config.hosts_settings[host_name].host_lnets():
                    lnet = element[1]
                    rules.append(self.__generate_mdt_ping_location(
                        'mdt-{0}-{1}-honor-ping-{2}'.format(fs, backbone_device_type, lnet),
                        'lustre-{0}-mdt-{1}'.format(fs, backbone_device_type),
                        lnet))
            else:
                lnets_str = '-'.join([element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()])
                rules.append(self.__generate_mdt_ping_location(
                    'mdt-{0}-{1}-honor-ping'.format(fs, backbone_device_type),
                    'lustre-{0}-mdt-{1}'.format(fs, backbone_device_type),
                    lnets_str))

        return list(set([rule.__str__() for rule in rules]))

    @staticmethod
    def _generate_mdt_location(fs):
        """ Generate MDT resource location.
        """

        location = Location()
        location.id = 'mdt-{0}-placement'.format(fs)
        location.resource = 'lustre-{0}-mdt'.format(fs)
        location.resource_discovery_attribute = 'never'
        rule = Rule()
        rule.score = '-inf'
        seu = SimpleExpressionUnary()
        seu.attribute = 'mdt-{0}-placement'.format(fs)
        seu.unary_op = 'not_defined'
        seb = SimpleExpressionBinary()
        seb.attribute = 'mdt-{0}-placement'.format(fs)
        seb.binary_op = 'ne'
        seb.value = 'true'
        rule.expression.add_simple_expression(seu)
        rule.expression.add_bool_operator('or')
        rule.expression.add_simple_expression(seb)
        location.add_rule(rule)
        return location

    @staticmethod
    def _generate_mdt_after_mgs_order(fs):
        """ Generate MDT order related to MGT.
        """

        after_mgs_order = Order()
        after_mgs_order.id = 'mdt-{0}-after-mgs'.format(fs)
        after_mgs_order.score = 0
        after_mgs_order.add_resource('mgs', 'start')
        after_mgs_order.add_resource('lustre-{0}-mdt'.format(fs), 'start')
        return after_mgs_order

    @staticmethod
    def _generate_mdt_after_sfa_home_vd_order(fs):
        """ Generate MDT order related to sfa_home_vd resource agent.
        """

        after_sfa_home_vd = Order()
        after_sfa_home_vd.id = 'mdt-{0}-after_sfa_home_vd'.format(fs)
        after_sfa_home_vd.score = 0
        after_sfa_home_vd.add_resource('cl-sfa-home-vd', 'start')
        after_sfa_home_vd.add_resource('lustre-{0}-mdt'.format(fs), 'start')
        return after_sfa_home_vd

    @staticmethod
    def _generate_mdt_resource_ticket(fs):
        """ Generate MDT resource ticket.
        """

        resource_ticket = RscTicket()
        resource_ticket.id = 'ticket-{0}-allocated-mdt'.format(fs)
        resource_ticket.ticket_id = '{0}-allocated'.format(fs)
        resource_ticket.add_resource('lustre-{0}-mdt'.format(fs))
        resource_ticket.loss_policy = 'stop'
        return resource_ticket

    def _generate_meta_zone_attribute(self, target):
        """Generate a list of meta attributes for zone
        """

        meta_attributes = list()
        sfa_list = self._es_config.hosts_settings[target.primary_host].host_sfa_list
        if not sfa_list:
            meta = TaggedAttributesListWithMetaAndRules('meta')
            meta.add_attribute('zone', 'default')
            meta_attributes.append(meta)
        else:
            for sfa in sfa_list:
                meta = TaggedAttributesListWithMetaAndRules('meta')
                meta.add_attribute('zone', sfa)
                meta_attributes.append(meta)

        return meta_attributes

    def _generate_mdt_target_rules(self, target, fs):
        """ Generate mdt target specific rules.
        """

        rules = list()
        backfs_type = self._es_config.fs_settings[fs].backfs
        backbone_dev_type = target.service_device.device_type

        if target.mgs.fs != fs or target.mgs.standalone:
            backbone_dev_primitive = Primitive(
                'mdt%04d-%s-%s' % (target.idx, fs, backbone_dev_type),
                primitive_template='lustre-{0}-mdt-{1}'.format(fs, backbone_dev_type))
            params = TaggedAttributesListWithMetaAndRules('params')
            if backfs_type == 'ldiskfs':
                params.add_attribute('volgrpname', target.service_device.name)
            elif backfs_type == 'zfs':
                params.add_attribute('pool', target.service_device.name)
                params.add_attribute('importargs', '"-d %s"' % target.service_device.underlying_storage_devices_base_path)
            backbone_dev_primitive.add_params(params)
            for meta in self._generate_meta_zone_attribute(target):
                backbone_dev_primitive.add_params(meta)
            rules.append(backbone_dev_primitive)

        primitive = Primitive('mdt%04d-%s' % (target.idx, fs), primitive_template='lustre-{0}-mdt'.format(fs))
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('device', '"%s"' % target.device.path)
        params.add_attribute('directory', '"/lustre/%s/mdt%04d"' % (fs, target.idx))
        primitive.add_params(params)
        for meta in self._generate_meta_zone_attribute(target):
            primitive.add_params(meta)
        rules.append(primitive)

        order = Order()
        order.id = 'mdt%04d-%s-after-%s' % (target.idx, fs, backbone_dev_type)
        order.score = 'inf'
        if target.mgs.fs == fs and not target.mgs.standalone:
            order.add_resource('mgs-%s' % backbone_dev_type)
        else:
            order.add_resource('mdt%04d-%s-%s' % (target.idx, fs, backbone_dev_type))
        order.add_resource('mdt%04d-%s' % (target.idx, fs))
        rules.append(order)

        colocation = Colocation()
        colocation.id = 'mdt%04d-%s-with-%s' % (target.idx, fs, backbone_dev_type)
        colocation.score = 'inf'
        colocation.add_resource('mdt%04d-%s' % (target.idx, fs))
        if target.mgs.fs == fs and not target.mgs.standalone:
            colocation.add_resource('mgs-%s' % backbone_dev_type)
        else:
            colocation.add_resource('mdt%04d-%s-%s' % (target.idx, fs, backbone_dev_type))
        rules.append(colocation)

        return rules

    def _generate_mdt_prefer_storage_location(self, target, fs):
        """ Generate MDT resource preferable location for storage.
        """

        rules = list()
        sfa_list = self._es_config.hosts_settings[target.primary_host].host_sfa_list

        for sfa in sfa_list:
            storage_location = Location()
            storage_location.id = 'mdt%04d-%s-prefer-storage-%s' % (target.idx, fs, sfa)
            storage_location.resource = 'mdt%04d-%s' % (target.idx, fs)
            rule = Rule()
            rule.score = '-inf'
            seu = SimpleExpressionUnary()
            seu.attribute = sfa
            seu.unary_op = 'not_defined'
            seb = SimpleExpressionBinary()
            seb.attribute = sfa
            seb.binary_op = 'ne'
            seb.value = 'true'
            rule.expression.add_simple_expression(seu)
            rule.expression.add_bool_operator('or')
            rule.expression.add_simple_expression(seb)
            storage_location.add_rule(rule)
            rules.append(storage_location)

        return rules

    def _generate_mdt_rules(self, fs, host_name, mgs_exists):
        """ Generate rules for MDT targets for given filesystem.
        """

        rules = list()
        if not self._es_config.fs_settings[fs].mgs_internal or self._es_config.fs_settings[fs].mgs_standalone:
            rules.append(self._generate_mdt_backbone_dev_template(fs))
        rules.append(self._generate_mdt_template(fs, self._es_config.fs_settings[fs].mdt_mount_opts))
        if not self._es_config.fs_settings[fs].mgs_internal or self._es_config.fs_settings[fs].mgs_standalone:
            rules.append(self._generate_mdt_backbone_dev_location(fs))
        if self._es_config.global_settings.pingd:
            if not self._es_config.fs_settings[fs].mgs_internal or self._es_config.fs_settings[fs].mgs_standalone:
                rules.extend(self._generate_mdt_ifspeed_locations(fs, host_name))
                rules.extend(self._generate_mdt_ping_locations(fs, host_name))
        rules.append(self._generate_mdt_location(fs))
        if mgs_exists:
            rules.append(self._generate_mdt_after_mgs_order(fs))
        rules.append(self._generate_mdt_after_sfa_home_vd_order(fs))
        rules.append(self._generate_mdt_resource_ticket(fs))

        ha_group_idx = self._es_config.hosts_settings[host_name].ha_group_idx

        for host in self._es_config.ha_settings.ha_groups[ha_group_idx]:
            local_targets = self._targets_storage_builder.create_local_storage(host=host, fs=fs).target_list
            for target in local_targets:
                if target.type == 'mdt':
                    rules.extend(self._generate_mdt_target_rules(target, fs))

        if self._es_config.fs_settings[fs].backfs == 'zfs':
            colocation_multipathd = Colocation()
            colocation_multipathd.id = 'lustre-%s-mdt-zpool-with-multipathd' % (fs)
            colocation_multipathd.score = 'inf'
            colocation_multipathd.add_resource('lustre-%s-mdt-zpool' % (fs))
            colocation_multipathd.add_resource('cl-multipathd')
            rules.append(colocation_multipathd)

            order_multipathd = Order()
            order_multipathd.id = 'lustre-%s-mdt-zpool-after-multipathd' % (fs)
            order_multipathd.score = 'inf'
            order_multipathd.add_resource('cl-multipathd')
            order_multipathd.add_resource('lustre-%s-mdt-zpool' % (fs))
            rules.append(order_multipathd)

        return rules

    def _generate_mgs_backbone_dev_primitive(self):
        backfs_type = self._targets_storage_builder.mgs.backfs
        if backfs_type == 'ldiskfs':
            return self._generate_mgs_vg_primitive()
        elif backfs_type == 'zfs':
            return self._generate_mgs_zpool_primitive()

    def _generate_mgs_vg_primitive(self):
        """ Generate MGT resource vg primitive.
        """

        backbone_dev = self._targets_storage_builder.mgs.service_device

        vg_primitive = Primitive('mgs-vg', 'LVM')
        vg_primitive.cls = 'ocf'
        vg_primitive.provider = 'heartbeat'
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('volgrpname', backbone_dev.name)
        params.add_attribute('exclusive', 'true')
        params.add_attribute('tag', 'exascaler')
        vg_primitive.add_params(params)
        vg_primitive.add_op('start', **{'timeout': 120, 'interval': 0, 'record-pending': 'true'})
        vg_primitive.add_op('stop', **{'timeout': 120, 'interval': 0, 'record-pending': 'true'})
        vg_primitive.add_op('monitor', **{'timeout': 60, 'interval': 60})
        vg_primitive.meta.add_attribute('priority', 301)
        return vg_primitive

    def _generate_mgs_zpool_primitive(self):
        """ Generate MGS resource vg primitive.
        """
        backbone_dev = self._targets_storage_builder.mgs.service_device

        zpool_primitive = Primitive('mgs-zpool', 'zpool')
        zpool_primitive.cls = 'ocf'
        zpool_primitive.provider = 'ddn'
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('pool', backbone_dev.name)
        params.add_attribute('importargs', '"-d {0}"'.format(backbone_dev.underlying_storage_devices_base_path))
        zpool_primitive.add_params(params)
        zpool_primitive.add_op('start', **{'timeout': 120, 'interval': 0, 'record-pending': 'true'})
        zpool_primitive.add_op('stop', **{'timeout': 120, 'interval': 0, 'record-pending': 'true'})
        zpool_primitive.add_op('monitor', **{'timeout': self._es_config.ha_settings.zpool_monitor_timeout, 'interval': 60})
        zpool_primitive.meta.add_attribute('priority', 301)
        return zpool_primitive

    def _generate_mgs_backbone_dev_location(self):
        """ Generate MGT resource vg location.
        """

        backbone_dev_type = self._targets_storage_builder.mgs.service_device.device_type

        dev_location = Location()
        dev_location.id = 'mgs-%s-placement' % backbone_dev_type
        dev_location.resource = 'mgs-%s' % backbone_dev_type
        dev_location.resource_discovery_attribute = 'never'
        rule = Rule()
        rule.score = '-inf'
        seu = SimpleExpressionUnary()
        seu.attribute = 'mgs-placement'
        seu.unary_op = 'not_defined'
        seb = SimpleExpressionBinary()
        seb.attribute = 'mgs-placement'
        seb.binary_op = 'ne'
        seb.value = 'true'
        rule.expression.add_simple_expression(seu)
        rule.expression.add_bool_operator('or')
        rule.expression.add_simple_expression(seb)
        dev_location.add_rule(rule)
        return dev_location

    def _generate_mgs_prefer_master_node_location(self):
        """ Generate MGT resource preferable location for master node.
        """

        backbone_dev_type = self._targets_storage_builder.mgs.service_device.device_type

        master_location = Location()
        master_location.id = 'mgs-%s-prefer-master-node' % backbone_dev_type
        master_location.resource = 'mgs-%s' % backbone_dev_type
        rule = Rule()
        rule.score = 'mgs-preference-config'
        seu = SimpleExpressionUnary()
        seu.attribute = 'mgs-preference-config'
        seu.unary_op = 'defined'
        rule.expression.add_simple_expression(seu)
        master_location.add_rule(rule)
        return master_location

    def _generate_mgs_prefer_home_node_location(self):
        """ Generate MGT resource preferable location for home node.
        """

        backbone_dev_type = self._targets_storage_builder.mgs.service_device.device_type

        master_location = Location()
        master_location.id = 'mgs-prefer-home-node'
        master_location.resource = 'mgs-%s' % backbone_dev_type
        rule = Rule()
        rule.score = 'mgs-preference-auto'
        seu = SimpleExpressionUnary()
        seu.attribute = 'mgs-preference-auto'
        seu.unary_op = 'defined'
        rule.expression.add_simple_expression(seu)
        master_location.add_rule(rule)
        return master_location

    def __generate_mgs_ifspeed_location(self, location_id, lnets_str):
        """ Generate MGT resource location for ifspeed.
        """

        backbone_dev_type = self._targets_storage_builder.mgs.service_device.device_type

        honor_ifspeed_location = Location()
        honor_ifspeed_location.id = location_id
        honor_ifspeed_location.resource = 'mgs-%s' % backbone_dev_type
        rule = Rule()
        rule.score = 'ifspeed-lnet-{0}'.format(lnets_str)
        seu = SimpleExpressionUnary()
        seu.attribute = 'ifspeed-lnet-{0}'.format(lnets_str)
        seu.unary_op = 'defined'
        rule.expression.add_simple_expression(seu)
        honor_ifspeed_location.add_rule(rule)
        return honor_ifspeed_location

    def _generate_mgs_ifspeed_locations(self, host_name):
        """ Generate MGT resource locations for ifspeed.
        """

        rules = list()
        backbone_dev_type = self._targets_storage_builder.mgs.service_device.device_type

        if self.generate_multirail_clone_rules:
            for element in self._es_config.hosts_settings[host_name].host_lnets():
                lnet = element[1]
                rules.append(self.__generate_mgs_ifspeed_location(
                    'mgs-{0}-honor-ifspeed-{1}'.format(backbone_dev_type, lnet), lnet))
        else:
            if self._es_config.global_settings.lnet_mr_fault_sensitive:
                for element in self._es_config.hosts_settings[host_name].host_lnets():
                    lnet = element[1]
                    rules.append(self.__generate_mgs_ifspeed_location(
                        'mgs-{0}-honor-ifspeed-{1}'.format(backbone_dev_type, lnet), lnet))
            else:
                lnets_str = '-'.join([element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()])
                rules.append(self.__generate_mgs_ifspeed_location(
                    'mgs-{0}-honor-ifspeed'.format(backbone_dev_type), lnets_str))

        return list(set([rule.__str__() for rule in rules]))

    def __generate_mgs_ping_location(self, location_id, lnets_str):
        """ Generate MGT resource location for ping.
        """

        backbone_dev_type = self._targets_storage_builder.mgs.service_device.device_type

        honor_ifspeed_location = Location()
        honor_ifspeed_location.id = location_id
        honor_ifspeed_location.resource = 'mgs-{0}'.format(backbone_dev_type)
        rule = Rule()
        rule.score = 'ping-lnet-{0}'.format(lnets_str)
        seu = SimpleExpressionUnary()
        seu.attribute = 'ping-lnet-{0}'.format(lnets_str)
        seu.unary_op = 'defined'
        rule.expression.add_simple_expression(seu)
        honor_ifspeed_location.add_rule(rule)
        return honor_ifspeed_location

    def _generate_mgs_ping_locations(self, host_name):
        """ Generate MGT resource locations for ping.
        """

        rules = list()
        backbone_dev_type = self._targets_storage_builder.mgs.service_device.device_type

        if self.generate_multirail_clone_rules:
            for element in self._es_config.hosts_settings[host_name].host_lnets():
                lnet = element[1]
                rules.append(self.__generate_mgs_ifspeed_location(
                    'mgs-{0}-honor-ping-{1}'.format(backbone_dev_type, lnet), lnet))
        else:
            if self._es_config.global_settings.lnet_mr_fault_sensitive:
                for element in self._es_config.hosts_settings[host_name].host_lnets():
                    lnet = element[1]
                    rules.append(self.__generate_mgs_ifspeed_location(
                        'mgs-{0}-honor-ping-{1}'.format(backbone_dev_type, lnet), lnet))
            else:
                lnets_str = '-'.join([element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()])
                rules.append(self.__generate_mgs_ifspeed_location(
                    'mgs-{0}-honor-ping'.format(backbone_dev_type), lnets_str))

        return list(set([rule.__str__() for rule in rules]))

    def _generate_mgs_primitive(self):
        """ Generate MGT resource vg primitive.
        """

        primitive = Primitive('mgs', 'lustre-server')
        primitive.cls = 'ocf'
        primitive.provider = 'ddn'
        params = TaggedAttributesListWithMetaAndRules('params')
        params.add_attribute('device', '"%s"' % self._targets_storage_builder.mgs.device.path)
        params.add_attribute('directory', '"/lustre/mgs"')
        params.add_attribute('lustre_resource_type', 'mgs')
        params.add_attribute('manage_directory', '1')
        params.add_attribute('options', self._targets_storage_builder.mgs.mount_opts)
        primitive.add_params(params)
        primitive.add_op('start', **{'timeout': self._es_config.ha_settings.lustre_start_timeout,
                                     'interval': 0, 'record-pending': 'true'})
        primitive.add_op('stop', **{'timeout': 300, 'interval': 0, 'record-pending': 'true'})
        primitive.add_op('monitor', **{'timeout': 300, 'interval': 60})
        primitive.meta.add_attribute('priority', 300)
        return primitive

    @staticmethod
    def _generate_mgs_placement():
        """ Generate MGT resource placement.
        """

        location = Location()
        location.id = 'mgs-placement'
        location.resource = 'mgs'
        location.resource_discovery_attribute = 'never'
        rule = Rule()
        rule.score = '-inf'
        seu = SimpleExpressionUnary()
        seu.attribute = 'mgs-placement'
        seu.unary_op = 'not_defined'
        seb = SimpleExpressionBinary()
        seb.attribute = 'mgs-placement'
        seb.binary_op = 'ne'
        seb.value = 'true'
        rule.expression.add_simple_expression(seu)
        rule.expression.add_bool_operator('or')
        rule.expression.add_simple_expression(seb)
        location.add_rule(rule)
        return location

    def _generate_mgs_after_backbone_dev_order(self):
        """ Generate MGT resource order after backbone device.
        """

        backbone_dev_type = self._targets_storage_builder.mgs.service_device.device_type

        order = Order()
        order.id = 'mgs-after-%s' % backbone_dev_type
        order.score = 'inf'
        order.add_resource('mgs-%s' % backbone_dev_type)
        order.add_resource('mgs')
        return order

    def _generate_mgs_with_backbone_dev_colocation(self):
        """ Generate MGT resource colocation with backbone device.
        """

        backbone_dev_type = self._targets_storage_builder.mgs.service_device.device_type

        colocation = Colocation()
        colocation.id = 'mgs-with-%s' % backbone_dev_type
        colocation.score = 'inf'
        colocation.add_resource('mgs')
        colocation.add_resource('mgs-%s' % backbone_dev_type)
        return colocation

    @staticmethod
    def _generate_mgs_with_mpath_colocation():
        """ Generate MGS resource colocation with vg.
        """

        colocation = Colocation()
        colocation.id = 'mgs-zpool-with-mpath-config'
        colocation.score = 'inf'
        colocation.add_resource('mgs-zpool')
        colocation.add_resource('cl-mpath-config')
        return colocation

    @staticmethod
    def _generate_mgs_with_multipathd_colocation():
        """ Generate MGS resource colocation with vg.
        """

        colocation = Colocation()
        colocation.id = 'mgs-zpool-with-multipathd'
        colocation.score = 'inf'
        colocation.add_resource('mgs-zpool')
        colocation.add_resource('cl-multipathd')
        return colocation

    @staticmethod
    def _generate_mgs_after_sfa_home_vd_order():
        """ Generate MGT resource order after sfa_home_vd.
        """

        order = Order()
        order.id = 'mgs-after-sfa-home-vd'
        order.score = '0'
        order.add_resource('cl-sfa-home-vd', 'start')
        order.add_resource('mgs', 'start')
        return order

    @staticmethod
    def _generate_mgs_zpool_after_mpath_conf_order():
        """ Generate MGS resource order after sfa_home_vd.
        """

        order = Order()
        order.id = 'mgs-zpool-after-mpath-config'
        order.score = 'inf'
        order.add_resource('cl-mpath-config')
        order.add_resource('mgs-zpool')
        return order

    @staticmethod
    def _generate_mgs_zpool_after_multipathd_order():
        """ Generate MGS resource order after sfa_home_vd.
        """

        order = Order()
        order.id = 'mgs-zpool-after-multipathd'
        order.score = 'inf'
        order.add_resource('cl-multipathd')
        order.add_resource('mgs-zpool')
        return order

    @staticmethod
    def _generate_mgs_rsc_ticket():
        """ Generate MGT resource ticket.
        """

        rsc_ticket = RscTicket()
        rsc_ticket.id = 'ticket-lustre-allocated-mgs'
        rsc_ticket.ticket_id = 'lustre-allocated'
        rsc_ticket.add_resource('mgs')
        rsc_ticket.loss_policy = 'stop'
        return rsc_ticket

    def _generate_mgs_rules(self, host_name):
        """ Generate rules for MGT targets for given filesystem.
        """

        backfs_type = self._targets_storage_builder.mgs.backfs

        rules = list()
        rules.append(self._generate_mgs_backbone_dev_primitive())
        rules.append(self._generate_mgs_backbone_dev_location())
        rules.append(self._generate_mgs_prefer_master_node_location())
        rules.append(self._generate_mgs_prefer_home_node_location())
        if self._es_config.global_settings.pingd:
            rules.extend(self._generate_mgs_ifspeed_locations(host_name))
            rules.extend(self._generate_mgs_ping_locations(host_name))
        rules.append(self._generate_mgs_primitive())
        rules.append(self._generate_mgs_placement())
        rules.append(self._generate_mgs_after_backbone_dev_order())
        rules.append(self._generate_mgs_with_backbone_dev_colocation())
        rules.append(self._generate_mgs_after_sfa_home_vd_order())
        rules.append(self._generate_mgs_rsc_ticket())
        if backfs_type == 'zfs':
            rules.append(self._generate_mgs_with_multipathd_colocation())
            rules.append(self._generate_mgs_zpool_after_multipathd_order())

        return rules

    def __generate_ost_template(self, template_name, options=None):
        """ Generate OST resource templates.
        """

        template = RscTemplate(template_name, 'lustre-server')
        template.cls = 'ocf'
        template.provider = 'ddn'
        template.params.add_attribute('lustre_resource_type', 'ost')
        template.params.add_attribute('manage_directory', '1')
        if options is not None:
            template.params.add_attribute('options', options)
        template.add_op('start', **{'timeout': self._es_config.ha_settings.lustre_start_timeout,
                                    'interval': 0, 'record-pending': 'true'})
        template.add_op('stop', **{'timeout': 300, 'interval': 0, 'record-pending': 'true'})
        template.add_op('monitor', **{'timeout': 300, 'interval': 30})
        template.utilization.add_attribute('lustre-object', 1)
        template.meta.add_attribute('priority', 0)
        return template

    def _generate_ost_templates(self, fs, host_name):
        """ Generate OST resource templates.
        """

        rules = list()

        if self._lnet_groups[fs]:
            for lnet, osts in self._lnet_groups[fs].iteritems():
                rules.append(self.__generate_ost_template('lustre-{0}-ost-{1}'.format(fs, lnet),
                                                          self._es_config.fs_settings[fs].ost_mount_opts))
        else:
            rules.append(self.__generate_ost_template('lustre-{0}-ost'.format(fs),
                                                      self._es_config.fs_settings[fs].ost_mount_opts))
        return rules

    @staticmethod
    def __generate_ost_after_mgs_order(order_id, resource):
        """ Generate OST resource order after MGT.
        """

        order = Order()
        order.id = order_id
        order.score = '0'
        order.add_resource('mgs', 'start')
        order.add_resource(resource, 'start')
        return order

    def _generate_ost_after_mgs_orders(self, fs, host_name):
        """ Generate OST resource orders after MGT.
        """

        rules = list()

        if self._lnet_groups[fs]:
            for lnet, osts in self._lnet_groups[fs].iteritems():
                rules.append(self.__generate_ost_after_mgs_order(
                    'ost-{0}-{1}-after-mgs'.format(fs, lnet),
                    'lustre-{0}-ost-{1}'.format(fs, lnet)))
        else:
            rules.append(self.__generate_ost_after_mgs_order(
                'ost-{0}-after-mgs'.format(fs),
                'lustre-{0}-ost'.format(fs)))

        return rules

    @staticmethod
    def __generate_ost_after_mdt_order(order_id, mdt_resource, ost_resource):
        """ Generate OST resource order after MDT.
        """

        order = Order()
        order.id = order_id
        order.score = '0'
        order.add_resource(mdt_resource, 'start')
        order.add_resource(ost_resource, 'start')
        return order

    def _generate_ost_after_mdt_orders(self, fs, host_name):
        """ Generate OST resource orders after MDT.
        """

        rules = list()

        if self._lnet_groups[fs]:
            for lnet, osts in self._lnet_groups[fs].iteritems():
                rules.append(self.__generate_ost_after_mdt_order(
                    'ost-{0}-{1}-after-mdt'.format(fs, lnet),
                    'lustre-{0}-mdt'.format(fs),
                    'lustre-{0}-ost-{1}'.format(fs, lnet)))
        else:
            rules.append(self.__generate_ost_after_mdt_order(
                'ost-{0}-after-mdt'.format(fs),
                'lustre-{0}-mdt'.format(fs),
                'lustre-{0}-ost'.format(fs)
            ))

        return rules

    @staticmethod
    def __generate_ost_after_sfa_home_vd_order(order_id, resource):
        """ Generate OST resource order after sfa_home_vd.
        """

        order = Order()
        order.id = order_id
        order.score = '0'
        order.add_resource('cl-sfa-home-vd', 'start')
        order.add_resource(resource, 'start')
        return order

    def _generate_ost_after_sfa_home_vd_orders(self, fs, host_name):
        """ Generate OST resource orders after sfa_home_vd.
        """

        rules = list()

        if self._lnet_groups[fs]:
            for lnet, osts in self._lnet_groups[fs].iteritems():
                rules.append(self.__generate_ost_after_sfa_home_vd_order(
                    'ost-{0}-{1}-after-sfa-home-vd'.format(fs, lnet),
                    'lustre-{0}-ost-{1}'.format(fs, lnet)))
        else:
            rules.append(self.__generate_ost_after_sfa_home_vd_order(
                'ost-{0}-after-sfa-home-vd'.format(fs),
                'lustre-{0}-ost'.format(fs)
            ))

        return rules

    @staticmethod
    def __generate_ost_rsc_ticket(identifier, ticket_id, resource):
        """ Generate OST resource ticket.
        """

        rsc_ticket = RscTicket()
        rsc_ticket.id = identifier
        rsc_ticket.ticket_id = ticket_id
        rsc_ticket.add_resource(resource)
        rsc_ticket.loss_policy = 'stop'
        return rsc_ticket

    def _generate_ost_rsc_tickets(self, fs, host_name):
        """ Generate OST resource tickets.
        """

        rules = list()

        if self._lnet_groups[fs]:
            for lnet, osts in self._lnet_groups[fs].iteritems():
                rules.append(self.__generate_ost_rsc_ticket(
                    'ticket-{0}-{1}-allocated-ost'.format(fs, lnet),
                    '{0}-allocated'.format(fs),
                    'lustre-{0}-ost-{1}'.format(fs, lnet)))

        else:
            rules.append(self.__generate_ost_rsc_ticket(
                'ticket-{0}-allocated-ost'.format(fs),
                '{0}-allocated'.format(fs),
                'lustre-{0}-ost'.format(fs)
            ))

        return rules

    @staticmethod
    def __generate_ost_placement(placement, resource):
        """ Generate OST resource placement.
        """

        location = Location()
        location.id = placement
        location.resource = resource
        location.resource_discovery_attribute = 'never'
        rule = Rule()
        rule.score = '-inf'
        seu = SimpleExpressionUnary()
        seu.attribute = placement
        seu.unary_op = 'not_defined'
        seb = SimpleExpressionBinary()
        seb.attribute = placement
        seb.binary_op = 'ne'
        seb.value = 'true'
        rule.expression.add_simple_expression(seu)
        rule.expression.add_bool_operator('or')
        rule.expression.add_simple_expression(seb)
        location.add_rule(rule)
        return location

    def _generate_ost_placements(self, fs, host_name):
        """ Generate OST resource placements.
        """

        rules = list()

        if self._lnet_groups[fs]:
            for lnet, osts in self._lnet_groups[fs].iteritems():
                rules.append(self.__generate_ost_placement(
                    'ost-{0}-{1}-placement'.format(fs, lnet),
                    'lustre-{0}-ost-{1}'.format(fs, lnet)))
        else:
            rules.append(self.__generate_ost_placement(
                'ost-{0}-placement'.format(fs),
                'lustre-{0}-ost'.format(fs)
            ))

        return rules

    def _generate_ost_ifspeed_locations(self, fs, host_name):
        """ Generate OST resource locations for ifspeed.
        """

        rules = list()
        backfs_type = self._es_config.fs_settings[fs].backfs

        if self._lnet_groups[fs]:
            for lnet, osts in self._lnet_groups[fs].iteritems():
                honor_ifspeed_location = Location()
                honor_ifspeed_location.id = 'ost-{0}-{1}-honor-ifspeed'.format(fs, lnet)
                honor_ifspeed_location.resource = 'lustre-{0}-ost-{1}'.format(fs, lnet)
                rule = Rule()
                rule.score = 'ifspeed-lnet-{0}'.format(lnet)
                seu = SimpleExpressionUnary()
                seu.attribute = 'ifspeed-lnet-{0}'.format(lnet)
                seu.unary_op = 'defined'
                rule.expression.add_simple_expression(seu)
                honor_ifspeed_location.add_rule(rule)
                rules.append(honor_ifspeed_location)
        else:
            if self._es_config.global_settings.lnet_mr_fault_sensitive:
                for lnet in [element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()]:
                    honor_ifspeed_location = Location()
                    honor_ifspeed_location.id = 'ost-{0}-{1}-honor-ifspeed'.format(fs, lnet)
                    honor_ifspeed_location.resource = 'lustre-{0}-ost'.format(fs)
                    rule = Rule()
                    rule.score = 'ifspeed-lnet-{0}'.format(lnet)
                    seu = SimpleExpressionUnary()
                    seu.attribute = 'ifspeed-lnet-{0}'.format(lnet)
                    seu.unary_op = 'defined'
                    rule.expression.add_simple_expression(seu)
                    honor_ifspeed_location.add_rule(rule)
                    rules.append(honor_ifspeed_location)

            else:
                lnets_str = '-'.join([element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()])
                honor_ifspeed_location = Location()
                honor_ifspeed_location.id = 'ost-{0}-honor-ifspeed'.format(fs)
                if backfs_type == 'ldiskfs':
                    honor_ifspeed_location.resource = 'lustre-{0}-ost'.format(fs)
                elif backfs_type == 'zfs':
                    honor_ifspeed_location.resource = 'lustre-{0}-ost-zpool'.format(fs)
                rule = Rule()
                rule.score = 'ifspeed-lnet-{0}'.format(lnets_str)
                seu = SimpleExpressionUnary()
                seu.attribute = 'ifspeed-lnet-{0}'.format(lnets_str)
                seu.unary_op = 'defined'
                rule.expression.add_simple_expression(seu)
                honor_ifspeed_location.add_rule(rule)
                rules.append(honor_ifspeed_location)

        return list(set([rule.__str__() for rule in rules]))

    def _generate_ost_ping_locations(self, fs, host_name):
        """ Generate OST resource location for ping.
        """

        rules = list()
        backfs_type = self._es_config.fs_settings[fs].backfs

        if self._lnet_groups[fs]:
            for lnet, osts in self._lnet_groups[fs].iteritems():
                honor_ping_location = Location()
                honor_ping_location.id = 'ost-{0}-{1}-honor-ping'.format(fs, lnet)
                honor_ping_location.resource = 'lustre-{0}-ost-{1}'.format(fs, lnet)
                rule = Rule()
                rule.score = 'ping-lnet-{0}'.format(lnet)
                seu = SimpleExpressionUnary()
                seu.attribute = 'ping-lnet-{0}'.format(lnet)
                seu.unary_op = 'defined'
                rule.expression.add_simple_expression(seu)
                honor_ping_location.add_rule(rule)
                rules.append(honor_ping_location)
        else:
            if self._es_config.global_settings.lnet_mr_fault_sensitive:
                for lnet in [element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()]:
                    honor_ping_location = Location()
                    honor_ping_location.id = 'ost-{0}-{1}-honor-ping'.format(fs, lnet)
                    honor_ping_location.resource = 'lustre-{0}-ost'.format(fs)
                    rule = Rule()
                    rule.score = 'ping-lnet-{0}'.format(lnet)
                    seu = SimpleExpressionUnary()
                    seu.attribute = 'ping-lnet-{0}'.format(lnet)
                    seu.unary_op = 'defined'
                    rule.expression.add_simple_expression(seu)
                    honor_ping_location.add_rule(rule)
                    rules.append(honor_ping_location)

            else:
                lnets_str = '-'.join([element[1] for element in self._es_config.hosts_settings[host_name].host_lnets()])
                honor_ping_location = Location()
                honor_ping_location.id = 'ost-{0}-honor-ping'.format(fs)
                if backfs_type == 'ldiskfs':
                    honor_ping_location.resource = 'lustre-{0}-ost'.format(fs)
                elif backfs_type == 'zfs':
                    honor_ping_location.resource = 'lustre-{0}-ost-zpool'.format(fs)
                rule = Rule()
                rule.score = 'ping-lnet-{0}'.format(lnets_str)
                seu = SimpleExpressionUnary()
                seu.attribute = 'ping-lnet-{0}'.format(lnets_str)
                seu.unary_op = 'defined'
                rule.expression.add_simple_expression(seu)
                honor_ping_location.add_rule(rule)
                rules.append(honor_ping_location)

        return list(set([rule.__str__() for rule in rules]))

    @staticmethod
    def _generate_ost_prefer_master_node_location(backfs_type):
        """ Generate OST resource preferable location for master node.
        """

        master_location = Location()
        master_location.id = 'ost-prefer-master-node'
        master_location.resource = ('/ost([[:digit:]]{4})-(.+)-zpool/' if backfs_type == 'zfs'
                                    else '/ost([[:digit:]]{4})-(.+)/')
        rule = Rule()
        rule.score = 'ost%1-%2-preference-config'
        seu = SimpleExpressionUnary()
        seu.attribute = 'ost%1-%2-preference-config'
        seu.unary_op = 'defined'
        rule.expression.add_simple_expression(seu)
        master_location.add_rule(rule)
        return master_location

    @staticmethod
    def _generate_ost_prefer_home_node_location(backfs_type):
        """ Generate OST resource preferable location for home node.
        """

        home_location = Location()
        home_location.id = 'ost-prefer-home-node'
        home_location.resource = ('/ost([[:digit:]]{4})-(.+)-zpool/' if backfs_type == 'zfs'
                                  else '/ost([[:digit:]]{4})-(.+)/')
        rule = Rule()
        rule.score = 'ost%1-%2-preference-auto'
        seu = SimpleExpressionUnary()
        seu.attribute = 'ost%1-%2-preference-auto'
        seu.unary_op = 'defined'
        rule.expression.add_simple_expression(seu)
        home_location.add_rule(rule)
        return home_location

    def _generate_ost_target_rules(self, target, fs):
        """ Generate OST target specific rules.
        """

        rules = list()
        backfs_type = self._es_config.fs_settings[fs].backfs

        if backfs_type == 'zfs':
            primitive_zpool = Primitive('ost%04d-%s-zpool' % (target.idx, fs),
                                        primitive_template='lustre-{0}-ost-zpool'.format(fs))
            params = TaggedAttributesListWithMetaAndRules('params')
            params.add_attribute('pool', target.service_device.name)
            params.add_attribute('importargs', '"-d {0}"'.format(target.service_device.underlying_storage_devices_base_path))
            primitive_zpool.add_params(params)
            for meta in self._generate_meta_zone_attribute(target):
                primitive_zpool.add_params(meta)
            rules.append(primitive_zpool)

        if self._lnet_groups[fs]:

            target_lnet = None

            for lnet, indexes in self._lnet_groups[fs].iteritems():
                if target.idx in indexes:
                    target_lnet = lnet
                    break

            if target_lnet is None:
                raise ScalersException('Ost with index {0} was not mentioned in'
                                       ' ost_lnet_list for filesystem {1}'.format(target.idx, fs))

            primitive = Primitive('ost%04d-%s' % (target.idx, fs),
                                  primitive_template='lustre-{0}-ost-{1}'.format(fs, target_lnet))
            params = TaggedAttributesListWithMetaAndRules('params')
            params.add_attribute('device', '"%s"' % target.device.path)
            params.add_attribute('directory', '"/lustre/%s/ost%04d"' % (fs, target.idx))
            primitive.add_params(params)
            for meta in self._generate_meta_zone_attribute(target):
                primitive.add_params(meta)
            rules.append(primitive)

        else:

            primitive = Primitive('ost%04d-%s' % (target.idx, fs), primitive_template='lustre-{0}-ost'.format(fs))
            params = TaggedAttributesListWithMetaAndRules('params')
            params.add_attribute('device', '"%s"' % target.device.path)
            params.add_attribute('directory', '"/lustre/%s/ost%04d"' % (fs, target.idx))
            primitive.add_params(params)
            for meta in self._generate_meta_zone_attribute(target):
                primitive.add_params(meta)
            rules.append(primitive)

        if backfs_type == 'zfs':
            order = Order()
            order.id = 'ost%04d-%s-after-zpool' % (target.idx, fs)
            order.score = 'inf'
            order.add_resource('ost%04d-%s-zpool' % (target.idx, fs))
            order.add_resource('ost%04d-%s' % (target.idx, fs))
            rules.append(order)

            colocation = Colocation()
            colocation.id = 'ost%04d-%s-with-zpool' % (target.idx, fs)
            colocation.score = 'inf'
            colocation.add_resource('ost%04d-%s' % (target.idx, fs))
            colocation.add_resource('ost%04d-%s-zpool' % (target.idx, fs))
            rules.append(colocation)

        return rules

    def _generate_ost_prefer_storage_location(self, target, fs):
        """ Generate OST resource preferable location for storage.
        """

        rules = list()
        sfa_list = self._es_config.hosts_settings[target.primary_host].host_sfa_list

        for sfa in sfa_list:
            storage_location = Location()
            storage_location.id = 'ost%04d-%s-prefer-storage-%s' % (target.idx, fs, sfa)
            storage_location.resource = 'ost%04d-%s' % (target.idx, fs)
            rule = Rule()
            rule.score = '-inf'
            seu = SimpleExpressionUnary()
            seu.attribute = sfa
            seu.unary_op = 'not_defined'
            seb = SimpleExpressionBinary()
            seb.attribute = sfa
            seb.binary_op = 'ne'
            seb.value = 'true'
            rule.expression.add_simple_expression(seu)
            rule.expression.add_bool_operator('or')
            rule.expression.add_simple_expression(seb)
            storage_location.add_rule(rule)
            rules.append(storage_location)

        return rules

    def _generate_ost_require_home_zone_location(self):
        """ Generate OST resource require home zone location.
        """

        rules = list()

        storage_location = Location()
        storage_location.id = 'ost-require-home-zone'
        storage_location.resource = '/ost([[:digit:]]{4})-(.+)/'
        rule = Rule()
        rule.score = '-inf'
        seu = SimpleExpressionUnary()
        seu.unary_op = 'not_defined'
        seu.attribute = 'zone'
        seb = SimpleExpressionBinary()
        seb.attribute = 'zone'
        seb.binary_op = 'ne'
        seb.value = 'meta{zone}'
        rule.expression.add_simple_expression(seu)
        rule.expression.add_bool_operator('or')
        rule.expression.add_simple_expression(seb)
        storage_location.add_rule(rule)
        rules.append(storage_location)

        return rules

    def _generate_ost_rules(self, fs, host_name, mgs_exists, mdt_exists):
        """ Generate rules for OST targets for given filesystem.l
        """

        rules = list()
        backfs_type = self._es_config.fs_settings[fs].backfs

        if backfs_type == 'zfs':
            rules.append(self._generate_ost_zpool_template(fs, self._es_config))
            rules.append(self._generate_ost_zpool_location(fs))

        rules.extend(self._generate_ost_templates(fs, host_name))
        if mgs_exists:
            rules.extend(self._generate_ost_after_mgs_orders(fs, host_name))
        if mdt_exists:
            rules.extend(self._generate_ost_after_mdt_orders(fs, host_name))
        rules.extend(self._generate_ost_after_sfa_home_vd_orders(fs, host_name))
        rules.extend(self._generate_ost_rsc_tickets(fs, host_name))
        rules.extend(self._generate_ost_placements(fs, host_name))
        if self._es_config.global_settings.pingd:
            rules.extend(self._generate_ost_ifspeed_locations(fs, host_name))
            rules.extend(self._generate_ost_ping_locations(fs, host_name))

        ha_group_idx = self._es_config.hosts_settings[host_name].ha_group_idx

        for host in self._es_config.ha_settings.ha_groups[ha_group_idx]:
            local_targets = self._targets_storage_builder.create_local_storage(host=host, fs=fs).target_list
            for target in local_targets:
                if target.type == 'ost':
                    rules.extend(self._generate_ost_target_rules(target, fs))

        if backfs_type == 'zfs':
            colocation_multipathd = Colocation()
            colocation_multipathd.id = 'lustre-%s-ost-zpool-with-multipathd' % (fs)
            colocation_multipathd.score = 'inf'
            colocation_multipathd.add_resource('lustre-%s-ost-zpool' % (fs))
            colocation_multipathd.add_resource('cl-multipathd')
            rules.append(colocation_multipathd)

            order_multipathd = Order()
            order_multipathd.id = 'lustre-%s-ost-zpool-after-multipathd' % (fs)
            order_multipathd.score = 'inf'
            order_multipathd.add_resource('cl-multipathd')
            order_multipathd.add_resource('lustre-%s-ost-zpool' % (fs))
            rules.append(order_multipathd)

        return rules
