# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level serial related functionality for EXAScaler API package.
"""
import os

from es.utils import get_hostname, get_file_content
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand


class SerialConfigurator(object):
    """ Configurator for serial.
    """

    def __init__(self, config):
        """ Basic initialization.
        """

        self._es_config = config

        self.speed = self._es_config.hosts_settings[get_hostname()].serial_speed
        self.port = self._es_config.hosts_settings[get_hostname()].serial_port

    def configure_securetty(self):
        """ Tune '/etc/securetty'.
        """

        securetty_content = get_file_content('/etc/securetty')

        with open('/etc/securetty', 'w') as securetty_file:
            securetty_file.write(securetty_content)
            if securetty_content.find(self.port) == -1:
                securetty_file.write('{0}\n'.format(self.port))

        os.chmod('/etc/securetty', 0644)

    def if_serial_port_exist(self):
        """ Check of serial port existence.
        """

        try:
            with open(os.path.join('/dev', self.port), 'w') as f:
                f.write(' ')
        except IOError:
            return False

        return True

    def configure(self):
        """ Configure serial.
        """

        if self.if_serial_port_exist():
            self.configure_securetty()

        kernel_path = CmdExecutor(StringCommand('grubby --default-kernel')).execute().strip()
        CmdExecutor(StringCommand('grubby --args="console=tty0 console={0},{1}" --update-kernel={2}'.format(
            self.port, self.speed, kernel_path))).execute()
