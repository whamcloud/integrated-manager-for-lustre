# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level logging related functionality for EXAScaler API package.
"""
import ConfigParser
import os

from scalers.errors import ScalersException
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import CommandExecutor, StringCommand
from es.utils import get_hostname, load_module, get_file_content


class LoggingConfigurator(object):
    """ Configurator for logging.
    """

    @classmethod
    def configure_logrotate(cls):
        """ Tune /etc/logrotate.d/
        """

        with open('/etc/logrotate.d/syslog', 'w') as syslog_file:
            syslog_file.write(get_file_content('/opt/ddn/api/es/cluster/configurator/templates/logrotate.syslog'))
        os.chmod('/etc/logrotate.d/syslog', 0644)

        with open('/etc/logrotate.d/rest', 'w') as syslog_file:
            syslog_file.write(get_file_content('/opt/ddn/api/es/cluster/configurator/templates/logrotate.rest'))
        os.chmod('/etc/logrotate.d/rest', 0644)

        with open('/etc/logrotate.d/es', 'w') as syslog_file:
            syslog_file.write(get_file_content('/opt/ddn/api/es/cluster/configurator/templates/logrotate.es'))
        os.chmod('/etc/logrotate.d/es', 0644)

    @classmethod
    def configure_journald(cls):
        """ Tune '/etc/systemd/journald.conf'
        """

        old_content = get_file_content('/etc/systemd/journald.conf')

        with open('/etc/systemd/journald.conf', 'w') as journal_file:
            for line in old_content.splitlines():
                if line.strip().startswith('#ForwardToSyslog=no'):
                    journal_file.write('ForwardToSyslog=yes\n')
                else:
                    journal_file.write('{0}\n'.format(line))
        os.chmod('/etc/systemd/journald.conf', 0644)

    @classmethod
    def configure_syslog_ng(cls):
        """ Tune '/etc/syslog-ng/syslog-ng.conf'
        """

        with open('/etc/syslog-ng/syslog-ng.conf', 'w') as syslog_ng_file:
            syslog_ng_file.write(get_file_content('/opt/ddn/api/es/cluster/configurator/templates/syslog-ng.conf'))
        os.chmod('/etc/syslog-ng/syslog-ng.conf', 0644)

    @classmethod
    def restart_services(cls):
        """ Restart services.
        """

        CmdExecutor(StringCommand('systemctl restart systemd-journald.service')).execute()
        CmdExecutor(StringCommand('systemctl restart syslog-ng.service')).execute()

    @classmethod
    def configure_syslog_ng_unit(cls):
        """ Create custom syslog-ng unit.
        """

        if os.path.exists('/usr/lib/systemd/system/syslog-ng.service'):
            config = ConfigParser.ConfigParser()
            config.optionxform = str
            config.read('/usr/lib/systemd/system/syslog-ng.service')
            config.set('Unit', 'After', 'network.target')
            with open('/etc/systemd/system/syslog-ng.service', 'w') as configfile:
                config.write(configfile)
            os.chmod('/etc/systemd/system/syslog-ng.service', 0644)

    def configure(self):
        """ Configure logging.
        """

        self.configure_logrotate()
        self.configure_journald()
        self.configure_syslog_ng()
        self.configure_syslog_ng_unit()
        self.restart_services()
