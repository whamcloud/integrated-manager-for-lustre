# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level MDT backup related functionality for EXAScaler API package.
"""

import os

from pprint import pprint
from es.utils import get_hostname
from es.lustre.entities.targets_storage import TargetsStorageBuilder
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand, CommandExecutor


class LConfig(object):
    """ Configurator for Loris config.
    """

    def __init__(self, hostname, es_config):
        """ Basic initialization.
        """

        self.loris_config_path = '/etc/loris.conf'
        self.loris_config = None
        self.hostname = hostname
        self._es_config = es_config
        self.mdt_targets = list()
        self.backup_path = self._es_config.global_settings.mdt_backup_dir
        self.ssh_identity_file = '/root/.ssh/id_rsa'
        self._create_targets()
        if not self.loris_config:
            try:
                self._create_lconfig()
            except:
                self.loris_config = {}

    def _create_targets(self):
        """ Create MDT objects which could be launched on current host.
        """

        builder = TargetsStorageBuilder(self._es_config)
        for fs in self._es_config.global_settings.fs_list:
            if self.hostname in self._es_config.fs_settings[fs].mds_list:
                local_targets = builder.create_local_storage(fs, self.hostname).target_list
                failover_targets = builder.create_failover_storage(fs, self.hostname).target_list
                [self.mdt_targets.append(mdt) for mdt in local_targets + failover_targets if mdt.type == 'mdt']

    def _create_lconfig(self):
        """ Create Loris config.
        """

        self._loris_config = {
            'only_backup_active_mdt': True,
            'ssh_hosts': [{
                'host_id': self.hostname,
                'hostname': self.hostname,
                'ssh_identity_file': self.ssh_identity_file
        },],
            'lustre_devices': [],
            'backup_devices': [{
                'backups': [],
                'host_id': self.hostname,
                'path': self.backup_path,
            }],
        }
        for mdt in self.mdt_targets:
            lustre_device = {
                'device': mdt.device.path,
                'device_id': mdt.device_label,
                'fsname': mdt.fs,
                'host_id': self.hostname,
                'service_name': mdt.device_label.split(mdt.fs + '-')[-1],
            }
            backup = {
                'lustre_device_id': mdt.device_label,
                'type': 'e2image'
            }
            self._loris_config['lustre_devices'].append(lustre_device)
            for device in self._loris_config['backup_devices']:
                if device['host_id'] == self.hostname:
                    device['backups'].append(backup)

        self.loris_config = self._loris_config

    def show(self):
        """ Convert Loris config to yaml.
        """

        pprint(self.loris_config)

    def to_yaml(self):
        """ Create MDT objects which could be launched on current host.
        """
        if self.loris_config:
            from yaml import dump
            return dump(self.loris_config, default_flow_style=False)


class MdtBackupConfigurator(object):
    """ Configurator for MDT backup.
    """

    def __init__(self, config, local_host_name=None):
        """ Basic initialization.
        """

        self._es_config = config
        self.host_name = local_host_name if local_host_name is not None else get_hostname()

    def _configure_mdt_backup_sh(self):
        """ Tune '/etc/cron.d/mdt-backup'.
        """

        content = None

        if self._es_config.global_settings.mdt_backup == 'weekly':
            content = '10 4 * * 0 root /opt/ddn/es/tools/mdt_lvm_backup.sh 2>&1'
        elif self._es_config.global_settings.mdt_backup == 'daily':
            content = '10 4 * * * root /opt/ddn/es/tools/mdt_lvm_backup.sh 2>&1'

        with open('/etc/cron.d/mdt-backup', 'w') as backup_file:
            backup_file.write(content)

        os.chmod('/etc/cron.d/mdt-backup', 0644)

    def _configure_loris(self):
        """ Tune '/etc/loris.conf' and add loris to cron.
        """

        loris_config = LConfig(self.host_name, self._es_config)
        if not loris_config.loris_config:
            return
        with open(loris_config.loris_config_path, 'w') as backup_file:
            backup_file.write(loris_config.to_yaml())

        os.chmod(loris_config.loris_config_path, 0644)
        CommandExecutor(StringCommand('loris_crontab')).run()
        CommandExecutor(StringCommand('crontab -l')).run()

    def configure(self):
        """ Tune '/etc/cron.d/mdt-backup'.
        """

        backup_enabled = False

        for fs in self._es_config.global_settings.fs_list:
            if self.host_name not in self._es_config.fs_settings[fs].mds_list:
                continue
            if self._es_config.global_settings.mdt_backup not in ('weekly', 'daily', 'loris'):
                continue
            backup_enabled = True

        if backup_enabled:

            if self._es_config.global_settings.mdt_backup in ('loris',):
                self._configure_loris()
            else:
                self._configure_mdt_backup_sh()
