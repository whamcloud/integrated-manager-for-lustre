# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level operating system related functionality for EXAScaler API package.
"""

import os

from es.utils import get_hostname, makedirs
from scalers.errors import ScalersException
from scalers.utils.command import StringCommand
from scalers.utils.cmd import CmdExecutor
from es.utils import is_embedded, get_file_content


class OperationSystemConfigurator(object):
    """ Configurator for operation system.
    """

    def __init__(self, config, local_host_name=None):
        """ Basic initialization.
        """

        self._es_config = config

        self.host_name = local_host_name if local_host_name is not None else get_hostname()

        if (self.host_name not in self._es_config.global_settings.host_list) and \
                (self.host_name not in self._es_config.global_settings.clients_list):
            raise ScalersException("No configuration found for host '{0}'".format(self.host_name))

    def config_sysctl(self):
        """ Tune  /etc/sysctl.conf
        """

        sysctl_file_path = '/etc/sysctl.conf'

        if os.path.exists(sysctl_file_path):

            makedirs('/scratch/crash/coredumps')

            settings = dict()

            with open(sysctl_file_path, 'r') as sysctl_file:
                for line in sysctl_file:
                    stripped_line_content = line.strip()
                    if not stripped_line_content or stripped_line_content.startswith("#"):
                        continue
                    pair = line.split("=")
                    settings[pair[0].strip()] = pair[1].strip()

            if self._es_config.flavour == 'SFA':
                settings_to_add = {
                    'net.ipv4.tcp_timestamps': '0',
                    'net.ipv4.tcp_sack': '1',
                    'net.ipv4.tcp_window_scaling': '1',
                    'net.ipv4.tcp_low_latency': '1',
                    'net.core.netdev_max_backlog': '250000',
                    'net.core.rmem_max': '16777216',
                    'net.core.wmem_max': '16777216',
                    'net.ipv4.tcp_rmem': '4096 87380 524288',
                    'net.ipv4.tcp_wmem': '4096 65536 524288',
                    'kernel.hung_task_timeout_secs': '90',
                    'kernel.nmi_watchdog': '0',
                    'kernel.panic_on_io_nmi': '0',
                    'kernel.panic_on_unrecovered_nmi': '0',
                    'kernel.unknown_nmi_panic': '1'
                }
                settings.update(settings_to_add)

            settings.update({"kernel.core_pattern": "/scratch/crash/coredumps/%e-%s-%u-%g-%p-%t"})

            if self._es_config.hosts_settings[self.host_name].sysctl is not None:
                settings.update(self._es_config.hosts_settings[self.host_name].sysctl.settings)

            for fs in self._es_config.fs_settings:
                if len(self._es_config.fs_settings[fs].ost_lnet_list) != 0 or \
                                len(self._es_config.hosts_settings[self.host_name].lnets) > 1:
                    arp_tuning = {
                        'net.ipv4.conf.all.rp_filter': '0',
                        'net.ipv4.conf.all.arp_announce': '2',
                        'net.ipv4.conf.all.arp_ignore': '1',
                        'net.ipv4.conf.default.rp_filter': '2',
                        'net.ipv4.conf.default.arp_announce': '2',
                        'net.ipv4.conf.default.arp_ignore': '1'
                    }
                    settings.update(arp_tuning)

            with open(sysctl_file_path, 'w') as sysctl_file:
                for key, value in settings.items():
                    sysctl_file.write('{0} = {1}\n'.format(key, value))

            os.chmod(sysctl_file_path, 0644)

    def customize_os(self):
        """ Configure services.
        """

        flavour = self._es_config.flavour

        services_to_enable = tuple()
        services_to_disable = tuple()

        if flavour == 'SFA':
            services_to_enable = ('openibd', 'syslog-ng', )
            services_to_disable = ('lnet', 'srpd', 'ddn-ibsrp', 'opensmd', 'multipathd', 'lvm2-lvmetad.service', 'lvm2-lvmetad.socket', 'chronyd', )
        elif flavour == 'HPC':
            services_to_enable = ('openibd', 'multipathd', 'syslog-ng',)
            services_to_disable = ('lnet', 'opensmd', 'srpd', 'lvm2-lvmetad.service', 'lvm2-lvmetad.socket', 'chronyd', )
        elif flavour == 'Client' or flavour == 'Bridge':
            services_to_enable = ('openibd', 'syslog-ng', )
            services_to_disable = ('lnet', 'srpd', 'ddn-ibsrp', 'opensmd', 'multipathd', 'lvm2-lvmetad.service', 'lvm2-lvmetad.socket', 'chronyd', )

        for service in services_to_enable:
            CmdExecutor(StringCommand('systemctl enable {0}'.format(service))).execute(ensure_success=False)

        for service in services_to_disable:
            CmdExecutor(StringCommand('systemctl disable --now {0}'.format(service))).execute(ensure_success=False)

    def config_rdma_conf(self):

        file_path = '/etc/rdma/rdma.conf'
        if self._es_config.drivers_type == "intel":
            if is_embedded():
                if os.path.exists(file_path):
                    old_content = get_file_content(file_path).splitlines()
                    new_content = ''
                    for line in old_content:
                        if line.strip().startswith('SRPT_LOAD'):
                            new_content += 'SRPT_LOAD=no\n'
                        elif line.strip().startswith('ISERT_LOAD'):
                            new_content += 'ISERT_LOAD=no\n'
                        else:
                            new_content += "{0}\n".format(line)

                    with open(file_path, 'w') as rdma_file:
                        rdma_file.write(new_content)

                    os.chmod(file_path, 0644)

    def config_timezone(self):
        """Configure timezone.
        """

        timezone = self._es_config.global_settings.timezone
        if timezone is not None:
            if timezone not in CmdExecutor(StringCommand('timedatectl list-timezones'))\
                    .execute(ensure_success=True).split():
                raise ScalersException("Unsupported timezone specified: {0}.\n"
                                       "Invoke 'timedatectl list-timezones' to get a list of supported timezones."
                                       .format(timezone))
            CmdExecutor(StringCommand('timedatectl set-timezone {0}'.format(timezone))).execute(ensure_success=True)

    def config_grub(self):
        """Configure GRUB2
        """

        grub_args = self._es_config.hosts_settings[self.host_name].grub_args
        if grub_args is not None:
            kernel_path = CmdExecutor(StringCommand('grubby --default-kernel')).execute().strip()
            CmdExecutor(StringCommand('grubby --args="{0}" --update-kernel={1}'
                                      .format(grub_args, kernel_path))).execute()



    def configure(self):
        """ Install and tune all required OS files.
        """

        self.config_rdma_conf()
        self.config_sysctl()
        self.customize_os()
        self.config_timezone()
        self.config_grub()
