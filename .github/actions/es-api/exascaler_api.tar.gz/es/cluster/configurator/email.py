# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level email alerts related functionality for EXAScaler API package.
"""

from string import Template

from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand
from es.utils import get_file_content, makedirs


class EmailConfigurator(object):
    """ Configurator for email MTU.
    """

    def __init__(self, config):
        """ Basic initialization.
        """

        self._es_config = config

        self.email_list = self._es_config.global_settings.email_list
        self.email_relay = self._es_config.global_settings.email_relay
        self.email_domain = self._es_config.global_settings.email_domain
        self.host_list = self._es_config.global_settings.host_list

    def _substitute_email_params(self, template):
        return template.safe_substitute(
            email_domain=self.email_domain,
            email_relay=self.email_relay,
            email_list=self.email_list,
        )

    def config_aliases(self):
        """ Install and tune /etc/aliases file.
        """

        conf_template = Template(get_file_content('/opt/ddn/api/es/cluster/configurator/templates/aliases'))
        with open('/etc/aliases', 'w') as contents:
            contents.write(self._substitute_email_params(conf_template))
        CmdExecutor(StringCommand('newaliases')).execute()

    def config_postfix_main_cf(self):
        """ Install and tune /etc/postfix/main.cf file.
        """

        conf_template = Template(get_file_content('/opt/ddn/api/es/cluster/configurator/templates/main.cf'))
        makedirs('/etc/postfix/')
        with open('/etc/postfix/main.cf', 'w') as contents:
            contents.write(self._substitute_email_params(conf_template))

    def config_postfix_sender_canonical(self):
        """ Install and tune /etc/postfix/sender_canonical file.
        """

        makedirs('/etc/postfix/')
        sc_file_path = '/etc/postfix/sender_canonical'
        with open(sc_file_path, 'w') as contents:
            for host in self.host_list:
                contents.write('root@{0} {0}@{1}\n'.format(host, self.email_domain))
        CmdExecutor(StringCommand('postmap %s' % sc_file_path)).execute()

    def config_services(self):
        """ Enable and start all the required services.
        """

        CmdExecutor(StringCommand('systemctl enable postfix')).execute()
        CmdExecutor(StringCommand('systemctl start postfix')).execute()

    def configure(self):
        """ Install and tune all required files.
        """

        self.config_aliases()
        self.config_postfix_main_cf()
        self.config_postfix_sender_canonical()
        self.config_services()
