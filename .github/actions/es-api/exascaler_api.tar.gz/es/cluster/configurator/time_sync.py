# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level time synchronization related functionality for EXAScaler API package.
"""

import os

from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand, CommandExecutor
from es.utils import get_file_content


class TimeSynchronizationConfigurator(object):
    """ Configurator for time synchronization.
    """

    def __init__(self, config):
        """ Basic initialization.
        """

        self._es_config = config

    def configure_sysconfig_file(self, sysconfig_file_name):
        """ Tune '/etc/sysconfig/ntpd' or '/etc/sysconfig/ntpdate'
        """

        is_vm_result = CommandExecutor(StringCommand('virt-what')).run()
        if is_vm_result.exit_code == 0 and is_vm_result.stdout.strip() == '':
            sync_hwclock_str = 'yes'
        else:
            sync_hwclock_str = 'no'

        old_content = get_file_content(sysconfig_file_name)

        with open(sysconfig_file_name, 'w') as sysconfig_file:
            for line in old_content.splitlines():
                if line.strip().startswith('#SYNC_HWCLOCK') or line.strip().startswith('SYNC_HWCLOCK'):
                    continue
                else:
                    sysconfig_file.write('{0}\n'.format(line))
            sysconfig_file.write('SYNC_HWCLOCK={0}\n'.format(sync_hwclock_str))
        os.chmod(sysconfig_file_name, 0644)

    def configure_sysconfig_ntpd(self):
        """ Tune '/etc/sysconfig/ntpd'
        """

        self.configure_sysconfig_file('/etc/sysconfig/ntpd')

    def configure_sysconfig_ntpdate(self):
        """ Tune '/etc/sysconfig/ntpdate'
        """

        self.configure_sysconfig_file('/etc/sysconfig/ntpdate')

    def configure_ntp_step_tickers(self):
        """ Tune '/etc/ntp/step-tickers'
        """

        ntp_step_tickers_file_name = '/etc/ntp/step-tickers'

        with open(ntp_step_tickers_file_name, 'w') as ntp_step_tickers_file:
            for ntp in self._es_config.global_settings.ntp_list:
                ntp_step_tickers_file.write('{0}\n'.format(ntp))
        os.chmod(ntp_step_tickers_file_name, 0644)

    def configure_ntp_conf(self):
        """ Tune '/etc/sysconfig/ntpd'
        """

        ntp_conf_file_name = '/etc/ntp.conf'
        old_content = get_file_content(ntp_conf_file_name)

        with open(ntp_conf_file_name, 'w') as ntp_conf_file:
            for line in old_content.splitlines():
                if line.strip().startswith('#') or line.strip().startswith('server') or not line.strip():
                    continue
                else:
                    ntp_conf_file.write('{0}\n'.format(line))
            for ntp in self._es_config.global_settings.ntp_list:
                ntp_conf_file.write('server {0}\n'.format(ntp))
        os.chmod(ntp_conf_file_name, 0644)

    def sync_time(self):
        """ Sync time via ntpdate command
        """

        CmdExecutor(StringCommand('ntpdate {0}'.format(' '.join(self._es_config.global_settings.ntp_list)))).execute()

    @classmethod
    def autostart_ntpd_service(cls):
        """ Add ntpd service to autostart.
        """

        CmdExecutor(StringCommand('systemctl enable ntpd')).execute()

    @classmethod
    def start_ntpd_service(cls):
        """ Start ntpd service.
        """

        CmdExecutor(StringCommand('systemctl start ntpd')).execute()

    @classmethod
    def autostart_ntpdate_service(cls):
        """ Add ntpdate service to autostart.
        """

        CmdExecutor(StringCommand('systemctl enable ntpdate')).execute()

    @classmethod
    def start_ntpdate_service(cls):
        """ Start ntpdate service.
        """

        CmdExecutor(StringCommand('systemctl start ntpdate')).execute()

    @classmethod
    def stop_ntpd_service(cls):
        """ Stop ntpd service.
        """

        CmdExecutor(StringCommand('systemctl stop ntpd')).execute()

    @classmethod
    def stop_ntpdate_service(cls):
        """ Stop ntpdate service.
        """

        CmdExecutor(StringCommand('systemctl stop ntpdate')).execute()

    def configure(self):
        """ Configure time synchronization.
        """

        if len(self._es_config.global_settings.ntp_list) == 0:
            return

        self.stop_ntpd_service()
        self.stop_ntpdate_service()
        self.configure_sysconfig_ntpd()
        self.configure_sysconfig_ntpdate()
        self.configure_ntp_conf()
        self.sync_time()
        self.configure_ntp_step_tickers()
        self.autostart_ntpdate_service()
        self.autostart_ntpd_service()
        self.start_ntpdate_service()
        self.start_ntpd_service()
