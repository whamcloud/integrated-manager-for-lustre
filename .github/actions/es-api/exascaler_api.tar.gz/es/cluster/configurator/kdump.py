# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level kdump related functionality for EXAScaler API package.
"""

import os

from scalers.errors import ScalersException
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand
from es.utils import relative_path, get_hostname, makedirs


class KdumpConfigurator(object):
    """ Configurator for kdump.
    """

    def __init__(self, config, local_host_name=None):
        """ Basic initialization.
        """

        self._es_config = config
        self.host_name = local_host_name if local_host_name is not None else get_hostname()

        if (self.host_name not in self._es_config.global_settings.host_list) and \
                (self.host_name not in self._es_config.global_settings.clients_list):
            raise ScalersException("No configuration found for host '{0}'".format(self.host_name))

    def config_sysconfig_kdump(self):
        """ Create '/etc/sysconfig/kdump'.
        """

        if self._es_config.flavour == 'SFA':
            with open('/etc/sysconfig/kdump', 'w') as kdump_file:
                content = 'KDUMP_KERNELVER=""\n' \
                          'KDUMP_COMMANDLINE=""\n' \
                          'KDUMP_COMMANDLINE_APPEND="irqpoll nr_cpus=1 reset_devices cgroup_disable=memory"\n' \
                          'MKDUMPRD_ARGS="--preload=sfablkdriver"\n' \
                          'KEXEC_ARGS=""\n' \
                          'KDUMP_BOOTDIR="/boot"\n' \
                          'KDUMP_IMG="vmlinuz"\n' \
                          'KDUMP_IMG_EXT=""\n'

                kdump_file.write(content)

            os.chmod('/etc/sysconfig/kdump', 0644)

    def configure_kdump_conf(self):
        """ Configure '/etc/kdump.conf'.
        """

        kdump_path = self._es_config.global_settings.kdump_path
        makedirs(kdump_path)

        out = CmdExecutor(StringCommand('df -P {0}'.format(kdump_path))).execute()
        details = out.splitlines()[1]
        lvm_name = details[:details.index(' ')]
        mount_point = details[details.rindex(' ') + 1:]
        sub_path = relative_path(kdump_path, mount_point)

        with open('/etc/kdump.conf', 'w') as kdump_file:
            content = '# Configures where to put the kdump /proc/vmcore files\n' \
                      '#\n' \
                      'ext4 {0}\n' \
                      'path {1}\n' \
                      'core_collector makedumpfile -c -d 17\n' \
                      'fence_kdump_args -i 5\n' \
                      'default shell\n'.format(lvm_name, sub_path)

            peer_nodes = self._es_config.ha_group_list(self.host_name)
            if self.host_name in peer_nodes:
                peer_nodes.remove(self.host_name)
            if len(peer_nodes) > 0:
                peers = ' '.join(peer_nodes)
                content = content + 'fence_kdump_nodes {0}\n'.format(peers)

            kdump_file.write(content)

        os.chmod('/etc/kdump.conf', 0644)
        CmdExecutor(StringCommand('systemctl restart kdump')).execute()

    def configure(self):
        """ Configure kdump.
        """

        self.config_sysconfig_kdump()
        self.configure_kdump_conf()
