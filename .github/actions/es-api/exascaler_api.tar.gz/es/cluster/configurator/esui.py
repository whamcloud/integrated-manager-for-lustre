# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2020, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level ESUI docker related functionality for EXAScaler API package.
"""

import os
import yaml
import json
import tempfile
import shutil

from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand, CommandExecutor
from scalers.errors import ScalersException
from es.utils import makedirs


class EsuiConfigurator(object):
    """ Configurator for ESUI docker config.
    """

    def __init__(self, es_config, local_host_name):
        """ Basic initialization.
        """

        self.iml_docker_compose = "/etc/iml-docker/docker-compose.yml"
        self.iml_docker_compose_override = (
            "/etc/iml-docker/docker-compose.overrides.yml"
        )
        self.iml_docker_secret_file = "/etc/iml-docker/secret.txt"
        self.iml_docker_setup_dir = "/etc/iml-docker/setup"
        self.iml_config = {
            "BRANDING": None,
            "USE_STRATAGEM": False,
            "EXA_VERSION": None,
        }
        self.docker_data_root = "/ui_data"
        self.docker_data_label = "esui"
        self.docker_data_config = "/etc/docker"
        self.docker_data_device = None
        self.host_name = local_host_name
        self._es_config = es_config
        self._server_hosts = self._get_server_host_ip()

    def _get_compose_version(self):
        """ Extract the docker compose version
        """

        with open(self.iml_docker_compose, "r") as file:
            compose = yaml.safe_load(file)

            return compose["version"]

    def _get_server_host_ip(self):
        """ Get host and ip from config
        """

        ip_hosts = dict()
        for host_key in self._es_config.global_settings.host_list:
            host = self._es_config.hosts_settings[host_key]
            # We are only interest in the first nic
            nic = host.nic_list[0]
            if host.nics[nic].ip is None:
                continue
            ip_hosts[host_key] = host.nics[nic].ip

        return ip_hosts

    def _is_rpm_installed(self, rpm):
        """ Check if a package is installed
        """

        rpm_list = []
        if type(rpm) is list:
            rpm_list.extend(rpm)
        else:
            rpm_list.append(rpm)

        found = True
        for rpm_name in rpm_list:
            if (
                CommandExecutor(StringCommand("rpm --quiet -q {0}".format(rpm_name)))
                .run()
                .exit_code
                != 0
            ):
                found = False

        return found

    def _install_rpm(self, rpm):

        local_yum_conf = "/etc/ddn/yum.conf"

        base_yum_cmd = ["yum", "--assumeyes", "install"]
        if os.path.isfile(local_yum_conf):
            base_yum_cmd.append("--config=" + local_yum_conf)

        if type(rpm) is list:
            base_yum_cmd.extend(rpm)
        else:
            base_yum_cmd.append(rpm)

        CmdExecutor(StringCommand(" ".join(base_yum_cmd))).execute()

    def _mount_target(self):
        """ Mount data-root
        """

        CmdExecutor(
            StringCommand(
                "mount -L {0} {1}".format(self.docker_data_label, self.docker_data_root)
            )
        ).execute()

    def _umount_target(self):
        """ Mount data-root
        """

        CmdExecutor(StringCommand("umount {0}".format(self.docker_data_root))).execute()

    def _get_label(self, device):
        """ Get device label
        """

        blkid_out = CommandExecutor(
            StringCommand(
                "blkid -c /dev/null -o value -s LABEL {0}".format(
                    self.docker_data_device
                )
            )
        ).run()
        return blkid_out.stdout

    def _configure_lvm(self):
        """ create lv using mgs vg
        Only run if mgs is active locally!
        """

        mgs_active = (
            CmdExecutor(
                StringCommand("lvdisplay --noheadings -C -o lv_active vg_mgs/mgs")
            )
            .execute()
            .strip()
        )
        if mgs_active != "active":
            return False

        lv_path = (
            CmdExecutor(StringCommand("lvdisplay --noheadings -C -o lv_path"))
            .execute()
            .split()
        )
        lv_device = [s for s in lv_path if self.docker_data_label in s]

        # create the lv if none
        if len(lv_device) == 0:
            vg_list = (
                CmdExecutor(StringCommand("vgdisplay --noheadings -C -o name"))
                .execute()
                .split()
            )
            vg_mgs = [s for s in vg_list if s == "vg_mgs"]
            if len(vg_mgs) == 0:
                raise ScalersException("Can not find volume group name vg_mgs")

            unit = self._es_config.esui_settings.size[-1]
            if unit.isalpha():
                needed = self._es_config.esui_settings.size[:-1]
            else:
                needed = self._es_config.esui_settings.size
                # if no units, assume bytes
                unit = "b"

            free_space = (
                CmdExecutor(
                    StringCommand(
                        "vgs --noheadings -o vg_free --nosuffix --units {} vg_mgs".format(
                            unit
                        )
                    )
                )
                .execute()
                .strip()
            )
            if float(needed) > float(free_space):
                raise ScalersException(
                    "Not enough space for esui ({}) in vg_mgs ({}{})".format(
                        self._es_config.esui_settings.size, free_space, unit
                    )
                )

            # save lvm.conf file
            lvm_conf = "/etc/lvm/lvm.conf"
            _, lvm_conf_bk = tempfile.mkstemp(dir="/etc/lvm")
            shutil.copy2(lvm_conf, lvm_conf_bk)

            with open(lvm_conf_bk, "rt") as fin:
                data = fin.read()
                data = data.replace(
                    "auto_activation_volume_list", "#auto_activation_volume_list"
                )
                data = data.replace("volume_list", "#volume_list")

            with open(lvm_conf, "wt") as fin:
                fin.write(data)

            CmdExecutor(
                StringCommand(
                    "lvcreate -n {0} --size {1} {2} -y".format(
                        self.docker_data_label,
                        self._es_config.esui_settings.size,
                        vg_mgs[0],
                    )
                )
            ).execute()

            # retore the file
            shutil.copy2(lvm_conf_bk, lvm_conf)
            os.remove(lvm_conf_bk)

        elif len(lv_device) > 1:
            raise ScalersException(
                "Multiple volume name {0} found".format(self.docker_data_label)
            )

        return True

    def _configure_storage(self):
        """ create ext4 filesystem to store data
        """

        if not self._configure_lvm():
            return False
        lv_path = (
            CmdExecutor(StringCommand("lvdisplay -C -o lv_path")).execute().split()
        )
        lv_device = [s for s in lv_path if self.docker_data_label in s]
        # we only expect one lv
        if len(lv_device) != 1:
            raise ScalersException(
                'Create volume name "{0}" failed'.format(self.docker_data_label)
            )

        self.docker_data_device = lv_device[0]

        # need to check the label existed
        if self._get_label(self.docker_data_device) != self.docker_data_label:
            CmdExecutor(
                StringCommand(
                    "mke2fs -t ext4 -L {0} {1}".format(
                        self.docker_data_label, self.docker_data_device
                    )
                )
            ).execute()
        return True

    def _configure_iml_config(self):
        """ Create esui config file for branding and stratagem
        """

        rpm = ["iml-docker", "ddn-iml-profile"]
        if not self._is_rpm_installed(rpm):
            self._install_rpm(rpm)

        new_config = self.iml_config
        if (
            os.path.isfile(os.path.join(self.iml_docker_setup_dir, "config"))
        ) and os.path.getsize(os.path.join(self.iml_docker_setup_dir, "config")) != 0:
            with open(
                os.path.join(self.iml_docker_setup_dir, "config"), "r"
            ) as config_file:
                for line in config_file:
                    if line.strip():
                        k, v = line.split("=")
                        new_config[k] = v.strip()

        new_config["EXA_VERSION"] = ".".join(map(str, self._es_config.version))

        new_config["CLI_NAME"] = "emf"

        sfa_list = self._es_config.global_settings.sfa_list
        if len(sfa_list) == 1:
            new_config["BRANDING"] = sfa_list[0].split("-")[0].lower()
        else:
            new_config["BRANDING"] = "exascaler"

        if new_config["BRANDING"].upper() in [
            "AI200",
            "AI200NV",
            "AI200NVX",
            "AI200X",
            "AI400",
            "AI400NV",
            "AI400NVX",
            "AI400X",
        ]:
            sfa_num = 0
            for sfa in sfa_list:
                sfa_num += 1
                sfa_str = "SFA_ENDPOINTS_{}".format(sfa_num)
                controllers = self._es_config.sfa_settings[sfa].controllers
                user = "esui"
                pw = "esui"
                port = 5989

                new_config[sfa_str] = "|".join(
                    "https://{0}:{1}@{2}:{3}".format(user, pw, x, port) for x in controllers
                )

        with open(
            os.path.join(self.iml_docker_setup_dir, "config"), "w"
        ) as config_file:
            for k, v in new_config.iteritems():
                config_file.write("{0}={1}\n".format(k, v))

    def create_compose_overrides(self):
        """ Create docker compose overrides
        """

        compose_overrides = {
            "version": "{0}".format(self._get_compose_version()),
            "services": {
                "job-scheduler": {"environment": [], "extra_hosts": self._server_hosts}
            },
        }

        with open(self.iml_docker_compose_override, "w") as yaml_file:
            yaml_str = yaml.safe_dump(
                compose_overrides, default_flow_style=False
            ).replace(r"''", "")
            yaml_file.write(yaml_str)

    def configure_nginx_host(self):
        """ Add nginx host ip
        """

        esui_ip = self._es_config.esui_settings.ip

        CommandExecutor(StringCommand("sed -i '/nginx/d' /etc/hosts")).run()
        with open("/etc/hosts", "a") as hosts:
            hosts.write("{0} nginx\n".format(esui_ip))

    def configure_docker(self):
        """ Make sure docker is enable and started
        """

        rpm = "docker-ce"
        # Make sure docker-ce is installed
        if not self._is_rpm_installed(rpm):
            self._install_rpm(rpm)

        with open(
            os.path.join(self.docker_data_config, "daemon.json"), "w"
        ) as config_file:
            json.dump(
                {"data-root": "{0}".format(self.docker_data_root)},
                config_file,
                sort_keys=True,
                indent=4,
            )

    def setup_docker(self):
        """ Make sure swarm is started
        """

        self._configure_iml_config()

        CmdExecutor(StringCommand("systemctl disable docker iml-docker")).execute()

        # check if data dir is mounted
        if not os.path.ismount(self.docker_data_root):
            # if not, check if storage is configured locally
            if not self._configure_storage():
                return
            self._mount_target()

        CmdExecutor(StringCommand("systemctl start docker")).execute()
        CommandExecutor(StringCommand("docker swarm leave --force")).run()
        CmdExecutor(
            StringCommand(
                "docker swarm init --advertise-addr=127.0.0.1 --listen-addr=127.0.0.1"
            )
        ).execute()
        self._configure_docker_secret()
        CmdExecutor(StringCommand("systemctl stop docker")).execute()
        self._umount_target()

    def _configure_docker_secret(self, iml_pw="DDNSolutions4U"):
        """ Configure docker secret
        """

        with open(self.iml_docker_secret_file, "w") as yaml_file:
            yaml_file.write(iml_pw)

        try:
            CmdExecutor(
                StringCommand(
                    "docker secret create iml_pw {0}".format(
                        self.iml_docker_secret_file
                    )
                )
            ).execute()
        finally:
            os.remove(self.iml_docker_secret_file)

    def add_server(self, pw=None):
        """ Add server to IML
        """

        if pw is not None:
            CmdExecutor(
                StringCommand(
                    "iml server add {0} -a password -P {1} --profile exascaler_server".format(
                        ",".join(self._server_hosts.keys(), pw)
                    )
                )
            ).execute()
        else:
            CmdExecutor(
                StringCommand(
                    "iml server add {0} -a shared --profile exascaler_server".format(
                        ",".join(self._server_hosts.keys())
                    )
                )
            ).execute()

    def detect_filesystem(self):
        """ Add filesystem to IML
        """

        CmdExecutor(StringCommand("iml filesystem detect")).execute()

    def _in_mgs(self):
        """ Determine if local host is in @mgs clush set
        """
        contents = (
            CmdExecutor(StringCommand("cluset -f {} -i @mgs".format(self.host_name)))
            .execute()
            .strip()
        )
        return bool(contents)

    def configure_dirs(self):
        """Create all needed dirs
        """
        makedirs(self.docker_data_config)
        makedirs(self.docker_data_root)
        makedirs(self.iml_docker_setup_dir)

    def configure(self):
        """ Configure ESUI docker
        """

        self.configure_nginx_host()
        if not self._in_mgs():
            return
        self.configure_dirs()
        self.configure_docker()
        self.create_compose_overrides()
        self.setup_docker()
