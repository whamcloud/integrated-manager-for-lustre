# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level lustre related functionality for EXAScaler API package.
"""

import os
import re
from string import Template

from es.lustre import Lustre
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand, CommandExecutor
from scalers.errors import ScalersException
from es.utils import get_file_content, get_hostname, makedirs


class LustreConfigurator(object):
    """ Configurator for Lustre.
    """

    def __init__(self, config, local_host_name=None):
        """ Basic initialization.
        """

        self._es_config = config
        self.host_name = local_host_name if local_host_name is not None else get_hostname()

        if (self.host_name not in self._es_config.global_settings.host_list) and \
                (self.host_name not in self._es_config.global_settings.clients_list):
            raise ScalersException("No configuration found for host '{0}'".format(self.host_name))

    @classmethod
    def get_all_configured_volume_groups(cls):
        """Get all configured LVM volume groups.
        """

        volume_groups = list()
        volume_grp_str = CmdExecutor(StringCommand('vgs')).execute()
        volume_grp_str = volume_grp_str.splitlines()
        volume_grp_str = volume_grp_str[1:]

        for line in volume_grp_str:
            line = re.sub(' +', ' ', line)
            result = line.split(' ')
            volume_groups.append(result[1])

        return volume_groups

    def get_exascaler_volume_groups(self):
        """ Get all EXAScaler volume groups.
        """

        lustre = Lustre(self._es_config)
        return lustre.get_all_volume_groups()

    def get_local_ost_targets(self):
        """ Get list of local ost targets.
        """

        lustre = Lustre(self._es_config)
        return lustre.local_ost_targets()

    def configure_lvm(self):
        """ Configure LVM.
        """

        all_volumes = self.get_all_configured_volume_groups()
        exascaler_volumes = self.get_exascaler_volume_groups()

        volumes = list(set(all_volumes) - set(exascaler_volumes))
        volumes_list = ', '.join(['"{0}"'.format(item) for item in volumes])

        if self._es_config.global_settings.vg_activation_list[0] == 'none':
            auto_activation_volume_list = None
        elif self._es_config.global_settings.vg_activation_list[0] == 'auto':
            auto_activation_volume_list = volumes_list
        else:
            auto_activation_volumes = self._es_config.global_settings.vg_activation_list
            for volume_grp in auto_activation_volumes:
                if volume_grp not in all_volumes:
                    raise ScalersException('Volume Group {0} does not exist'.format(volume_grp))
            auto_activation_volume_list = ', '.join(['"{0}"'.format(item) for item in auto_activation_volumes])

        lvm_template = Template(get_file_content('/opt/ddn/api/es/cluster/configurator/templates/lvm.conf.templ'))

        if auto_activation_volume_list:
            substitute_auto = 'auto_activation_volume_list = [ {0} ]'.format(auto_activation_volume_list)
        else:
            substitute_auto = ''

        substitute = 'volume_list = [ {0} ]'.format(volumes_list)

        with open('/etc/lvm/lvm.conf', 'w') as lvm_conf:
            lvm_conf.write(lvm_template.safe_substitute(
                auto_activation_volume_list=substitute_auto, volume_list=substitute))
            lvm_conf.write('\n')

        os.chmod('/etc/lvm/lvm.conf', 0644)

    def configure_zfs(self):
        """ Configure ZFS.
        """

        if not os.path.exists('/etc/hostid'):
            CommandExecutor(StringCommand('genhostid')).run()

    def configure_filesystem(self, dry_run=False):
        """ Create and tune Lustre filesystem.
        """

        lustre = Lustre(self._es_config)
        lustre.mkfs_on_local_node(wipe=False, reformat=False, dry_run=dry_run)

    def configure_dirs(self):
        """ Create all appropriate dirs.
        """

        for fs in self._es_config.global_settings.fs_list:
            makedirs(self._es_config.fs_settings[fs].log_dir)
            makedirs(os.path.join('/lustre', fs, 'client'))

        lustre = Lustre(self._es_config)
        lustre.create_local_mount_points()

    def configure(self, is_client=False):
        """ Configure Lustre.
        """

        self.configure_dirs()
        if not is_client:
            if 'zfs' in self._es_config.global_settings.used_backfs_types:
                self.configure_zfs()
            if 'ldiskfs' in self._es_config.global_settings.used_backfs_types:
                self.configure_lvm()
            self.configure_filesystem()

