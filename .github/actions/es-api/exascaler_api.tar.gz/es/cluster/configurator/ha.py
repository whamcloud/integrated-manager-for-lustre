# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level HA related functionality for EXAScaler API package.
"""

import os

from es.corosync import EXAScalerCorosync
from es.utils import get_hostname
from scalers.errors import ScalersException
from scalers.utils.command import StringCommand
from scalers.utils.cmd import CmdExecutor


class HAConfigurator(object):
    """ Configurator for HA.
    """

    def __init__(self, config, local_host_name=None):
        """ Basic initialization.
        """

        self._es_config = config
        self.host_name = local_host_name if local_host_name is not None else get_hostname()

        if (self.host_name not in self._es_config.global_settings.host_list) and \
                (self.host_name not in self._es_config.global_settings.clients_list):
            raise ScalersException("No configuration found for host '{0}'".format(self.host_name))

    def config_corosync(self):
        """ Tune '/etc/corosync/corosync.conf'.
        """

        corosync = EXAScalerCorosync(self._es_config)
        corosync.save_config()

    @staticmethod
    def _config_pacemaker_sysconfig(key, value):
        """ Tune '/etc/sysconfig/pacemaker' with appropriate values.
        """

        pacemaker_file_path = '/etc/sysconfig/pacemaker'

        if os.path.exists(pacemaker_file_path):

            new_content = ''

            with open(pacemaker_file_path, 'r') as pacemaker_file:
                for line in pacemaker_file:
                    if line.strip().startswith('{0}='.format(key)):
                        return
                    new_content += '{0}'.format(line)
                    if line.strip().startswith('# {0}'.format(key)):
                        new_content += '{0}={1}\n'.format(key, value)

            with open(pacemaker_file_path, 'w') as pacemaker_file:
                pacemaker_file.write(new_content)

            os.chmod(pacemaker_file_path, 0644)

    def config_pacemaker_sysconfig(self):
        """ Tune '/etc/sysconfig/pacemaker'
        """

        self._config_pacemaker_sysconfig('PCMK_logfile', 'none')
        self._config_pacemaker_sysconfig('PCMK_ipc_buffer', '13793948')

    @classmethod
    def config_pacemaker_profiled(cls):
        """ Tune '/etc/profile.d/pacemaker.sh'
        """

        with open('/etc/profile.d/pacemaker.sh', 'w') as pacemaker_file:
            pacemaker_file.write('source /etc/sysconfig/pacemaker\n')
            pacemaker_file.write('export PCMK_ipc_buffer\n')

        os.chmod('/etc/profile.d/pacemaker.sh', 0755)

    def configure_services(self):
        """ Configure services.
        """

        if self._es_config.flavour in ('SFA', 'HPC', 'ZFS',):
            if self._es_config.ha_settings.start_on_boot:
                CmdExecutor(StringCommand('systemctl enable corosync')).execute(ensure_success=False)
                CmdExecutor(StringCommand('systemctl enable pacemaker')).execute(ensure_success=False)
            if not self._es_config.ha_settings.start_on_boot:
                CmdExecutor(StringCommand('systemctl disable corosync')).execute(ensure_success=False)
                CmdExecutor(StringCommand('systemctl disable pacemaker')).execute(ensure_success=False)
        
    def configure(self):
        """ Configure HA.
        """

        if self._es_config.ha_settings is None or self._es_config.ha_settings.type != 'corosync':
            return

        self.configure_services()
        self.config_corosync()
        self.config_pacemaker_sysconfig()
        self.config_pacemaker_profiled()
