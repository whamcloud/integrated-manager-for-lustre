# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2017, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level REST API related functionality for EXAScaler API package.
"""

from es.utils import get_hostname
from scalers.errors import ScalersException
from rest.config import RestConf, RestNodeConf
from rest.configure.validators.static import validate_int_api_vip, validate_ha_id, validate_certs, \
    validate_nodes
from rest.configure.validators.runtime import check_node_interfaces
from rest.configure.message import MessageTemplates, set_templates
from rest.utils.net import get_interface_status
from rest.configure.deploy import deploy


class ESMessageTemplates(MessageTemplates):

    ERR_INT_VIP_FORMAT = "Incorrect IP format {ip} for 'int_vip' setting in 'rest'" \
                         " section of EXAScaler configuration file."
    ERR_INT_VIP_MASK = "'int_mask' setting in 'rest' section of EXAScaler configuration file " \
                       "must be an integer value in range 0..32"
    ERR_API_VIP_FORMAT = "Incorrect IP format {ip} for 'ext_vip' setting in 'rest'" \
                         " section of EXAScaler configuration file."
    ERR_API_VIP_MASK = "'ext_mask' setting in 'rest' section of EXAScaler configuration file " \
                       "must be an integer value in range 0..32"
    ERR_SAME_INT_API_VIP = "'int_vip' and 'ext_vip' settings in 'rest' section of EXAScaler" \
                           " configuration file must not be the same value: {ip}"
    ERR_VRID_VALUE = "'ka_vr_id' setting in 'rest' section of EXAScaler configuration file" \
                     " must be an integer value in range 1..255"
    ERR_SSL_FQDN_FORMAT = "Invalid server FQDN '{fqdn}' was mentioned in 'rest'" \
                          " section of EXAScaler configuration file."


class RestConfigurator(object):
    """ Configurator for REST API.
    """

    def __init__(self, config, local_host_name=None):
        """ Basic initialization.
        """

        self._es_config = config
        self.host_name = local_host_name if local_host_name is not None else get_hostname()

        if (self.host_name not in self._es_config.global_settings.host_list) and \
                (self.host_name not in self._es_config.global_settings.clients_list):
            raise ScalersException("No configuration found for host '{0}'".format(self.host_name))

    def configure(self):
        """ Configure REST API.
        """

        host_info = self._es_config.hosts_settings[self.host_name]
        if host_info.rest_primary_nic is not None:
            bind_ip = host_info.nics[host_info.rest_primary_nic].ip
        elif self._es_config.ha_settings is not None and self._es_config.ha_settings.type == 'corosync':
            bind_ip = host_info.nics[host_info.ring0].ip
        else:
            raise ScalersException("Unable to determine internal bind ip for host '{0}'".format(self.host_name))

        rest_config = RestConf()
        rest_config.int_vip = self._es_config.rest_settings.int_vip
        rest_config.int_vip_mask = self._es_config.rest_settings.int_mask
        rest_config.ext_vip = self._es_config.rest_settings.ext_vip
        rest_config.ext_vip_mask = self._es_config.rest_settings.ext_mask
        rest_config.ha_id = self._es_config.rest_settings.ka_vr_id
        rest_config.cert_ca = self._es_config.hosts_settings[self.host_name].rest_cert_ca
        rest_config.cert_server = self._es_config.hosts_settings[self.host_name].rest_cert_server
        rest_config.cert_server_key = self._es_config.hosts_settings[self.host_name].rest_cert_server_key
        rest_config.cert_crl = self._es_config.hosts_settings[self.host_name].rest_cert_crl
        rest_config.auth_ou = self._es_config.rest_settings.auth_ou
        rest_config.api_fqdn = self._es_config.rest_settings.ext_vip_fqdn
        set_templates(ESMessageTemplates())

        local_node = None
        for host in self._es_config.global_settings.host_list:
            node = RestNodeConf(host)
            node.api = host in self._es_config.rest_settings.master_nodes
            node.int_intf = self._es_config.hosts_settings[host].rest_int_nic
            node.int_bind_ip = bind_ip
            if host in self._es_config.rest_settings.master_nodes:
                node.ext_intf = self._es_config.hosts_settings[host].rest_ext_nic
                node.ha_intf = self._es_config.hosts_settings[host].rest_keepalived_nic
            rest_config.nodes.append(node)
            if host == self.host_name:
                local_node = node

        validate_int_api_vip(rest_config)
        validate_ha_id(rest_config)
        if self.host_name in self._es_config.rest_settings.master_nodes:
            validate_certs(rest_config)
        validate_nodes(rest_config)
        check_node_interfaces(local_node)
        rest_primary_nic = self._es_config.hosts_settings[self.host_name].rest_primary_nic
        if rest_primary_nic is not None:
            if not get_interface_status(rest_primary_nic, self.host_name):
                raise ScalersException("Interface '{0}' which was mentioned as"
                                       " 'rest_primary_nic' for local host is down.".format(rest_primary_nic))

        deploy(rest_config, [self.host_name, ])
