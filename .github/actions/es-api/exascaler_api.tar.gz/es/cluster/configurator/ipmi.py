# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level IPMI related functionality for EXAScaler API package.
"""

import os
import re

from scalers.errors import ScalersException
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import CommandExecutor, StringCommand
from es.utils import get_hostname, load_module

IPMITOOL_USER_RE = re.compile(r'^\s*(?P<id>\d+)\s+(?P<username>\S+).+$')


class IPMIConfigurator(object):
    """ Configurator for IPMI.
    """

    kernel_modules = ('ipmi_devintf', 'ipmi_si', )

    def __init__(self, config, local_host_name=None):
        """ Basic initialization.
        """

        self._es_config = config

        self.host_name = local_host_name if local_host_name is not None else get_hostname()

        if self.host_name not in self._es_config.hosts_settings:
            raise ScalersException("No configuration found for host '{0}'".format(self.host_name))

    @classmethod
    def ipmi_configuration_tool(cls):
        """ Get ipmi configuration tool.
        """

        for path in ('/usr/bin/ipmitool', '/usr/sbin/bmc-config', ):
            if os.path.exists(path):
                return path
        return None

    @classmethod
    def is_ipmi_device_exists(cls):
        """ Is IPMI device exists.
        """

        for path in ('/dev/ipmi0', '/dev/ipmi/0', '/dev/ipmidev/0', ):
            if os.path.exists(path):
                return True
        return False

    @classmethod
    def get_ipmi_channel(cls):
        """ Get IPMI lan channel.
        """

        for i in range(1, 4):
            result = CommandExecutor(StringCommand('{0} lan print {1}'.format(
                cls.ipmi_configuration_tool(), i))).run()
            if result.stdout.find('Auth') > 1:
                return i
        return None

    @classmethod
    def set_ipmitool_network(cls, ip, netmask, channel):
        """Set IPMI network configuration.
        """

        CmdExecutor(StringCommand('/usr/bin/ipmitool lan set {0} access on'.format(channel))).execute()
        output = CmdExecutor(StringCommand('/usr/bin/ipmitool lan print {0}'.format(channel))).execute()
        for line in output.splitlines():
            if line.lower().startswith('IP Address Source'.lower()):
                current_setting = line[line.find(': ') + 2:]
                if current_setting.lower().startswith('dhcp'):
                    CmdExecutor(StringCommand('/usr/bin/ipmitool lan set {0} ipsrc static'.format(channel))).execute()
                    break
        CmdExecutor(StringCommand('/usr/bin/ipmitool lan set {0} ipaddr {1}'.format(channel, ip))).execute()
        if netmask is not None:
            CmdExecutor(StringCommand('/usr/bin/ipmitool lan set {0} netmask {1}'.format(channel, netmask))).execute()

    @classmethod
    def set_ipmitool_gateway(cls, gateway, channel):
        """Set IPMI gateway.
        """

        CmdExecutor(StringCommand('/usr/bin/ipmitool lan set {0} defgw ipaddr {1}'.format(channel, gateway))).execute()

    @classmethod
    def set_bmc_config_network(cls, ip, netmask):
        """Set IPMI network configuration.
        """

        CmdExecutor(StringCommand('/usr/sbin/bmc-config -c -e "Lan_Conf:IP_Address_Source=Static"')).execute()
        CmdExecutor(StringCommand(
            '/usr/sbin/bmc-config -c -e "Lan_Conf:IP_Address={0} -e "Lan_Conf:Subnet_Mask={1}'.format(
                ip, netmask))).execute()

    @classmethod
    def set_ipmitool_password(cls, user_id, password):
        """ Set IPMI password.
        """

        CommandExecutor(StringCommand('/usr/bin/ipmitool set password {0}'.format(password))).run()
        CommandExecutor(StringCommand('ipmitool user set password {0} {1}'.format(user_id, password))).run()

    @classmethod
    def set_ipmitool_username(cls, user_id, username):
        """ Set IPMI user.
        """

        CmdExecutor(StringCommand('ipmitool user set name {0} {1}'.format(user_id, username))).execute()

    @classmethod
    def enable_user(cls, user_id):
        """ Enable ipmi user.
        """

        CmdExecutor(StringCommand('ipmitool user enable {0}'.format(user_id))).execute()

    @classmethod
    def set_admin_permissions_to_ipmitool_user(cls, user_id):
        """ Set admin permissions to ipmitool user.
        """

        channel = cls.get_ipmi_channel()
        CmdExecutor(StringCommand('ipmitool channel setaccess {0} {1} ipmi=true privilege=4'
                                  .format(channel, user_id))).execute()

    @classmethod
    def get_existing_ipmitool_user_ids(cls):
        """ Returns dict with usernames as keys and username ids as values.
        """

        channel = cls.get_ipmi_channel()
        command = 'ipmitool user list {0}'.format(channel)
        output = CmdExecutor(StringCommand(command)).execute()

        # Remove table header
        lines = output.splitlines()[1:]

        users = dict()
        for line in lines:
            match = IPMITOOL_USER_RE.match(line)
            if match is not None:
                username = match.group('username')
                users[username] = int(match.group('id'))
            else:
                raise ScalersException("Can't parse '{0}' output: \n{1}".format(command, output))

        return users

    def create_ipmitool_user(self, username, password):
        """ Update password for user if user exists else create new user.
        """

        if password is not None and username is None:
            raise ScalersException("Can't set password to ipmitool user without username")

        if username is None and password is None:
            return

        # If no password is given, the password is cleared.
        password = password if password is not None else ""

        user_ids = self.get_existing_ipmitool_user_ids()
        if username in user_ids:
            self.set_ipmitool_password(user_ids[username], password)
            self.enable_user(user_ids[username])
        else:
            new_user_id = max(user_ids.values()) + 1 if user_ids else 1
            self.set_ipmitool_username(new_user_id, username)
            self.set_ipmitool_password(new_user_id, password)
            self.enable_user(new_user_id)
            self.set_admin_permissions_to_ipmitool_user(new_user_id)

    def configure(self):
        """ Configure IPMI.
        """

        if 'ipmi' not in self._es_config.hosts_settings[self.host_name].nics:
            raise ScalersException("'No ipmi_ip specified for '{0}' in config file.".format(self.host_name))

        ipmi_cmd = self.ipmi_configuration_tool()
        if ipmi_cmd is None:
            raise ScalersException("No ipmi configuration tool found on '{0}'.".format(self.host_name))

        if not self.is_ipmi_device_exists():
            for kernel_module in self.kernel_modules:
                load_module(kernel_module)
            if not self.is_ipmi_device_exists():
                raise ScalersException('Unable to detect IPMI hardware.')

        ipmi_channel = self.get_ipmi_channel()
        if ipmi_channel is None:
            raise ScalersException('Could not find IPMI lan channel.')

        ip_addr = self._es_config.hosts_settings[self.host_name].nics['ipmi'].ip
        netmask = self._es_config.hosts_settings[self.host_name].nics['ipmi'].netmask
        if ipmi_cmd == '/usr/bin/ipmitool':
            self.set_ipmitool_network(ip_addr, netmask, ipmi_channel)
        elif ipmi_cmd == '/usr/sbin/bmc-config':
            self.set_bmc_config_network(ip_addr, netmask)

        if ipmi_cmd == '/usr/bin/ipmitool':

            if self._es_config.hosts_settings[self.host_name].nics['ipmi'].gateway is not None:
                gateway = self._es_config.hosts_settings[self.host_name].nics['ipmi'].gateway
                self.set_ipmitool_gateway(gateway, ipmi_channel)

            username = self._es_config.hosts_settings[self.host_name].stonith_user
            password = self._es_config.hosts_settings[self.host_name].stonith_pass
            self.create_ipmitool_user(username, password)
