# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" High-level networking related functionality for EXAScaler API package.
"""

import os

from scalers.errors import ScalersException
from scalers.utils.command import CommandExecutor, StringCommand
from es.utils import get_hostname


class NetworkingConfigurator(object):
    """ Configurator for networking.
    """

    def __init__(self, config, local_host_name=None):
        """ Basic initialization.
        """

        self._es_config = config
        self.host_name = local_host_name if local_host_name is not None else get_hostname()

        if (self.host_name not in self._es_config.global_settings.host_list) and \
                (self.host_name not in self._es_config.global_settings.clients_list):
            raise ScalersException("No configuration found for host '{0}'".format(self.host_name))

    def config_modprobe(self):
        """ Tune '/etc/modprobe.d/lustre.conf'.
        """

        with open('/etc/modprobe.d/lustre.conf', 'w') as lustre_conf:
            lnet_networks = self._es_config.hosts_settings[self.host_name].lnet_networks()
            lustre_conf.write('options lnet networks="{0}"\n'.format(lnet_networks))
            if self._es_config.hosts_settings[self.host_name].modprobe_cfg is not None:
                lustre_conf.write(self._es_config.hosts_settings[self.host_name].modprobe_cfg)

        os.chmod('/etc/modprobe.d/lustre.conf', 0644)

    @staticmethod
    def restart_network():
        """ Try to restart network.
        """

        CommandExecutor(StringCommand('service network restart')).run()

    def configure_hosts_file(self):
        """ Tune '/etc/hosts'.
        """

        with open('/etc/hosts', 'w') as hosts_file:

            hosts_file.write('# Do not remove the following line or various programs\n'
                             '# that require network functionality will fail.\n'
                             '\n'
                             '# This file was auto-generated.\n'
                             '\n'
                             '127.0.0.1               localhost.localdomain localhost\n'
                             '::1             localhost6.localdomain6 localhost6\n'
                             '\n'
                             '\n'
                             )

            nic_list = list()
            nic_hosts = dict()
            for host_key in self._es_config.global_settings.host_list:
                host = self._es_config.hosts_settings[host_key]
                first_nic = True

                nics = host.nic_list + ['ipmi', ]

                for nic in nics:
                    if nic not in host.nics:
                        continue
                    if host.nics[nic].ip is None:
                        continue
                    if nic not in nic_hosts:
                        nic_hosts[nic] = ''
                        nic_list.append(nic)
                    if first_nic:
                        nic_hosts[nic] += '{0} {1} {2}-{3}\n'.format(host.nics[nic].ip, host_key, host_key, nic)
                        first_nic = False
                    else:
                        nic_hosts[nic] += '{0} {1}-{2}\n'.format(host.nics[nic].ip, host_key, nic)

            for nic in nic_list:
                hosts_file.write(nic_hosts[nic])
                hosts_file.write('\n')

            for sfa_name in self._es_config.global_settings.sfa_list:
                for cont_num, cont_ip in enumerate(self._es_config.sfa_settings[sfa_name].controllers):
                    hosts_file.write('{0} {1}-c{2}\n'.format(cont_ip, sfa_name, cont_num))
                if self._es_config.sfa_settings[sfa_name].controllers:
                    hosts_file.write('\n')

        os.chmod('/etc/hosts', 0644)

    def configure_hostname_file(self):
        """Tune /etc/hostname
        """

        with open('/etc/hostname', 'w') as hostname_file:
            hostname_file.write('{0}\n'.format(self.host_name))
        os.chmod('/etc/hostname', 0644)

    def configure_clush(self):
        """ Configure clush utility.
        """

        with open('/etc/clustershell/groups.d/local.cfg', 'w') as clush_groups_file:

            oss_list = list()
            mds_list = list()
            mgs_list = list()
            for fs in self._es_config.fs_settings.values():
                oss_list.extend(fs.oss_list)
                mds_list.extend(fs.mds_list)
                mgs_list.extend(fs.mgs_list)
            oss_list = list(set(oss_list))
            mds_list = list(set(mds_list))
            mgs_list = list(set(mgs_list))

            clush_groups_file.write('oss: {0}\n'.format(' '.join(sorted(oss_list))))
            clush_groups_file.write('mds: {0}\n'.format(' '.join(sorted(mds_list))))
            clush_groups_file.write('mgs: {0}\n'.format(' '.join(sorted(mgs_list))))
            clush_groups_file.write('all: @oss @mds @mgs\n')

            sfa_controllers = []
            for sfa_name in self._es_config.global_settings.sfa_list:
                for cont_num, _ in enumerate(self._es_config.sfa_settings[sfa_name].controllers):
                    sfa_controllers.append('{0}-c{1}'.format(sfa_name, cont_num))
            if sfa_controllers:
                clush_groups_file.write('sfa: {0}\n'.format(' '.join(sorted(sfa_controllers))))

            if self._es_config.ha_settings is not None:
                for idx, ha_group in enumerate(self._es_config.ha_settings.ha_groups):
                    clush_groups_file.write('ha_group{0}: {1}\n'.format(idx, ' '.join(ha_group)))
                ha_heads = [ha_group[0] for ha_group in self._es_config.ha_settings.ha_groups]
                clush_groups_file.write('ha_heads: {0}\n'.format(' '.join(sorted(ha_heads))))

        os.chmod('/etc/clustershell/groups.d/local.cfg', 0644)

    def _generate_ifconfig_filename(self, nic):
        """ Generate a filename for ifcfg-* file.
        """

        device = self._es_config.hosts_settings[self.host_name].nics[nic].device
        cfg_filename = 'ifcfg-{0}'.format(nic)
        if device != nic:
            device_filename = 'ifcfg-{0}'.format(device)
            nic_file = os.path.join('/etc/sysconfig/network-scripts/', cfg_filename)
            if not os.path.exists(nic_file):
                cfg_filename = device_filename

        return cfg_filename

    def configure_ifconfig(self):
        """ Tune ifcfg-* files.
        """

        for nic in self._es_config.hosts_settings[self.host_name].nic_list:

            ifcfg_file_name = os.path.join('/etc/sysconfig/network-scripts/', self._generate_ifconfig_filename(nic))
            with open(ifcfg_file_name, 'w') as ifcfg:
                device = self._es_config.hosts_settings[self.host_name].nics[nic].device
                ifcfg.write('DEVICE={0}\n'.format(device))
                ifcfg.write('ONBOOT=yes\n')
                ifcfg.write('NOZEROCONF=yes\n')

                if self._es_config.hosts_settings[self.host_name].nics[nic].cfg is not None:
                    ifcfg.write('{0}\n'.format(self._es_config.hosts_settings[self.host_name].nics[nic].cfg))

                if self._es_config.hosts_settings[self.host_name].nics[nic].master is not None:
                    ifcfg.write('MASTER={0}\n'.format(self._es_config.hosts_settings[self.host_name].nics[nic].master))
                    ifcfg.write('SLAVE=yes\n')
                else:
                    ifcfg.write('IPADDR={0}\n'.format(self._es_config.hosts_settings[self.host_name].nics[nic].ip))
                    ifcfg.write('NETMASK={0}\n'.format(
                        self._es_config.hosts_settings[self.host_name].nics[nic].netmask))

                    if self._es_config.hosts_settings[self.host_name].nics[nic].gateway is not None:
                        ifcfg.write('GATEWAY={0}\n'.format(
                            self._es_config.hosts_settings[self.host_name].nics[nic].gateway))

            os.chmod(ifcfg_file_name, 0644)

    def configure_network(self):
        """ Tune '/etc/sysconfig/network'.
        """

        with open('/etc/sysconfig/network', 'w') as network_file:

            gateway_device = None
            for nic in self._es_config.hosts_settings[self.host_name].nic_list:
                if self._es_config.hosts_settings[self.host_name].nics[nic].gateway is None:
                    continue
                gateway_device = self._es_config.hosts_settings[self.host_name].nics[nic].device
                break

            network_file.write('\n')
            network_file.write('NETWORKING=yes\n')
            network_file.write('NETWORKING_IPV6=no\n')
            network_file.write('HOSTNAME={0}\n'.format(self.host_name))
            if gateway_device is not None:
                network_file.write('GATEWAYDEV={0}\n'.format(gateway_device))
            network_file.write('\n')

        os.chmod('/etc/sysconfig/network', 0644)

    def configure_bonding(self):
        """ Tune '/etc/modprobe.d/bonding.conf'
        """

        if self._es_config.hosts_settings[self.host_name].bonding_mode is None:
            return

        for nic in self._es_config.hosts_settings[self.host_name].nic_list:
            if self._es_config.hosts_settings[self.host_name].nics[nic].is_bonded:
                with open('/etc/modprobe.d/bonding.conf', 'w') as bonding_file:
                    bonding_file.write('\n')
                    bonding_file.write('alias {0} bonding\n'.format(nic))
                    bonding_file.write('options bonding miimon=100 mode={0}'.format(
                        self._es_config.hosts_settings[self.host_name].bonding_mode))
                    bonding_file.write('\n')
                os.chmod('/etc/modprobe.d/bonding.conf', 0644)
                return

    def configure_nics(self):
        """ Configure network interfaces.
        """

        self.configure_ifconfig()
        self.configure_network()
        self.configure_bonding()

    def configure_hosts(self):
        """ Configure information about hosts.
        """

        self.configure_hostname_file()
        self.configure_hosts_file()
        self.configure_clush()

    def configure(self):
        """ Configure networking.
        """

        self.configure_nics()
        self.configure_hosts()
        self.config_modprobe()
