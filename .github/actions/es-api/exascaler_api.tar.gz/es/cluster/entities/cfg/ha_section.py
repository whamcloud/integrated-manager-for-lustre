# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" HA section of EXAScaler configuration file.
"""

from itertools import chain

from es.cluster.entities.cfg.section import EsConfigSection
from es.cluster.entities.cfg.utils import parse_nodespec, split_list_settings
from scalers.errors import ScalersException


class HASection(EsConfigSection):
    """ HA section of EXAScaler configuration file.
    """

    def __init__(self, config, shadow_config=None):
        """ Basic initialization.
        """

        self.corosync_nics = list()

        self.no_quorum_policy = 'freeze'
        self.type = 'corosync'
        self.transport = 'multicast'
        self.failover_policy = 'standard'
        self.rrp_mode = 'passive'
        self.crypto_hash = 'sha1'
        self.crypto_cipher = 'aes256'
        self.secauth = 'on'
        self.netmtu = 1500
        self.window_size = 50
        self.max_messages = 17

        self.mcastport = 5405
        self.ha_group_count = None

        self.dampen_ping = 20
        self.dampen_ifspeed = 20

        self.stonith_timeout = 60
        
        self.zpool_monitor_timeout = 60
        self.lustre_start_timeout = 450

        self.start_on_boot = True

        # Calculated
        self.ha_groups = list()

        super(HASection, self).__init__(config, 'HA', shadow_config)

    def to_dict(self):
        """ Convert to dictionary.
        """

        fields = ('corosync_nics', 'no_quorum_policy', 'type', 'transport', 'failover_policy', 'rrp_mode',
                  'mcastport', 'ha_group_count', 'start_on_boot', 'ha_groups', 'dampen_ping', 'dampen_ifspeed',
                  'crypto_hash', 'crypto_cipher', 'secauth', 'netmtu', 'window_size', 'max_messages', 'stonith_timeout',
                  'zpool_monitor_timeout', 'lustre_start_timeout')

        result = {field: getattr(self, field) for field in fields}

        return result

    def _configure_section(self):
        """ Divide settings according their types.
        Set mandatory,comma separated list, space separated list, str, bool,
        int, list of nodes fields if it is necessary.
        """

        self._str_fields = ['no_quorum_policy', 'type', 'transport', 'failover_policy', 'rrp_mode', 'crypto_hash',
                            'crypto_cipher', 'secauth', ]
        self._space_separated_list_fields = ['corosync_nics', ]
        self._int_fields = ['mcastport', 'ha_group_count', 'dampen_ping', 'dampen_ifspeed', 'netmtu', 'window_size',
                            'max_messages', 'stonith_timeout', 'zpool_monitor_timeout', 'lustre_start_timeout']
        self._bool_fields = ['start_on_boot', ]

    def _check_settings(self):
        """ Verify obtained settings.
        """

        valid_ha_types = ['none', 'corosync', ]
        if self.type not in valid_ha_types:
            raise ScalersException("Invalid HA type '{0}' in 'HA' section of EXAScaler configuration file. "
                                   "Possible values are: {1}".format(self.type, ','.join(valid_ha_types)))

        valid_policy = ['freeze', 'stop', 'ignore', ]
        if self.no_quorum_policy not in valid_policy:
            raise ScalersException("Invalid quorum policy '{0}' in 'HA' section of EXAScaler configuration file. "
                                   "Possible values are: {1}".format(self.no_quorum_policy, ','.join(valid_policy)))

        valid_failover_policy = ['standard', 'round-robin']
        if self.failover_policy not in valid_failover_policy:
            raise ScalersException("Invalid failover policy '{0}' in 'HA' section of EXAScaler configuration file. "
                                   "Possible values are: {1}".format(self.failover_policy,
                                                                     ','.join(valid_failover_policy)))

        valid_rrp_mode = ['none', 'active', 'passive']
        if self.rrp_mode not in valid_rrp_mode:
            raise ScalersException(
                "Invalid rrp_mode corosync value '{0}' in 'HA' section of EXAScaler configuration file."
                " Possible values are: {1}".format(self.rrp_mode, ','.join(valid_rrp_mode)))

        valid_transports = ['unicast', 'multicast', ]
        if self.type == 'corosync' and self.transport not in valid_transports:
            raise ScalersException("Invalid HA transport value '{0}' in 'HA' section of EXAScaler configuration file."
                                   " Possible values are: {1}".format(self.transport, ','.join(valid_transports)))

        valid_crypto_hash = ['none', 'md5', 'sha1', 'sha256', 'sha384', 'sha512']
        if self.type == 'corosync' and self.crypto_hash not in valid_crypto_hash:
            raise ScalersException("Invalid HA crypro_hash value '{0}' in 'HA' section of EXAScaler configuration file."
                                   " Possible values are: {1}".format(self.crypto_hash, ','.join(valid_crypto_hash)))

        valid_crypto_cipher = ['none', 'aes256', 'aes192', 'aes128', '3des']
        if self.type == 'corosync' and self.crypto_cipher not in valid_crypto_cipher:
            raise ScalersException("Invalid HA crypro_cipher value '{0}' in 'HA' section of EXAScaler configuration file."
                                   " Possible values are: {1}".format(self.crypto_cipher, ','.join(valid_crypto_cipher)))

        if self.crypto_cipher != 'none' and self.crypto_hash == 'none':
            raise ScalersException("Invalid HA crypro_cipher and crypto_hash combination in 'HA' "
                                   "section of EXAScaler configuration file."
                                   " Enabling 'crypto_cipher', requires also enabling of 'crypto_hash'.")

        valid_secauth = ['on', 'off', ]
        if self.type == 'corosync' and self.secauth not in valid_secauth:
            raise ScalersException("Invalid HA secauth value '{0}' in 'HA' section of EXAScaler configuration file."
                                   " Possible values are: {1}".format(self.secauth, ','.join(valid_secauth)))

        if self.type == 'corosync':
            if len(self.corosync_nics) == 0:
                raise ScalersException(
                    "At least 'ring0' should be specified in corosync_nics if HA type is 'corosync'.")
            elif len(self.corosync_nics) == 1:
                if self.corosync_nics[0] != 'ring0':
                    raise ScalersException(
                        "'ring0' is only one available option in case of one corosync network interface enabled.")
            elif len(self.corosync_nics) == 2:
                if 'ring0' not in self.corosync_nics:
                    raise ScalersException("'ring0' is missed in corosync network interface description.")
                if 'ring1' not in self.corosync_nics:
                    raise ScalersException("'ring1' is missed in corosync network interface description.")
            else:
                raise ScalersException(
                    "Maximum number of corosync network interfaces is 2. Possible values are: 'ring0' and 'ring1'.")

    def _parse_ha_groups(self):
        """ Parse mentioned ha groups with appropriate indexes.
        """

        if self.ha_group_count is not None:
            for ha_group_idx in xrange(self.ha_group_count):
                ha_group_param = 'ha_group{0}'.format(ha_group_idx)
                if ha_group_param in self.unknown_settings:
                    value = self.unknown_settings[ha_group_param]
                    del self.unknown_settings[ha_group_param]
                    parsed_value = parse_nodespec(split_list_settings(value, ' '))
                    self.ha_groups.append(parsed_value)
                else:
                    raise ScalersException("HA group description '{0}' is missed in HA section of EXAScaler"
                                           " configuration file.".format(ha_group_param))

    def _perform_custom_tunings(self):
        """ Perform custom tunings for obtained settings.
        """

        settings = chain(self._str_fields, self._space_separated_list_fields, self._int_fields, self._bool_fields,
                         self._list_of_nodes_fields, )
        for setting in settings:
            if setting in self._untuned_settings:
                setattr(self, setting, self._untuned_settings[setting])

        self._parse_ha_groups()
