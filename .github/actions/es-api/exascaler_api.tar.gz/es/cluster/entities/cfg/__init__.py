# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

import os
import ConfigParser
import re
import stat
from itertools import chain

from es.cluster.entities.cfg.section import EsConfigSection
from es.cluster.entities.cfg.global_section import GlobalSection
from es.cluster.entities.cfg.ha_section import HASection
from es.cluster.entities.cfg.host_defaults_section import HostDefaultsSection
from es.cluster.entities.cfg.hsm_section import HSMSection
from es.cluster.entities.cfg.esui_section import EsuiSection
from es.cluster.entities.cfg.filesystem_section import FilesystemSection
from es.cluster.entities.cfg.pool_section import PoolSection
from es.cluster.entities.cfg.zpool_section import ZpoolSection
from es.cluster.entities.cfg.host_section import HostSection
from es.cluster.entities.cfg.extra_section import ExtraSection
from es.cluster.entities.cfg.sfa_section import SFASection
from es.cluster.entities.cfg.rest_section import RestSection
from es.utils import get_file_content
from scalers.errors import ScalersException
from scalers.utils.command import StringCommand
from scalers.utils.cmd import CmdExecutor


class EXAScalerConfig(object):
    """ EXAScaler configuration.
    """

    class EXAScalerConfigParser(ConfigParser.ConfigParser):
        """ Custom ConfigParser implementation which overrides standard optionxform method.
        """

        def _tune_aliased_nic_names(self):
            """ Replace all occurrences of strings like 'ib0-alias0' with sth like 'ib0:0' in all keys and values of
                'host_defaults' and 'host' sections of exascaler.conf.
            """

            aliased_nic_regex = r'(?P<nic>\w+)-alias(?P<alias>\d+)(?P<param>\w*)'
            for section_data in (v for k, v in self._sections.iteritems() if k.startswith('host')):
                for key, value in section_data.items():
                    match = re.search(aliased_nic_regex, key)
                    if match:
                        section_data['{nic}:{alias}{param}'.format(**match.groupdict())] = section_data.pop(key)
                for key in ('nic_list', 'lnets', 'ring0', 'ring1'):
                    if key in section_data:
                        section_data[key] = re.sub(aliased_nic_regex, '\g<nic>:\g<alias>\g<param>', section_data[key])

        def read(self, filenames):
            ConfigParser.ConfigParser.read(self, filenames)
            self._tune_aliased_nic_names()

        def optionxform(self, optionstr):
            """ Custom optionxform implementation which doesn't cast optionstr to lowercase.
            """

            return optionstr

    def ha_group_list(self, hostname):
        """ Return the list of host names in the same group as hostname

        This is a solution method rather than a host method as the host does not have
        visibility of the ha_groups data currently.  A better long term solution might be
        to create a "ha group" object and have the hosts reference that.
        """
        if hostname in self.global_settings.clients_list:
            return list()
        return self.ha_settings.ha_groups[self.hosts_settings[hostname].ha_group_idx]

    def _tune_global(self):
        """ Tune global settings.
        """

        if not self.config.has_section('global'):
            raise ScalersException("Unable to found 'global' section in EXAScaler configuration file")

        self.global_settings = GlobalSection(self.config)

        if self.global_settings.shadow_conf:
            shadow_fname = os.path.basename(self.config_file.replace('.conf', '-shadow.conf'))
            shadow_path = os.path.join(os.path.dirname(self.config_file), shadow_fname)
            if not os.path.exists(shadow_path):
                raise ScalersException('{0} must exist if shadow_conf set to True'.format(shadow_fname))

            file_stat = os.stat(shadow_path)
            mode = file_stat.st_mode
            if mode & stat.S_IRUSR and mode & stat.S_IWUSR and not (mode & stat.S_IROTH or mode & stat.S_IWOTH
                                                                    or mode & stat.S_IXOTH or mode & stat.S_IRGRP
                                                                    or mode & stat.S_IWGRP or mode & stat.S_IXGRP):
                self.shadow_config = self.EXAScalerConfigParser()
                self.shadow_config.read(shadow_path)
                self.global_settings = GlobalSection(self.config, shadow_config=self.shadow_config)
            else:
                raise ScalersException("Only owner of '{0}' file should have each of "
                                       "read and write permissions.".format(shadow_fname))

        if self.config.has_section('set_param_tunings'):
            self.global_settings.set_param_tunings = ExtraSection(
                self.config_file, 'set_param_tunings', shadow_config=self.shadow_config)
        if self.config.has_section('conf_param_tunings'):
            self.global_settings.conf_param_tunings = ExtraSection(
                self.config_file, 'conf_param_tunings', shadow_config=self.shadow_config)

    def _tune_ha(self):
        """ Tune HA settings.
        """

        if not self.config.has_section('HA'):
            self.ha_settings = None
            return

        self.ha_settings = HASection(self.config, shadow_config=self.shadow_config)

        if self.ha_settings.ha_group_count is None:
            self.ha_settings.ha_groups = [self.global_settings.host_list[:], ]
            self.ha_settings.ha_group_count = 1

        cur_ha_group = 0
        for host_list in self.ha_settings.ha_groups:
            for host in host_list:

                if host not in self.hosts_settings:
                    raise ScalersException("Unknown host '{0}' in host group references ".format(host))

                for key in ('peers', 'stonith_primary_peers', 'stonith_secondary_peers', ):
                    if len(getattr(self.hosts_settings[host], key)) > 0:
                        for remote_host in getattr(self.hosts_settings[host], key):
                            if remote_host not in host_list:
                                raise ScalersException('Host {0} peer {1} not in same HA group ({2})'.format(
                                    host, remote_host, key))

                if self.hosts_settings[host].has_stonith_peers():
                    for remote_host in self.hosts_settings[host].stonith_primary_peers:
                        if self.hosts_settings[remote_host].has_stonith_peers():
                            if host in self.hosts_settings[remote_host].stonith_secondary_peers:
                                raise ScalersException("The stonith primary peer '{0}' for host '{1}', cannot make it"
                                                       " as its secondary peer".format(remote_host, host))

                if self.hosts_settings[host].ha_group_idx is not None:
                    raise ScalersException("Host '{0}' listed in more than one ha_group ('{1}' & '{2}')".format(
                        host, self.hosts_settings[host].ha_group_idx, cur_ha_group))

                self.hosts_settings[host].ha_group_idx = cur_ha_group
                self.hosts_settings[host].ha_group = self.ha_settings.ha_groups[cur_ha_group][:]
            cur_ha_group += 1

        if self.ha_settings.ha_group_count > 1:
            for host in self.global_settings.host_list:
                if self.hosts_settings[host].ha_group_idx is None:
                    raise ScalersException("Host '{0}' not listed in any ha_group".format(host))

        if self.ha_settings.type == 'corosync':
            for host in self.global_settings.host_list:
                for ring in self.ha_settings.corosync_nics:
                    if getattr(self.hosts_settings[host], ring) is None:
                        raise ScalersException("'{0}' value is missed for '{1}' host.".format(ring, host))
                    if getattr(self.hosts_settings[host], ring) not in self.hosts_settings[host].nics:
                        raise ScalersException(
                            "Unknown network interface '{0}' for '{1}' in  host {2} description.".format(
                                getattr(self.hosts_settings[host], ring),
                                ring,
                                host
                            ))

        for host in self.global_settings.host_list:
            if self.hosts_settings[host].has_stonith_peers():
                for run_host in self.ha_group_list(host):
                    if run_host in self.hosts_settings[host].stonith_primary_peers and run_host \
                            in self.hosts_settings[host].stonith_secondary_peers:
                        raise ScalersException(
                            "'{0}' is specified as primary and secondary stonith peer.".format(run_host))

        for host_name in self.global_settings.host_list:
            ha_group_idx = self.hosts_settings[host_name].ha_group_idx
            for lnet, _ in self.hosts_settings[host_name].parse_lnets():
                if lnet not in self.hosts_settings[host_name].lnet_members:
                    self.hosts_settings[host_name].lnet_members[lnet] = list()
                for host in self.ha_settings.ha_groups[ha_group_idx]:
                    if lnet in self.hosts_settings[host].host_nids_dict():
                        self.hosts_settings[host_name].lnet_members[lnet].append(
                            self.hosts_settings[host].host_nids_dict()[lnet]
                        )


    def _tune_esui(self):
        """ Tune esui settings.
        """
        if not self.config.has_section('ESUI'):
            self.esui_settings = None
        else:
            self.esui_settings = EsuiSection(self.config, shadow_config=self.shadow_config)


    def _tune_fs(self):
        """ Tune fs settings.
        """

        self.fs_settings = dict()
        self.pool_settings = dict()
        mgs_count = 0
        mgs_fs = None

        for fs in self.global_settings.fs_list:

            if not self.config.has_section('fs {0}'.format(fs)):
                raise ScalersException("Unable to found 'fs {0}' section in EXAScaler configuration file ".format(fs))

            self.fs_settings[fs] = FilesystemSection(
                self.config, fs, self.global_settings.log_dir, shadow_config=self.shadow_config)
            self.global_settings.add_hosts_to_host_list(self.fs_settings[fs].host_list)

            if self.fs_settings[fs].mgs_internal:
                mgs_count += 1
                self.global_settings.mgs_fs = mgs_fs = fs

            if self.fs_settings[fs].mdt_failback is None:
                self.fs_settings[fs].mdt_failback = (len(self.global_settings.fs_list) != 1)

            if self.fs_settings[fs].mgs_failback is None:
                self.fs_settings[fs].mgs_failback = self.fs_settings[fs].mdt_failback

            for pool in self.fs_settings[fs].pools:
                if not self.config.has_section('pool {0}'.format(pool)):
                    raise ScalersException(
                        "Unable to found 'pool {0}' section in EXAScaler configuration file ".format(pool))
                self.pool_settings[pool] = PoolSection(self.config, pool, shadow_config=self.shadow_config)

        for fs in self.global_settings.fs_list:
            if not self.fs_settings[fs].mgs_internal:
                if self.fs_settings[fs].mgs_fs is None:
                    raise ScalersException('Filesystem not specified for external mgs in fs: %s' % fs)

                external_fs = self.fs_settings[fs].mgs_fs
                if external_fs not in self.global_settings.fs_list:
                    raise ScalersException('Invalid mgs_fs for fs: %s' % fs)
                if not self.fs_settings[external_fs].mgs_internal:
                    raise ScalersException('External mgs fs %s should have mgs_internal = True' % external_fs)

        if mgs_count != 1:
            raise ScalersException('Exactly one fs must set mgs_internal = True')

        # Ensure that the fs with the mgs is at the start of the list
        self.global_settings.fs_list.remove(mgs_fs)
        self.global_settings.fs_list.insert(0, mgs_fs)

        self.global_settings.used_backfs_types = set(fs.backfs for fs in self.fs_settings.itervalues())
        if len(self.global_settings.used_backfs_types) > 1:
            raise ScalersException('All lustre filesystems defined in EXAScaler config must use the same backfs.')

    def _tune_zpools(self):
        """ Tune zpools settings.
        """

        self.zpool_settings = dict()
        for fs in self.global_settings.fs_list:
            fs_settings = self.fs_settings[fs]
            if fs_settings.backfs == 'zfs':
                for zpool in chain(fs_settings.mgs_zpools, fs_settings.mdt_zpools, fs_settings.ost_zpools):
                    self.zpool_settings[zpool] = ZpoolSection(self.config, zpool, shadow_config=self.shadow_config)

    def _tune_hsm(self):
        """ Tune HSM settings.
        """

        if self.global_settings.hsm_active:
            if not self.config.has_section('HSM'):
                raise ScalersException("Unable to found 'HSM' section in EXAScaler configuration file")
            self.hsm_settings = HSMSection(self.config, shadow_config=self.shadow_config)
        else:
            self.hsm_settings = None if not self.config.has_section('HSM') else HSMSection(
                self.config, shadow_config=self.shadow_config)

    def _tune_hosts(self):
        """ Tune hosts settings.
        """

        self.hosts_settings = dict()

        for host in self.global_settings.host_list:
            self.hosts_settings[host] = HostSection(
                self.config, host, self.host_defaults_settings, shadow_config=self.shadow_config)

        for host in self.global_settings.clients_list:
            self.hosts_settings[host] = HostSection(
                self.config, host, self.host_defaults_settings, shadow_config=self.shadow_config)

        sysctl_defaults = ExtraSection(self.config_file, 'sysctl_defaults', shadow_config=self.shadow_config)\
            if self.config.has_section('sysctl_defaults') else None

        for host in self.global_settings.host_list:

            if self.config.has_section('sysctl {0}'.format(host)):
                self.hosts_settings[host].sysctl = \
                    ExtraSection(
                        self.config_file,
                        'sysctl {0}'.format(host),
                        sysctl_defaults.settings if sysctl_defaults is not None else None,
                        shadow_config=self.shadow_config)
            else:
                self.hosts_settings[host].sysctl = sysctl_defaults

            if self.hosts_settings[host].stonith_type == 'sfa10ke':
                if not self.hosts_settings[host].has_stonith_peers:
                    raise ScalersException("stonith_primary_peers list needed for host '{0}' as stonith_type"
                                           " is sfa10ke".format(host))
                if self.hosts_settings[host].oid is None:
                    raise ScalersException("Stonith type set to sfa10ke but no OID defined for host '{0}'".format(host))

            elif self.hosts_settings[host].stonith_type != 'sfa_vm' and self.hosts_settings[host].oid is not None:

                raise ScalersException("Stonith type not set to sfa10ke or sfa_vm but OID defined for host '{0}'".format(host))

            if self.hosts_settings[host].stonith_type == 'sfa_vm':
                if len(self.hosts_settings[host].host_sfa_list) < 1:
                    raise ScalersException("Host: '{0}'. host_sfa_list cannot be empty for VM stonith".format(host))

            for key in ('peers', 'stonith_primary_peers', 'stonith_secondary_peers', ):
                if len(getattr(self.hosts_settings[host], key)) == 0:
                    continue
                for remote_host in getattr(self.hosts_settings[host], key):
                    if remote_host not in self.hosts_settings:
                        raise ScalersException("Host references unknown host. Host: '{0}'. Remote host: '{1}'.".format(
                            host, remote_host))

            if len(self.hosts_settings[host].peers) > 0:
                if host in self.hosts_settings[host].peers:
                    raise ScalersException("Cannot list host '{0}' in it's own peers list".format(host))
                for fs_name, ost_device_path in self.hosts_settings[host].ost_device_paths.itervalues():
                    for peer_host in self.hosts_settings[host].peers:
                        peer_ost_device_path = self.hosts_settings[peer_host].ost_device_paths.get(fs_name)
                        if peer_ost_device_path and peer_ost_device_path != ost_device_path:
                            raise ScalersException("Host '{0}' is peer of '{1}' but their ost_device_path for '{}'"
                                                   " filesystem differs".format(peer_host, host, fs_name))
                for fs_name, mdt_base_device_path in self.hosts_settings[host].mdt_base_device_paths.itervalues():
                    for peer_host in self.hosts_settings[host].peers:
                        peer_mdt_base_device_path = self.hosts_settings[peer_host].mdt_base_device_paths.get(fs_name)
                        if peer_mdt_base_device_path and peer_mdt_base_device_path != mdt_base_device_path:
                            raise ScalersException("Host '{0}' is peer of '{1}' but their mdt_base_device_path for '{}'"
                                                   " filesystem differs".format(peer_host, host, fs_name))

    def _parse_es_install_version_file(self):
        """ Get EXAScaler version and flavour from '/etc/es_install_version' file.
        """

        if os.path.exists('/etc/es_install_version'):

            content = get_file_content('/etc/es_install_version')

            template = re.compile(r"^\s*EXAScaler\s(?P<flavour>\S+)\s(?P<distro>\S+)"
                                  r"\s(?P<major>\d+)\.(?P<minor>\d+)\.(?P<revision>\d+)-(?P<release>\S+)\s*$")

            match = template.match(content)
            if match is not None:
                self.flavour = match.group('flavour')
                self.distro = match.group('distro')
                major = int(match.group('major'))
                minor = int(match.group('minor'))
                rev = int(match.group('revision'))
                self.version = (major, minor, rev,)

    def _parse_es_drivers_type_file(self):
        """ Get EXAScaler drivers type from '/etc/es_drivers_type' file.
        """

        if os.path.exists('/etc/es_drivers_type'):
            content = get_file_content('/etc/es_drivers_type')
            self.drivers_type = content.strip()

    def _tune_sfa(self):
        """ Tune SFA settings.
        """

        self.sfa_settings = dict()

        for sfa in self.global_settings.sfa_list:

            if not self.config.has_section('sfa {0}'.format(sfa)):
                raise ScalersException("Unable to found sfa '{0}' section in EXAScaler configuration file ".format(sfa))

            self.sfa_settings[sfa] = SFASection(self.config, sfa, shadow_config=self.shadow_config)

        for host_name, host_object in self.hosts_settings.items():
            for host_sfa in host_object.host_sfa_list:
                if host_sfa not in self.sfa_settings:
                    raise ScalersException("Unknown SFA '{0}' in sfa list for host '{1}'.".format(host_sfa, host_name))

    def _tune_rest(self):
        """ Tune REST API settings.l
        """

        if not self.config.has_section('rest'):
            self.rest_settings = None
            return

        if self.global_settings.cluster_name is None:
            raise ScalersException("Mandatory field 'cluster_name' is missed in 'global' section"
                                   " of EXAScaler config file.")

        self.rest_settings = RestSection(self.config, shadow_config=self.shadow_config)

        for host in self.rest_settings.master_nodes:
            if host not in self.global_settings.host_list:
                raise ScalersException("Unknown host '{0}' was defined as a REST master node.".format(host))
            if self.hosts_settings[host].rest_ext_nic is None:
                raise ScalersException("rest_ext_nic setting was missed for '{0}' host.".format(host))
            if self.hosts_settings[host].rest_ext_nic is not None and self.hosts_settings[host].rest_ext_nic not \
                    in self.hosts_settings[host].nics:
                raise ScalersException("Unknown network interface '{0}' mentioned as rest_ext_nic "
                                       "in host {1} description.".format(self.hosts_settings[host].rest_ext_nic, host))
            if self.hosts_settings[host].rest_cert_ca is None:
                raise ScalersException("rest_cert_ca setting is missed in REST API configuration"
                                       " for '{0}' node.".format(host))
            if self.hosts_settings[host].rest_cert_server is None:
                raise ScalersException("rest_cert_server setting is missed in REST API configuration"
                                       " for '{0}' node.".format(host))
            if self.hosts_settings[host].rest_cert_server_key is None:
                raise ScalersException("rest_cert_server_key setting is missed in REST API configuration"
                                       " for '{0}' node.".format(host))

        for host in self.global_settings.host_list:

            if self.hosts_settings[host].rest_int_nic is None:
                raise ScalersException("rest_int_nic setting was missed for '{0}' host.".format(host))
            if self.hosts_settings[host].rest_int_nic is not None and self.hosts_settings[host].rest_int_nic not \
                    in self.hosts_settings[host].nics:
                raise ScalersException("Unknown network interface '{0}' mentioned as rest_int_nic "
                                       "in host {1} description.".format(self.hosts_settings[host].rest_int_nic, host))

            if self.hosts_settings[host].rest_keepalived_nic is not None \
                    and self.hosts_settings[host].rest_keepalived_nic not in self.hosts_settings[host].nics:
                raise ScalersException("Unknown network interface '{0}' mentioned as rest_primary_nic in host {1} "
                                       "description.".format(self.hosts_settings[host].rest_keepalived_nic, host))

            if self.ha_settings is None or self.ha_settings.type != 'corosync':
                if self.hosts_settings[host].rest_primary_nic is None:
                    raise ScalersException("You should specify rest_primary_nic parameter for '{0}' host.".format(host))
            if self.hosts_settings[host].rest_primary_nic is not None \
                    and self.hosts_settings[host].rest_primary_nic not in self.hosts_settings[host].nics:
                raise ScalersException("Unknown network interface '{0}' mentioned as rest_primary_nic in host {1} "
                                       "description.".format(self.hosts_settings[host].rest_primary_nic, host))

        if self.rest_settings.auth_ou is None:
            raise ScalersException('auth_ou setting is missed in REST API configuration.')
        if self.rest_settings.ext_vip_fqdn is None:
            raise ScalersException('ext_vip_fqdn setting is missed in REST API configuration.')

        for host in self.global_settings.host_list:
            for nic_name, nic in self.hosts_settings[host].nics.items():
                if self.rest_settings.ext_vip == nic.ip:
                    raise ScalersException("IP '{0}' which was mentioned as 'ext_vip' in 'rest' section is"
                                           " already used as IP for '{1}' interface"
                                           " for '{2}' node".format( self.rest_settings.ext_vip, nic_name, host))
                if self.rest_settings.int_vip == nic.ip:
                    raise ScalersException("IP '{0}' which was mentioned as 'int_vip' in 'rest' section is"
                                           " already used as IP for '{1}' interface"
                                           " for '{2}' node".format(self.rest_settings.ext_vip, nic_name, host))

        for host in self.global_settings.host_list:
            if self.hosts_settings[host].rest_keepalived_nic is None:
                self.hosts_settings[host].rest_keepalived_nic = self.hosts_settings[host].rest_primary_nic

    def __init__(self, config_file):
        """ Basic initialization.
        :param config_file: absolute path to configuration file.
        """

        self.version = (None, None, None, )
        self.flavour = None
        self.distro = None
        self.drivers_type = None
        self._parse_es_install_version_file()
        self._parse_es_drivers_type_file()

        if not os.path.exists(config_file):
            raise ScalersException("Unable to found EXAScaler configuration file '{0}'".format(config_file))
        self.config_file = config_file
        self.config = self.EXAScalerConfigParser()
        self.config.read(config_file)
        self.shadow_config = None

        self._tune_global()

        self.host_defaults_settings = None if not self.config.has_section('host_defaults') \
            else HostDefaultsSection(self.config, shadow_config=self.shadow_config)

        self._tune_hsm()

        self._tune_fs()

        self._tune_zpools()

        # sort host_list by the order of host sections to fix automatic IP assignment
        ordered_sections_list = self.config.sections()
        ordered_hosts = [ i.split()[1] for i in ordered_sections_list if i.startswith('host ') ]
        self.global_settings.host_list = [ host for host in ordered_hosts if host in self.global_settings.host_list ]

        self.global_settings.finalize_host_list()
        if self.global_settings.hsm_active:
            self.global_settings.add_hosts_to_host_list(self.hsm_settings.rbh_host_name)

        self._tune_hosts()

        for fs in self.global_settings.fs_list:
            fs_settings = self.fs_settings[fs]
            fs_settings.associate_hosts(self.hosts_settings)
            fs_settings.check_ost_lnet_list(self.hosts_settings)

            if fs_settings.total_mdt_count > 1 and fs_settings.mgs_internal and not fs_settings.mgs_standalone:
                raise ScalersException("MGT target should be standalone in case of multiple MDTs in a scope of "
                                       "'{0}' filesystem.".format(fs))

            if fs_settings.backfs == 'zfs':
                if fs_settings.mgs_internal:
                    if len(fs_settings.mgs_zpools) != 1:
                        raise ScalersException("Only one zpool could be used for MGT in filesystem '{0}' but {1} "
                                               "were specified.".format(fs, len(fs_settings.mgs_zpools)))
                    if fs_settings.mgs_zpools[0] != 'mgs':
                        raise ScalersException("The expected name of MGT zpool is 'mgs' but '{0}' "
                                               "was specified.".format(fs_settings.mgs_zpools[0]))

                mdt_zpools_count = len(fs_settings.mdt_zpools)
                if mdt_zpools_count != fs_settings.total_mdt_count:
                    raise ScalersException("Number of MDT zpools for fs {0} is {1}, but expected value "
                                           "is {2}.".format(fs, mdt_zpools_count, fs_settings.total_mdt_count))
                expected_mdt_names = ['%s_mdt%04d' % (fs, idx) for idx in xrange(fs_settings.total_mdt_count)]
                for mdt_zpool in fs_settings.mdt_zpools:
                    if mdt_zpool not in expected_mdt_names:
                        raise ScalersException("Unexpected name '{0}' of MDT zpool specified. "
                                               "Expected values are {1}.".format(mdt_zpool, expected_mdt_names))

                ost_zpools_count = len(fs_settings.ost_zpools)
                if ost_zpools_count != fs_settings.total_ost_count:
                    raise ScalersException("Number of OST zpools for fs {0} is {1}, but expected value "
                                           "is {2}.".format(fs, ost_zpools_count, fs_settings.total_ost_count))
                expected_ost_names = ['%s_ost%04d' % (fs, idx) for idx in xrange(fs_settings.total_ost_count)]
                for ost_zpool in fs_settings.ost_zpools:
                    if ost_zpool not in expected_ost_names:
                        raise ScalersException("Unexpected name '{}' of OST zpool specified. "
                                               "Expected values are {}.".format(ost_zpool, expected_ost_names))

            #'-text4' opt may cause unexpected issues in lustre. forcing user to remove it"
            for opts in  [fs_settings.mkfs_opts, fs_settings.ost_mke2fs_opts, fs_settings.mdt_mke2fs_opts]:
                if opts is not None and '-text4' in opts:
                    raise ScalersException("'-text4' is not a valid option anymore in mkfs_opts or mke2fs_opts. "
                                       "Please remove the option for '{}' filesystem.".format(fs))

        self._tune_ha()

        self._tune_esui()

        self._tune_sfa()

        self._tune_rest()

    def to_dict(self):
        """ Convert to dictionary.
        """

        return dict(
            global_settings=self.global_settings.to_dict(),
            host_defaults_settings=None if self.host_defaults_settings is None else (
                self.host_defaults_settings.to_dict()),
            hsm_settings=None if self.hsm_settings is None else self.hsm_settings.to_dict(),
            fs_settings={key: value.to_dict() for key, value in self.fs_settings.iteritems()},
            pool_settings={key: value.to_dict() for key, value in self.pool_settings.iteritems()},
            zpool_settings=None if not self.zpool_settings else {
                key: value.to_dict() for key, value in self.zpool_settings.iteritems()},
            esui_settings=None if self.esui_settings is None else self.esui_settings.to_dict(),
            ha_settings=None if self.ha_settings is None else self.ha_settings.to_dict(),
            hosts_settings={key: value.to_dict() for key, value in self.hosts_settings.iteritems()},
            sfa_settings={key: value.to_dict() for key, value in self.sfa_settings.iteritems()},
            rest_settings=None if self.rest_settings is None else self.rest_settings.to_dict(),
        )

    def sync_config_file_across_cluster(self):
        """ Sync EXAScaler configuration file across cluster nodes.
        """

        CmdExecutor(StringCommand("/opt/ddn/es/tools/sync-file {0}".format(self.config_file))).execute()
