# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Host defaults section of EXAScaler configuration file.
"""

import re

from es.cluster.entities.cfg.section import EsConfigSection
from scalers.errors import ScalersException


class HostDefaultsSection(EsConfigSection):
    """ Host defaults section of EXAScaler configuration file.
    """

    class Nic(object):
        """ Nic settings.
        """

        def __init__(self, name):
            """ Basic initialization
            """

            self.name = name

            self.cfg = None
            self.device = None
            self.slaves = None
            self.netmask = None
            self.gateway = None

        def get_from_config_settings(self, settings):
            """ Obtain settings from configuration file.
            :param settings: Dictionary with settings from configuration file.
            """

            if self.name == 'ipmi':
                keys = ('netmask', 'gateway',)
            else:
                self.device = self.name
                keys = ('cfg', 'device', 'slaves', 'netmask', 'gateway',)

            for key in keys:
                setting = '{0}_{1}'.format(self.name, key)
                if setting in settings:
                    setattr(self, key, settings[setting])
                    del settings[setting]

            if self.cfg is not None:
                self.cfg = self.cfg.strip()

        def to_dict(self):
            """ Convert to dictionary.
            """

            keys = ('cfg', 'device', 'slaves', 'netmask', 'gateway',)

            return {key: getattr(self, key) for key in keys if getattr(self, key) is not None}

    def __init__(self, config, shadow_config=None):
        """ Basic initialization.
        """

        self.nic_list = list()
        self.lnets = list()

        self.stonith_pass = None
        self.stonith_user = None
        self.stonith_type = None
        self.ipmi_delay = None
        self.ipmi_method = None
        self.ipmi_monitor = None
        self.ipmi_power_wait = 5

        self.bonding_mode = None
        self.modprobe_cfg = None
        self.serial_speed = '115200'
        self.serial_port = 'ttyS0'
        self.ring0 = None
        self.ring1 = None

        self.rest_ext_nic = None
        self.rest_int_nic = None
        self.rest_primary_nic = None
        self.rest_keepalived_nic = None

        self.rest_cert_ca = None
        self.rest_cert_crl = None
        self.rest_cert_server = None
        self.rest_cert_server_key = None

        self.nics = dict()
        self.base_ip = dict()

        self.host_sfa_list = list()
        self.grub_args = None

        super(HostDefaultsSection, self).__init__(config, 'host_defaults', shadow_config)

    def to_dict(self):
        """ Convert to dictionary.
        """

        fields = ('nic_list', 'lnets', 'stonith_pass', 'stonith_user', 'stonith_type', 'bonding_mode', 'modprobe_cfg',
                  'serial_speed', 'serial_port', 'base_ip', 'ring0', 'ring1', 'host_sfa_list', 'grub_args',
                  'ipmi_delay', 'ipmi_method', 'ipmi_monitor', 'ipmi_power_wait',
                  'rest_ext_nic', 'rest_int_nic', 'rest_primary_nic', 'rest_keepalived_nic',
                  'rest_cert_ca', 'rest_cert_crl', 'rest_cert_server', 'rest_cert_server_key', )

        result = {field: getattr(self, field) for field in fields}
        result['nics'] = {key: value.to_dict() for key, value in self.nics.iteritems()}
        return result

    def _configure_section(self):
        """ Divide settings according their types.
        Set mandatory,comma separated list, space separated list, str, bool,
        int, list of nodes fields if it is necessary.
        """

        self._str_fields = ['stonith_pass', 'stonith_user', 'stonith_type', 'bonding_mode', 'modprobe_cfg',
                            'serial_speed', 'serial_port', 'ring0', 'ring1', 'ipmi_method', 'grub_args',
                            'rest_ext_nic', 'rest_int_nic', 'rest_primary_nic', 'rest_keepalived_nic',
                            'rest_cert_ca', 'rest_cert_crl', 'rest_cert_server', 'rest_cert_server_key',]
        self._space_separated_list_fields = ['nic_list', 'lnets', 'host_sfa_list', ]
        self._int_fields = ['ipmi_delay', 'ipmi_monitor', 'ipmi_power_wait', ]

    def _check_settings(self):
        """ Verify obtained settings.
        """

        valid_stonith_types = ['ipmi', 'ipmi-slow', 'ilo', 'ssh', 'sfa10ke', 'none', 'sfa_vm', ]
        if self.stonith_type is not None and self.stonith_type not in valid_stonith_types:
            valid_stonith_types.remove('ssh')
            raise ScalersException(
                "Invalid stonith type '{0}' in 'host defaults' section of EXAScaler configuration file."
                " Possible values are: {1}".format(self.stonith_type, ','.join(valid_stonith_types)))

        if self.stonith_type != 'ipmi' and (self.ipmi_delay or self.ipmi_method or self.ipmi_monitor):
            raise ScalersException(
                "Invalid parameter in 'host defaults' section of EXAScaler configuration file."
                " Parameters 'ipmi_delay' and 'ipmi_method' and 'ipmi_monitor' can be used only with ipmi stonith type")

        valid_ipmi_method = ["onoff", "cycle"]
        if self.ipmi_method is not None and self.ipmi_method not in valid_ipmi_method:
            raise ScalersException(
                "Invalid ipmi method '{0}' in 'host defaults' section of EXAScaler configuration file."
                " Possible values are: {1}".format(self.ipmi_method, ','.join(valid_ipmi_method)))

    def is_ipmi_required(self):
        """ If stonith settings require IPMI.
        """

        return self.stonith_type in ('ipmi', 'ipmi-slow',)

    def _set_stonith_defaults(self):
        """ Set stonith default settings if it is necessary.
        """

        if self.is_ipmi_required():
            if self.stonith_user is None:
                self.stonith_user = 'root'
            if self.stonith_pass is None:
                self.stonith_pass = 'calvin'
            if self.ipmi_delay is None:
                self.ipmi_delay = 15
            if self.ipmi_monitor is None:
                self.ipmi_monitor = 60
            if self.ipmi_method is None:
                self.ipmi_method = "onoff"

        elif self.stonith_type == 'ilo':
            if self.stonith_user is None:
                self.stonith_user = 'Administrator'
            if self.stonith_pass is None:
                self.stonith_pass = 'datadirect'

        elif self.stonith_type == 'sfa_vm':
            if self.stonith_user is None:
                self.stonith_user = 'user'
            if self.stonith_pass is None:
                self.stonith_pass = 'user'

    def _parse_nics(self):
        """ Parse network settings.
        """

        nic_list = list()
        if self.nic_list is not None:
            nic_list = self.nic_list[:]
        if self.is_ipmi_required():
            nic_list.append('ipmi')

        for name in nic_list:

            nic = self.Nic(name)
            nic.get_from_config_settings(self.unknown_settings)
            self.nics[name] = nic

            base_ip_setting = '{0}_ip_base'.format(name)
            if base_ip_setting in self.unknown_settings:
                base_ip = self.unknown_settings[base_ip_setting]
                self.base_ip[name] = [int(part) for part in base_ip.split('.')]
                del self.unknown_settings[base_ip_setting]

    def _perform_custom_tunings(self):
        """ Perform custom tunings for obtained settings.
        """

        settings = ('stonith_pass', 'stonith_user', 'stonith_type', 'bonding_mode', 'modprobe_cfg',
                    'serial_speed', 'serial_port', 'nic_list', 'lnets', 'ring0', 'ring1', 'host_sfa_list',
                    'ipmi_delay', 'ipmi_method', 'ipmi_monitor', 'ipmi_power_wait', 'grub_args',
                    'rest_ext_nic', 'rest_int_nic', 'rest_primary_nic', 'rest_keepalived_nic',
                    'rest_cert_ca', 'rest_cert_crl', 'rest_cert_server', 'rest_cert_server_key',)

        for setting in settings:
            if setting in self._untuned_settings:
                setattr(self, setting, self._untuned_settings[setting])

        self._parse_nics()
        # self._set_stonith_defaults()
        self._check_lnets()

    def get_next_ip(self, nic_name):
        """ Generate next ip address.
        """

        ip = self.base_ip[nic_name]
        ip_result = '.'.join([str(part) for part in ip])

        for i in range(3, -1, -1):
            ip[i] += 1
            if ip[i] < 256:
                return ip_result
            ip[i] = 0

        raise ScalersException('Impossible to generate next ip address.')

    def _check_lnets(self):
        """ Check lents filed.
        """

        template = re.compile(r"^\s*(?P<lnet>tcp|o2ib)[0-9]*\((?P<nics>.+)\)$")

        for lnet in self.lnets:
            match = re.match(template, lnet)
            if match is None:
                raise ScalersException("Incorrect format of lnet '{0}'. "
                                       "Supported format is [tcp|o2ib]<idx>(<nic>|<nic1>,<nic2>,...). "
                                       "Example: tcp0(eth0), o2ib(ib0), o2ib0(ib0,ib1).".format(lnet))
            if not set(match.group('nics').split(',')).issubset(set(self.nics.iterkeys())):
                raise ScalersException("Specified lnet network interface (0) not found in host network list".format(match.group('nics')))
