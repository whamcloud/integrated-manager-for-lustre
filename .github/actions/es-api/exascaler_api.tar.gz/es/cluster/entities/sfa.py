# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" EXAScaler wrapper for SFA API package.
"""

from ddn.sfa.core import APIContext
from ddn.sfa.api import SFAVirtualDisk, SFADiskDrive, SFAUPS, SFADiskSlot, SFAEnclosure, SFAStoragePool, SFAController
from ddn.sfa.legacy import SFAVirtualDisk as LegacySFAVirtualDisk
from ddn.sfa.legacy import SFAStoragePool as LegacySFAStoragePool

from functools import wraps

pd_state_mapping = {
    0: 'Ready',
    1: 'Absent',
    2: 'Assumed Present',
    3: 'Partial Ready Local',
    4: 'Partial Ready Remote',
    5: 'Starting',
    6: 'Stopped',
    255: 'Unknown'
}

vd_state_mapping = {
    0: 'None',
    1: 'Not Ready',
    2: 'Ready',
    3: 'Inoperative',
    4: 'Auto Write Locked',
    5: 'Critical',
    6: 'Deleted',
    7: 'Forced Write Through',
    8: 'Initialization Failed',
    255: 'Unknown'
}

pool_state_mapping = {
    0: 'Normal',
    1: 'Waiting',
    2: 'Failed',
    3: 'Fault',
    4: 'Degraded',
    5: 'Nored',
    6: 'INOP',
    7: 'Exported',
    8: 'Exporting',
    255: 'Unknown'
}

health_state_mapping = {
    0: 'NA',
    1: 'Ok',
    2: 'Non Critical',
    3: 'Critical',
    255: 'Unknown'
}

ses_statuses_mapping = {
    0: 'Unsupported',
    1: 'Ok',
    2: 'Critical',
    3: 'Non Critical',
    4: 'Unrecoverable',
    5: 'Not Installed',
    6: 'Unknown',
    7: 'Not Available',
    8: 'No Access'
}


def context(action_on_sfa):
    """ Wrapper for SFA command execution from context.
    """

    @wraps(action_on_sfa)
    def wrapper(self, *args, **kwargs):
        return self._context.execute(action_on_sfa, self, *args, **kwargs)

    return wrapper


class SFA(object):
    """ SFA entity.
    """

    def __init__(self, primary_controller, secondary_controller=None, login='user', password='user'):
        """ Basic initialization.
        """

        try:
            self._context = APIContext('https://{0}'.format(primary_controller), (login, password,))
            self._isDCR = self._context.isDCR()
        except Exception as e:
            if secondary_controller is not None:
                self._context = APIContext('https://{0}'.format(secondary_controller), (login, password,))
                self._isDCR = self._context.isDCR()
            else:
                raise e

    @context
    def _get_vds(self):
        """ Get all virtual disks.
        """

        if self._isDCR:
            return SFAVirtualDisk.getAll()
        else:
            return LegacySFAVirtualDisk.getAll()

    @context
    def _get_pds(self):
        """ Get all physical disks.
        """
        return SFADiskDrive.getAll()

    @context
    def _get_ups(self):
        """ Get all uninteruptible power supply objects.
        """
        return SFAUPS.getAll()

    @context
    def _get_slots(self):
        """ Get all disk slots.
        """
        return SFADiskSlot.getAll()

    @context
    def _get_enclosures(self):
        """ Get all enclosures.
        """
        return SFAEnclosure.getAll()

    @context
    def _get_pools(self):
        """ Get all storage pools.
        """

        if self._isDCR:
            return SFAStoragePool.getAll()
        else:
            return LegacySFAStoragePool.getAll()

    @context
    def _get_controllers(self):
        """ Get all controllers.
        """
        return SFAController.getAll()

    @context
    def _get_pool_by_index(self, index):
        """ Find pool by index.
        """

        if self._isDCR:
            return SFAStoragePool.get(Index=index)
        else:
            return LegacySFAStoragePool.get(Index=index)

    def get_multipath_table_for_vpd_page_83(self):
        """ Get multipath table for vital product data page 0x83.
        """

        return [dict(name=vd.Name, alias='3{0}'.format(vd.UUID)) for vd in self._get_vds()]

    def get_multipath_table_for_vpd_page_80(self):
        """ Get multipath table for vital product data page 0x80.
        """

        return [dict(name=vd.Name,
                     alias='{0}{1}{2}'.format(
                         vd.UUID[7:13].upper(),
                         vd.UUID[16:24].upper(),
                         vd.UUID[28:32].upper()))
                for vd in self._get_vds()]

    def get_udev_lookup_table(self):
        """ Get data suitably for writing a udev lookup table.
        """

        return [dict(name=vd.Name, alias=hex(int(vd.OID))[2:]) for vd in self._get_vds()]

    def check_pds(self):
        """ Check all physical drives.
        """

        errors = list()

        for disk in self._get_pds():

            if disk.State != disk.DISK_HEALTH_GOOD:
                error = "Physical disk {0} (enclosure {1}  slot {2}) has incorrect state '{3}'".format(
                    disk.WWN,
                    disk.EnclosureIndex,
                    disk.DiskSlotNumber,
                    pd_state_mapping.get(disk.State))
                errors.append(error)
            if disk.HealthState != disk.HEALTH_OK:
                error = "Physical disk {0} (enclosure {1}  slot {2}) has incorrect health state '{3}'".format(
                    disk.WWN,
                    disk.EnclosureIndex,
                    disk.DiskSlotNumber,
                    health_state_mapping.get(disk.HealthState))
                errors.append(error)

        return errors

    def check_pools(self):
        """ Check all pools.
        """

        errors = list()

        for pool in self._get_pools():

            if not self._isDCR:
                if pool.PoolState != pool.POOL_STATE_NORMAL:
                    error = "Pool {0} has incorrect state '{1}'".format(
                        pool.Index,
                        pool_state_mapping.get(pool.PoolState))
                    errors.append(error)

                if pool.HomeControllerIndex != pool.PreferredHomeControllerIndex:
                    error = "Pool {0} has not equal home controller index '{1}' and " \
                            "preferred home controller index '{2}'".format(
                        pool.Index,
                        pool.HomeControllerIndex,
                        pool.PreferredHomeControllerIndex)
                    errors.append(error)

                if pool.HomeControllerRPIndex != pool.PreferredHomeControllerRPIndex:
                    error = "Pool {0} has not equal home controller RP index '{1}' and " \
                            "preferred home controller RP index '{2}'".format(
                        pool.Index,
                        pool.HomeControllerRPIndex,
                        pool.PreferredHomeControllerRPIndex)
                    errors.append(error)

            if pool.HealthState != pool.HEALTH_OK:
                error = "Pool {0} has incorrect health state '{1}'".format(
                    pool.Index,
                    health_state_mapping.get(pool.HealthState))
                errors.append(error)

        return errors

    def check_vds(self):
        """ Check all virtual disks.
        """

        errors = list()

        for disk in self._get_vds():
            if self._isDCR:

                if disk.State != disk.STATE_READY:
                    error = "Virtual disk {0} has incorrect state '{1}'".format(
                        disk.Index,
                        vd_state_mapping.get(disk.State))
                    errors.append(error)

                if disk.HomeControllerIndex != disk.PreferredHomeControllerIndex:
                    error = "Virtual disk {0} has not equal home controller index '{1}' and " \
                            "preferred home controller index '{2}'".format(
                        disk.Index,
                        disk.HomeControllerIndex,
                        disk.PreferredHomeControllerIndex)
                    errors.append(error)

                if disk.HomeControllerRPIndex != disk.PreferredHomeControllerRPIndex:
                    error = "Virtual disk {0} has not equal home controller RP index '{1}' and " \
                            "preferred home controller RP index '{2}'".format(
                        disk.Index,
                        disk.HomeControllerRPIndex,
                        disk.PreferredHomeControllerRPIndex)
                    errors.append(error)
            else:

                if disk.State != disk.VD_STATE_READY:
                    error = "Virtual disk {0} has incorrect state '{1}'".format(
                        disk.Index,
                        vd_state_mapping.get(disk.State))
                    errors.append(error)

            if disk.HealthState != disk.HEALTH_OK:
                error = "Virtual disk {0} has incorrect health state '{1}'".format(
                    disk.Index,
                    health_state_mapping.get(disk.HealthState))
                errors.append(error)

        return errors

    def check_slots(self):
        """ Check all slots.
        """

        errors = list()

        for slot in self._get_slots():

            if slot.SESStatus not in (slot.SES_STATUS_OK, slot.SES_STATUS_NOT_INSTALLED,
                                      slot.SES_STATUS_NOT_AVAILABLE,):
                error = "Slot {0} has incorrect ses status '{1}'".format(
                    slot.Index,
                    ses_statuses_mapping.get(slot.SESStatus))
                errors.append(error)

            if slot.HealthState != slot.HEALTH_OK:
                error = "Slot {0} has incorrect health state '{1}'".format(
                    slot.Index,
                    health_state_mapping.get(slot.HealthState))
                errors.append(error)

            if not slot.Present:
                error = "Slot {0} is not present in the enclosure".format(slot.Index)
                errors.append(error)

        return errors

    def check_ups(self):
        """ Check all uninteruptible power supplies.
        """

        errors = list()

        for ups in self._get_ups():

            if ups.HealthState != ups.HEALTH_OK:
                error = "UPS {0} has incorrect health state '{1}'".format(
                    ups.Index,
                    health_state_mapping.get(ups.HealthState))
                errors.append(error)

            if ups.ACFailure:
                error = "UPS {0} is not receiving external power".format(ups.Index)
                errors.append(error)

        return errors

    def check_enclosures(self):
        """ Check all enclosures.
        """

        errors = list()

        for enclosure in self._get_ups():

            if enclosure.HealthState != enclosure.HEALTH_OK:
                error = "Enclosure {0} has incorrect health state '{1}'".format(
                    enclosure.Index,
                    health_state_mapping.get(enclosure.HealthState))
                errors.append(error)

            if enclosure.FirmwareVersion == "VARIOUS":
                error = "Enclosure {0} has various firmware versions".format(enclosure.Index)
                errors.append(error)

        return errors

    def check_controllers(self):
        """ Check all controllers.
        """

        errors = list()

        controllers = self._get_controllers()

        if len(controllers) != 2:
            error = "Incorrect number of presented SFA controllers: {0}".format(len(controllers))
            errors.append(error)
        else:
            if controllers[0].FWRelease != controllers[1].FWRelease:
                error = "Different firmware releases on SFA controllers: '{0}' and '{1}'".format(
                    controllers[0].FWRelease,
                    controllers[1].FWRelease)
                errors.append(error)

            if controllers[0].FWSourceVersion != controllers[1].FWSourceVersion:
                error = "Different firmware source versions on SFA controllers: '{0}' and '{1}'".format(
                    controllers[0].FWSourceVersion,
                    controllers[1].FWSourceVersion)
                errors.append(error)

        for controller in controllers:

            if controller.HealthState != controller.HEALTH_OK:
                error = "Controller {0} has incorrect health state '{1}'".format(
                    controller.Index,
                    health_state_mapping.get(controller.HealthState))
                errors.append(error)

        return errors

    def check_all(self):
        """ Check all SFA stuff.
        """

        return dict(
            pds=self.check_pds(),
            pools=self.check_pools(),
            vds=self.check_vds(),
            slots=self.check_slots(),
            ups=self.check_ups(),
            enclosures=self.check_enclosures(),
            controllers=self.check_controllers()
        )

    def get_local_controller_index(self):
        """ Get index of local controller.
        """

        for controller in self._get_controllers():
            if controller.Local:
                return controller.Index

    def list_home_vd_indexes(self):
        """ List VD indexes for home controller.
        """

        local_controller_index = self.get_local_controller_index()
        indexes = list()

        for vd in self._get_vds():
            if self._isDCR:
                if vd.HomeControllerIndex == local_controller_index:
                    indexes.append('%04d' % vd.Index)
            else:
                pool = self._get_pool_by_index(vd.PoolIndex)
                if pool.HomeControllerIndex == local_controller_index:
                    indexes.append('%04d' % vd.Index)

        return indexes
