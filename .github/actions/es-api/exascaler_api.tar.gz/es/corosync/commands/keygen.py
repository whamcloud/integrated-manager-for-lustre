# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing 'corosync-keygen' command.
"""


from scalers.utils.command import StringCommand
from scalers.utils.cmd import CmdExecutor
from es.utils.commands.rngd import rngd


COMMAND = 'corosync-keygen'


_corosync_keygen_executor = CmdExecutor(StringCommand(COMMAND))


def keygen():
    """ Run 'corosync-keygen' command.
    """

    return _corosync_keygen_executor.execute()


def generate_auth_key():
    """ Procedure for corosync authkey generation.
    """

    rngd()
    keygen()
