# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing corosync-quorumtool command
"""

import re

from scalers.utils.cmd import CmdOutputParser, CmdExecutor
from scalers.utils.command import StringCommand

COMMAND = 'corosync-quorumtool'
COMMAND_PARSING_ERROR = "Unable to parse 'corosync-quorumtool' output."

_RE_QUORUM_SECTION_HEADER = re.compile(r"^\s*Quorum\s+information\s*$")
_RE_VOTEQUORUM_SECTION_HEADER = re.compile(r"^\s*Votequorum\s+information\s*$")
_RE_MEMBERSHIP_SECTION_HEADER = re.compile(r"^\s*Membership\s+information\s*$")

_RE_SPLITTER = re.compile(r"^-+$")
_RE_EMPTY_LINE = re.compile(r"^\s*$")

_RE_QUORUM_DATE = re.compile(r'^\s*Date:\s+(?P<date>.+)\s*$')
_RE_QUORUM_PROVIDER = re.compile(r'^\s*Quorum\sprovider:\s+(?P<provider>\S+)\s*$')
_RE_QUORUM_NODES = re.compile(r'^\s*Nodes:\s+(?P<nodes>\d+)\s*$')
_RE_QUORUM_NODE_ID = re.compile(r'^\s*Node\sID:\s+(?P<node_id>\d+)\s*$')
_RE_QUORUM_RING_ID = re.compile(r'^\s*Ring\sID:\s+(?P<ring_id>\S+)\s*$')
_RE_QUORUM_QUORATE = re.compile(r'^\s*Quorate:\s+(?P<quorate>\S+)\s*$')

_RE_VOTEQUORUM_EXPECTED_VOTES = re.compile(r'^\s*Expected\svotes:\s+(?P<exp_votes>\d+)\s*$')
_RE_VOTEQUORUM_HIGHEST_EXPECTED = re.compile(r'^\s*Highest\sexpected:\s+(?P<highest_exp>\d+)\s*$')
_RE_VOTEQUORUM_TOTAL_VOTES = re.compile(r'^\s*Total\svotes:\s+(?P<total_votes>\d+)\s*$')
_RE_VOTEQUORUM_QUORUM = re.compile(r'^\s*Quorum:\s+(?P<quorum>\d+)\s*(?P<additional_info>.+)?\s*$')
_RE_VOTEQUORUM_FLAGS = re.compile(r'^\s*Flags:\s+(?P<flags>.+)\s*$')

_RE_MEMBERSHIP_HEADER = re.compile(r'^\s*Nodeid\s+Votes\s+Name\s*$')
_RE_MEMBERSHIP_NODE_INFO = re.compile(r'^\s*(?P<id>\d+)\s+(?P<votes>\d+)\s+(?P<name>\S+)(\s+(?P<local>\(local\)))?\s*$')


class QuorumtoolParser(CmdOutputParser):
    """ Class for parsing corosync-quorumtool command output.
    """

    def _parse_quorum_block(self, block):
        """ Parse quorum information.
        """

        if _RE_QUORUM_SECTION_HEADER.match(block[0]) is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        if _RE_SPLITTER.match(block[1]) is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)

        match = _RE_QUORUM_DATE.match(block[2])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        date = match.group('date')

        match = _RE_QUORUM_PROVIDER.match(block[3])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        provider = match.group('provider')

        match = _RE_QUORUM_NODES.match(block[4])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        nodes = match.group('nodes')

        match = _RE_QUORUM_NODE_ID.match(block[5])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        node_id = match.group('node_id')

        match = _RE_QUORUM_RING_ID.match(block[6])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        ring_id = match.group('ring_id')

        match = _RE_QUORUM_QUORATE.match(block[7])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        quorate = match.group('quorate')

        return dict(date=date,
                    provider=provider,
                    nodes=nodes,
                    node_id=node_id,
                    ring_id=ring_id,
                    quorate=quorate)

    def _parse_votequorum_block(self, block):
        """ Parse votequorum information.
        """

        if _RE_VOTEQUORUM_SECTION_HEADER.match(block[0]) is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        if _RE_SPLITTER.match(block[1]) is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)

        match = _RE_VOTEQUORUM_EXPECTED_VOTES.match(block[2])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        exp_votes = match.group('exp_votes')

        match = _RE_VOTEQUORUM_HIGHEST_EXPECTED.match(block[3])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        highest_exp = match.group('highest_exp')

        match = _RE_VOTEQUORUM_TOTAL_VOTES.match(block[4])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        total_votes = match.group('total_votes')

        match = _RE_VOTEQUORUM_QUORUM.match(block[5])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        quorum = match.group('quorum')

        match = _RE_VOTEQUORUM_FLAGS.match(block[6])
        if match is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        flags = match.group('flags').split(' ')

        return dict(exp_votes=exp_votes,
                    highest_exp=highest_exp,
                    total_votes=total_votes,
                    quorum=quorum,
                    flags=flags)

    def _parse_membership_block(self, block):
        """ Parse membership information.
        """

        if _RE_MEMBERSHIP_SECTION_HEADER.match(block[0]) is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        if _RE_SPLITTER.match(block[1]) is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)
        if _RE_MEMBERSHIP_HEADER.match(block[2]) is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)

        nodes = list()

        for line in block[3:]:
            if not line:
                continue

            match = _RE_MEMBERSHIP_NODE_INFO.match(line)
            if match is None:
                self.get_parse_error(COMMAND_PARSING_ERROR)

            nodes.append(dict(id=match.group('id'),
                              votes=match.group('votes'),
                              name=match.group('name'),
                              local=True if match.group('local') is not None else False))
        return dict(nodes=nodes)

    def _parse(self, output):
        """ Parse corosync-quorumtool output.
        """

        lines = output.split('\n')

        quorum_block = lines[:8]
        quorum_info = self._parse_quorum_block(quorum_block)

        if _RE_EMPTY_LINE.match(lines[8]) is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)

        votequorum_block = lines[9:16]
        votequorum_info = self._parse_votequorum_block(votequorum_block)

        if _RE_EMPTY_LINE.match(lines[16]) is None:
            self.get_parse_error(COMMAND_PARSING_ERROR)

        membership_info = lines[17:]
        membership_info = self._parse_membership_block(membership_info)

        return dict(quorum_info=quorum_info, votequorum_info=votequorum_info, membership_info=membership_info)


class QuorumtoolExecutor(CmdExecutor):
    """ Class for corosync-quorumtool command execution.
    """

    def __init__(self, command):
        """ Command output parser initialization.
        """

        super(QuorumtoolExecutor, self).__init__(command, QuorumtoolParser)

    def execute_command(self):
        """ corosync-quorumtool command execution.
        """

        return CmdExecutor.execute(self, ensure_success=False)


_quorumtool_executor = QuorumtoolExecutor(StringCommand(COMMAND))


def quorumtool():
    """ Run corosync-quorumtool command.
    """

    return _quorumtool_executor.execute_command()
