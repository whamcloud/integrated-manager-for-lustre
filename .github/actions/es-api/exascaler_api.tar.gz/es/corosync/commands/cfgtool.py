# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing corosync-cfgtool command
"""

import re

from scalers.utils.cmd import CmdOutputParser, CmdExecutor
from scalers.utils.command import StringCommand

COMMAND_STATUS = 'corosync-cfgtool -s'
COMMAND_S_PARSING_ERROR = "Unable to parse 'corosync-cfgtool -s' output."

_RE_STATUS_HEADER = re.compile(r"^\s*Printing\sring\sstatus\.\s*$")
_RE_STATUS_LOCAL_NODE_ID = re.compile(r"^\s*Local\snode\sID\s+(?P<id>\d+)\s*$")
_RE_STATUS_RING_ID = re.compile(r"^\s*RING\sID\s+(?P<id>\d+)\s*$")
_RE_STATUS_RING_NETWORK_ID = re.compile(r"^\s*id\s+=\s+(?P<id>\S+)\s*$")
_RE_STATUS_RING_STATUS = re.compile(r"^\s*status\s+=\s+(?P<status>.+)\s*$")


class CfgtoolStatusParser(CmdOutputParser):
    """ Class for parsing 'corosync-cfgtool -s' command output.
    """

    def _parse_ring_block(self, block):
        """ Parse ring information.
        """

        match = _RE_STATUS_RING_ID.match(block[0])
        if match is None:
            self.get_parse_error(COMMAND_S_PARSING_ERROR)
        ring_id = match.group('id')

        match = _RE_STATUS_RING_NETWORK_ID.match(block[1])
        if match is None:
            self.get_parse_error(COMMAND_S_PARSING_ERROR)
        network_id = match.group('id')

        match = _RE_STATUS_RING_STATUS.match(block[2])
        if match is None:
            self.get_parse_error(COMMAND_S_PARSING_ERROR)
        status = match.group('status')

        return dict(id=ring_id,
                    network_id=network_id,
                    status=status)

    def _parse(self, output):
        """ Parse corosync-quorumtool output.
        """

        lines = output.split('\n')

        if _RE_STATUS_HEADER.match(lines[0]) is None:
            self.get_parse_error(COMMAND_S_PARSING_ERROR)

        match = _RE_STATUS_LOCAL_NODE_ID.match(lines[1])
        if match is None:
            self.get_parse_error(COMMAND_S_PARSING_ERROR)
        local_node_id = match.group('id')

        rings = list()

        rings_info = lines[2:]
        rings_list = list((rings_info[i:(i + 3)] for i in range(0, len(rings_info), 3)))
        for ring_info in rings_list:
            rings.append(self._parse_ring_block(ring_info))

        return dict(local_node_id=local_node_id, rings=rings)


class CfgtoolStatusExecutor(CmdExecutor):
    """ Class for 'corosync-cfgtool -s' command execution.
    """

    def __init__(self, command):
        """ Command output parser initialization.
        """

        super(CfgtoolStatusExecutor, self).__init__(command, CfgtoolStatusParser)

    def execute_command(self):
        """ 'corosync-cfgtool -s' command execution.
        """

        return CmdExecutor.execute(self)


_cfgtool_status_executor = CfgtoolStatusExecutor(StringCommand(COMMAND_STATUS))


def cfgtool_status():
    """ Run 'corosync-cfgtool -s' command.
    """

    return _cfgtool_status_executor.execute_command()
