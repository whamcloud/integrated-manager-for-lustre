# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing 'corosync-xmlproc' command.
"""


from scalers.utils.command import StringCommand
from scalers.utils.cmd import CmdExecutor


COMMAND = 'corosync-xmlproc %(input)s %(output)s'


class XmlprocExecutor(CmdExecutor):
    """ Class for 'corosync-xmlproc' command execution.
    """

    def execute_command(self, input_file, output_file=None):
        """ 'corosync-xmlproc' command execution.
        :param input_file: path to xml file with corosync configuration.
        :param output_file: path to corosync configuration file, which should be generated,
        if output_file is None output will be redirected to stdout.
        """

        args = dict(input=input_file, output=(output_file if output_file is not None else ''))

        return CmdExecutor.execute(self, args=args)

_xmlproc_executor = XmlprocExecutor(StringCommand(COMMAND))


def xmlproc(input_file, output_file=None):
    """ Run 'corosync-xmlproc' command.
    :param input_file: path to xml file with corosync configuration.
    :param output_file: path to corosync configuration file, which should be generated,
    if output_file is None output will be redirected to stdout.
    """

    return _xmlproc_executor.execute_command(input_file, output_file)
