# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

from lxml import etree
import xml.etree.ElementTree

TOP_DIRECTIVE_TOTEM = 'totem'
TOP_DIRECTIVE_LOGGING = 'logging'
TOP_DIRECTIVE_QUORUM = 'quorum'
TOP_DIRECTIVE_NODELIST = 'nodelist'
TOP_DIRECTIVE_QB = 'qb'
TOP_DERECTIVES = (TOP_DIRECTIVE_TOTEM, TOP_DIRECTIVE_LOGGING, TOP_DIRECTIVE_QUORUM,
                  TOP_DIRECTIVE_NODELIST, TOP_DIRECTIVE_QB, )

SUB_DIRECTIVE_INTERFACE = 'interface'
SUB_DIRECTIVE_LOGGER_SUBSYS = 'logger_subsys'
SUB_DIRECTIVE_NODE = 'node'
SUB_DIRECTIVE_MEMBER = 'member'

MEMBER_MEMBERADDR = 'memberaddr'
MEMBER_MEMBERS = (MEMBER_MEMBERADDR, )

INTERFACE_RING_NUMBER = 'ringnumber'
INTERFACE_BIND_NET_ADDR = 'bindnetaddr'
INTERFACE_BROADCAST = 'broadcast'
INTERFACE_MULTICAST_ADDR = 'mcastaddr'
INTERFACE_MULTICAST_PORT = 'mcastport'
INTERFACE_TIME_TO_LIFE = 'ttl'
INTERFACE_MEMBERS = (INTERFACE_RING_NUMBER, INTERFACE_BIND_NET_ADDR, INTERFACE_BROADCAST, INTERFACE_MULTICAST_ADDR,
                     INTERFACE_MULTICAST_PORT, INTERFACE_TIME_TO_LIFE, '_members')

TOTEM_VERSION = 'version'
TOTEM_CLEAR_NODE_HIGH_BIT = 'clear_node_high_bit'
TOTEM_CRYPTO_HASH = 'crypto_hash'
TOTEM_CRYPTO_CIPHER = 'crypto_cipher'
TOTEM_SEC_AUTH = 'secauth'
TOTEM_RRP_MODE = 'rrp_mode'
TOTEM_NET_MTU = 'netmtu'
TOTEM_TRANSPORT = 'transport'
TOTEM_CLUSTER_NAME = 'cluster_name'
TOTEM_IP_VERSION = 'ip_version'
TOTEM_TOKEN = 'token'
TOTEM_TOKEN_COEFFICIENT = 'token_coefficient'
TOTEM_TOKEN_RETRANSMIT = 'token_retransmit'
TOTEM_HOLD = 'hold'
TOTEM_RETRANSMITS_BEFORE_LOSS_CONST = 'token_retransmits_before_loss_const'
TOTEM_JOIN = 'join'
TOTEM_SEND_JOIN = 'send_join'
TOTEM_CONSENSUS = 'consensus'
TOTEM_MERGE = 'merge'
TOTEM_DOWNCHECK = 'downcheck'
TOTEM_FAIL_RECV_CONST = 'fail_recv_const'
TOTEM_SEQNO_UNCHANGED_CONST = 'seqno_unchanged_const'
TOTEM_HEARTBEAT_FAILURES_ALLOWED = 'heartbeat_failures_allowed'
TOTEM_MAX_NET_DELAY = 'max_network_delay'
TOTEM_WIN_SIZE = 'window_size'
TOTEM_MAX_MSG = 'max_messages'
TOTEM_MISS_COUNT_CONST = 'miss_count_const'
TOTEM_RRP_PROBLEM_COUNT_TIMEOUT = 'rrp_problem_count_timeout'
TOTEM_RRP_PROBLEM_COUNT_THRESHOLD = 'rrp_problem_count_threshold'
TOTEM_RRP_PROBLEM_COUNT_MCAST_THRESHOLD = 'rrp_problem_count_mcast_threshold'
TOTEM_RRP_TOKEN_EXP_TIMEOUT = 'rrp_token_expired_timeout'
TOTEM_RRP_AUTOREC_CHECK_TIMEOUT = 'rrp_autorecovery_check_timeout'
TOTEM_MEMBERS = (TOTEM_VERSION, TOTEM_CRYPTO_HASH, TOTEM_CRYPTO_CIPHER, TOTEM_SEC_AUTH, TOTEM_RRP_MODE, TOTEM_NET_MTU,
                 TOTEM_TRANSPORT, TOTEM_CLUSTER_NAME, TOTEM_IP_VERSION, TOTEM_TOKEN, TOTEM_TOKEN_COEFFICIENT,
                 TOTEM_TOKEN_RETRANSMIT, TOTEM_HOLD, TOTEM_RETRANSMITS_BEFORE_LOSS_CONST, TOTEM_JOIN, TOTEM_SEND_JOIN,
                 TOTEM_CONSENSUS, TOTEM_MERGE, TOTEM_DOWNCHECK, TOTEM_FAIL_RECV_CONST, TOTEM_SEQNO_UNCHANGED_CONST,
                 TOTEM_HEARTBEAT_FAILURES_ALLOWED, TOTEM_MAX_NET_DELAY, TOTEM_WIN_SIZE, TOTEM_MAX_MSG,
                 TOTEM_MISS_COUNT_CONST, TOTEM_RRP_PROBLEM_COUNT_TIMEOUT, TOTEM_RRP_PROBLEM_COUNT_THRESHOLD,
                 TOTEM_RRP_PROBLEM_COUNT_MCAST_THRESHOLD, TOTEM_RRP_TOKEN_EXP_TIMEOUT, TOTEM_RRP_AUTOREC_CHECK_TIMEOUT,
                 TOTEM_CLEAR_NODE_HIGH_BIT, '_interfaces', )

LOGGING_TIMESTAMP = 'timestamp'
LOGGING_FILELINE = 'fileline'
LOGGING_FUNCTION_NAME = 'function_name'
LOGGING_TO_STDERR = 'to_stderr'
LOGGING_TO_LOGFILE = 'to_logfile'
LOGGING_TO_SYSLOG = 'to_syslog'
LOGGING_LOGFILE = 'logfile'
LOGGING_LOGFILE_PRIO = 'logfile_priority'
LOGGING_SYSLOG_FACILITY = 'syslog_facility'
LOGGING_SYSLOG_PRIORITY = 'syslog_priority'
LOGGING_DEBUG = 'debug'
LOGGING_MEMBERS = (LOGGING_TIMESTAMP, LOGGING_FILELINE, LOGGING_FUNCTION_NAME, LOGGING_TO_STDERR, LOGGING_TO_LOGFILE,
                   LOGGING_TO_SYSLOG, LOGGING_LOGFILE, LOGGING_LOGFILE_PRIO, LOGGING_SYSLOG_FACILITY,
                   LOGGING_SYSLOG_PRIORITY, LOGGING_DEBUG, '_logger_subsyses', )

LOGGER_SUBSYS_NAME = 'subsys'
LOGGER_SUBSYS_TO_STDERR = LOGGING_TO_STDERR
LOGGER_SUBSYS_TO_LOGFILE = LOGGING_TO_LOGFILE
LOGGER_SUBSYS_TO_SYSLOG = LOGGING_TO_SYSLOG
LOGGER_SUBSYS_LOGFILE = LOGGING_LOGFILE
LOGGER_SUBSYS_LOGFILE_PRIO = LOGGING_LOGFILE_PRIO
LOGGER_SUBSYS_SYSLOG_FACILITY = LOGGING_SYSLOG_FACILITY
LOGGER_SUBSYS_SYSLOG_PRIORITY = LOGGING_SYSLOG_PRIORITY
LOGGER_SUBSYS_DEBUG = LOGGING_DEBUG
LOGGER_SUBSYS_MEMBERS = (LOGGER_SUBSYS_NAME, LOGGER_SUBSYS_TO_STDERR, LOGGER_SUBSYS_TO_LOGFILE, LOGGER_SUBSYS_TO_SYSLOG,
                         LOGGER_SUBSYS_LOGFILE, LOGGER_SUBSYS_LOGFILE_PRIO, LOGGER_SUBSYS_SYSLOG_FACILITY,
                         LOGGER_SUBSYS_SYSLOG_PRIORITY, LOGGER_SUBSYS_DEBUG, )

NODE_RING_0_ADDR = 'ring0_addr'
NODE_RING_1_ADDR = 'ring1_addr'
NODE_NODEID = 'nodeid'
NODE_NAME = 'name'
NODE_MEMBERS = (NODE_RING_0_ADDR, NODE_RING_1_ADDR, NODE_NODEID, NODE_NAME, )

QUORUM_PROVIDER = 'provider'
QUORUM_TWO_NODE = 'two_node'
QUORUM_MEMBERS = (QUORUM_PROVIDER, QUORUM_TWO_NODE, )

QB_IPC_TYPE = 'ipc_type'
QB_MEMBERS = (QB_IPC_TYPE, )


class Member(object):
    """ Class for 'member' sub-directive of 'interface' sub-directive.
    """

    __slots__ = MEMBER_MEMBERS

    def __init__(self):
        """ Basic initialization.
        """

        self.memberaddr = None


class Interface(object):
    """ Class for 'interface' sub-directive of 'totem' directive.
    """

    __slots__ = INTERFACE_MEMBERS

    def __init__(self):
        """ Basic initialization.
        """

        self.ringnumber = None
        self.bindnetaddr = None
        self.broadcast = None
        self.mcastaddr = None
        self.mcastport = None
        self.ttl = None
        self._members = list()

    @property
    def members(self):
        """ Get members.
        """

        return self._members

    @members.setter
    def members(self, value):
        """ Set members.
        """

        self._members = value


class Totem(object):
    """ Class for 'totem' top level directive.
    """

    __slots__ = TOTEM_MEMBERS

    def __init__(self):
        """ Basic initialization.
        """

        self._interfaces = list()

        self.version = None
        self.clear_node_high_bit = None
        self.crypto_hash = None
        self.crypto_cipher = None
        self.secauth = None
        self.rrp_mode = None
        self.netmtu = None
        self.transport = None
        self.cluster_name = None
        self.ip_version = None
        self.token = None
        self.token_coefficient = None
        self.token_retransmit = None
        self.hold = None
        self.token_retransmits_before_loss_const = None
        self.join = None
        self.send_join = None
        self.consensus = None
        self.merge = None
        self.downcheck = None
        self.fail_recv_const = None
        self.seqno_unchanged_const = None
        self.heartbeat_failures_allowed = None
        self.max_network_delay = None
        self.window_size = None
        self.max_messages = None
        self.miss_count_const = None
        self.rrp_problem_count_timeout = None
        self.rrp_problem_count_threshold = None
        self.rrp_problem_count_mcast_threshold = None
        self.rrp_token_expired_timeout = None
        self.rrp_autorecovery_check_timeout = None

    @property
    def interfaces(self):
        """ Get interfaces.
        """

        return self._interfaces

    @interfaces.setter
    def interfaces(self, value):
        """ Set interfaces.
        """

        self._interfaces = value


class LoggerSubsys(object):
    """ Class for 'logger_subsys' sub-directive of 'logging' directive.
    """

    __slots__ = LOGGER_SUBSYS_MEMBERS

    def __init__(self):
        """ Basic initialization.
        """

        self.subsys = None
        self.to_stderr = None
        self.to_logfile = None
        self.to_syslog = None
        self.logfile = None
        self.logfile_priority = None
        self.syslog_facility = None
        self.syslog_priority = None
        self.debug = None


class Logging(object):
    """ Class for 'logging' top level directive.
    """

    __slots__ = LOGGING_MEMBERS

    def __init__(self):
        """ Basic initialization.
        """

        self._logger_subsyses = list()

        self.timestamp = None
        self.fileline = None
        self.function_name = None
        self.to_stderr = None
        self.to_logfile = None
        self.to_syslog = None
        self.logfile = None
        self.logfile_priority = None
        self.syslog_facility = None
        self.syslog_priority = None
        self.debug = None

    @property
    def logger_subsyses(self):
        """ Get logger subsyses.
        """

        return self._logger_subsyses


class Node(object):
    """ Class for 'node' sub-directive of 'nodelist' directive.
    """

    __slots__ = NODE_MEMBERS

    def __init__(self):
        """ Basic initialization.
        """

        self.ring0_addr = None
        self.ring1_addr = None
        self.nodeid = None
        self.name = None


class Nodelist(object):
    """ Class for 'nodelist' top level directive.
    """

    __slots__ = ['_nodes', ]

    def __init__(self):
        """ Basic initialization.
        """

        self._nodes = list()

    @property
    def nodes(self):
        """ Get nodes.
        """

        return self._nodes

    @nodes.setter
    def nodes(self, value):
        """ Set nodes.
        """

        self._nodes = value


class Quorum(object):
    """ Class for 'quorum' top level directive.
    """

    __slots__ = QUORUM_MEMBERS

    def __init__(self):
        """ Basic initialization.
        """

        self.provider = None
        self.two_node = None


class Qb(object):
    """ Class for 'qb' top level directive.
    """

    __slots__ = QB_MEMBERS

    def __init__(self):
        """ Basic initialization.
        """

        self.ipc_type = None


class CorosyncConfig(object):
    """ Class for corosync configuration.
    """

    __slots__ = TOP_DERECTIVES

    def __init__(self):
        """ Basic initialization.
        """

        self.totem = None
        self.logging = None
        self.quorum = None
        self.nodelist = None
        self.qb = None

    @staticmethod
    def _get_attributes(obj, attrs):
        """ Get public object attributes.
        """

        attributes = dict()
        members = [attr for attr in attrs if not callable(attr) and not attr.startswith("_")]
        for member in members:
            value = getattr(obj, member)
            if value is not None:
                attributes[member] = str(value)
        return attributes

    def save_to_xml(self, file_path):
        """ Save config to xml file.

        :param file_path: absolute path to xml file
        """

        top = etree.Element('corosync')

        if self.totem is not None:
            totem_attrib = self._get_attributes(self.totem, TOTEM_MEMBERS)
            totem = etree.SubElement(top, TOP_DIRECTIVE_TOTEM, attrib=totem_attrib)
            if len(self.totem.interfaces) != 0:
                for interface in self.totem.interfaces:
                    interface_attrib = self._get_attributes(interface, INTERFACE_MEMBERS)
                    interface_element = etree.SubElement(totem, SUB_DIRECTIVE_INTERFACE, attrib=interface_attrib)
                    for member in interface.members:
                        members_attrib = self._get_attributes(member, MEMBER_MEMBERS)
                        etree.SubElement(interface_element, SUB_DIRECTIVE_MEMBER, attrib=members_attrib)

        if self.logging is not None:
            logging_attrib = self._get_attributes(self.logging, LOGGING_MEMBERS)
            logging = etree.SubElement(top, TOP_DIRECTIVE_LOGGING, attrib=logging_attrib)
            if len(self.logging.logger_subsyses) != 0:
                for logger_subsys in self.logging.logger_subsyses:
                    logger_subsys_attrib = self._get_attributes(logger_subsys, LOGGER_SUBSYS_MEMBERS)
                    etree.SubElement(logging, SUB_DIRECTIVE_LOGGER_SUBSYS, attrib=logger_subsys_attrib)

        if self.quorum is not None:
            quorum_attrib = self._get_attributes(self.quorum, QUORUM_MEMBERS)
            etree.SubElement(top, TOP_DIRECTIVE_QUORUM, attrib=quorum_attrib)

        if self.nodelist is not None:
            nodelist = etree.SubElement(top, TOP_DIRECTIVE_NODELIST)
            if len(self.nodelist.nodes) != 0:
                for node in self.nodelist.nodes:
                    node_attrib = self._get_attributes(node, NODE_MEMBERS)
                    etree.SubElement(nodelist, SUB_DIRECTIVE_NODE, attrib=node_attrib)

        if self.qb is not None:
            qb_attrib = self._get_attributes(self.qb, QB_MEMBERS)
            etree.SubElement(top, TOP_DIRECTIVE_QB, attrib=qb_attrib)

        tree = etree.ElementTree(top)
        tree.write(file_path, pretty_print=True)

    @classmethod
    def load_from_xml(cls, file_path):
        """ Load config from xml file.

        :param file_path: absolute path to xml file with corosync configuration
        """

        parser = CorosyncConfigParser(file_path)
        config = parser.parse()
        return config


class CorosyncConfigParser(object):
    """ Parser for corosync xml config.
    """

    def __init__(self, config_path):
        """ Basic initialization
        """

        self._config_path = config_path

    @staticmethod
    def _parse_interface_sub_directive(interface_sub_directive):
        """ Parse 'interface' sub-directive of 'totem' directive.
        """

        interface = Interface()
        interface.ringnumber = interface_sub_directive.get(INTERFACE_RING_NUMBER)
        interface.bindnetaddr = interface_sub_directive.get(INTERFACE_BIND_NET_ADDR)
        interface.broadcast = interface_sub_directive.get(INTERFACE_BROADCAST)
        interface.mcastaddr = interface_sub_directive.get(INTERFACE_MULTICAST_ADDR)
        interface.mcastport = interface_sub_directive.get(INTERFACE_MULTICAST_PORT)
        interface.ttl = interface_sub_directive.get(INTERFACE_TIME_TO_LIFE)
        members_sub_directives = interface_sub_directive.findall(SUB_DIRECTIVE_MEMBER)
        if len(members_sub_directives) != 0:
            for members_sub_directive in members_sub_directives:
                member = Member()
                member.memberaddr = members_sub_directive.get(MEMBER_MEMBERADDR)
                interface.members.append(member)

        return interface

    @staticmethod
    def _parse_logging_subsys_sub_directive(logger_subsys_sub_directive):
        """ Parse 'logger_subsys' sub-directive of 'logging' directive.
        """

        logger_subsys = LoggerSubsys()
        logger_subsys.subsys = logger_subsys_sub_directive.get(LOGGER_SUBSYS_NAME)
        logger_subsys.to_stderr = logger_subsys_sub_directive.get(LOGGER_SUBSYS_TO_STDERR)
        logger_subsys.to_logfile = logger_subsys_sub_directive.get(LOGGER_SUBSYS_TO_LOGFILE)
        logger_subsys.to_syslog = logger_subsys_sub_directive.get(LOGGER_SUBSYS_TO_SYSLOG)
        logger_subsys.logfile = logger_subsys_sub_directive.get(LOGGER_SUBSYS_LOGFILE)
        logger_subsys.logfile_priority = logger_subsys_sub_directive.get(LOGGER_SUBSYS_LOGFILE_PRIO)
        logger_subsys.syslog_facility = logger_subsys_sub_directive.get(LOGGER_SUBSYS_SYSLOG_FACILITY)
        logger_subsys.syslog_priority = logger_subsys_sub_directive.get(LOGGER_SUBSYS_SYSLOG_PRIORITY)
        logger_subsys.debug = logger_subsys_sub_directive.get(LOGGER_SUBSYS_DEBUG)

        return logger_subsys

    @staticmethod
    def _parse_node_sub_directive(node_sub_directive):
        """ Parse 'node' sub-directive of 'nodelist' directive.
        """

        node = Node()
        node.ring0_addr = node_sub_directive.get(NODE_RING_0_ADDR)
        node.ring1_addr = node_sub_directive.get(NODE_RING_1_ADDR)
        node.nodeid = node_sub_directive.get(NODE_NODEID)
        node.name = node_sub_directive.get(NODE_NAME)

        return node

    def _parse_totem_directive(self, totem_directive):
        """ Parse totem top level directive.
        """

        totem = Totem()

        interface_sub_directives = totem_directive.findall(SUB_DIRECTIVE_INTERFACE)
        if len(interface_sub_directives) != 0:
            for interface_sub_directive in interface_sub_directives:
                totem.interfaces.append(self._parse_interface_sub_directive(interface_sub_directive))

        totem.version = totem_directive.get(TOTEM_VERSION)
        totem.clear_node_high_bit = totem_directive.get(TOTEM_CLEAR_NODE_HIGH_BIT)
        totem.crypto_hash = totem_directive.get(TOTEM_CRYPTO_HASH)
        totem.crypto_cipher = totem_directive.get(TOTEM_CRYPTO_CIPHER)
        totem.secauth = totem_directive.get(TOTEM_SEC_AUTH)
        totem.rrp_mode = totem_directive.get(TOTEM_RRP_MODE)
        totem.netmtu = totem_directive.get(TOTEM_NET_MTU)
        totem.transport = totem_directive.get(TOTEM_TRANSPORT)
        totem.cluster_name = totem_directive.get(TOTEM_CLUSTER_NAME)
        totem.ip_version = totem_directive.get(TOTEM_IP_VERSION)
        totem.token = totem_directive.get(TOTEM_TOKEN)
        totem.token_coefficient = totem_directive.get(TOTEM_TOKEN_COEFFICIENT)
        totem.token_retransmit = totem_directive.get(TOTEM_TOKEN_RETRANSMIT)
        totem.hold = totem_directive.get(TOTEM_HOLD)
        totem.token_retransmits_before_loss_const = totem_directive.get(TOTEM_RETRANSMITS_BEFORE_LOSS_CONST)
        totem.join = totem_directive.get(TOTEM_JOIN)
        totem.send_join = totem_directive.get(TOTEM_SEND_JOIN)
        totem.consensus = totem_directive.get(TOTEM_CONSENSUS)
        totem.merge = totem_directive.get(TOTEM_MERGE)
        totem.downcheck = totem_directive.get(TOTEM_DOWNCHECK)
        totem.fail_recv_const = totem_directive.get(TOTEM_FAIL_RECV_CONST)
        totem.seqno_unchanged_const = totem_directive.get(TOTEM_SEQNO_UNCHANGED_CONST)
        totem.heartbeat_failures_allowed = totem_directive.get(TOTEM_HEARTBEAT_FAILURES_ALLOWED)
        totem.max_network_delay = totem_directive.get(TOTEM_MAX_NET_DELAY)
        totem.window_size = totem_directive.get(TOTEM_WIN_SIZE)
        totem.max_messages = totem_directive.get(TOTEM_MAX_MSG)
        totem.miss_count_const = totem_directive.get(TOTEM_MISS_COUNT_CONST)
        totem.rrp_problem_count_timeout = totem_directive.get(TOTEM_RRP_PROBLEM_COUNT_TIMEOUT)
        totem.rrp_problem_count_threshold = totem_directive.get(TOTEM_RRP_PROBLEM_COUNT_THRESHOLD)
        totem.rrp_problem_count_mcast_threshold = totem_directive.get(TOTEM_RRP_PROBLEM_COUNT_MCAST_THRESHOLD)
        totem.rrp_token_expired_timeout = totem_directive.get(TOTEM_RRP_TOKEN_EXP_TIMEOUT)
        totem.rrp_autorecovery_check_timeout = totem_directive.get(TOTEM_RRP_AUTOREC_CHECK_TIMEOUT)

        return totem

    def _parse_logging_directive(self, logging_directive):
        """ Parse logging top level directive.
        """

        logging = Logging()

        logger_subsys_sub_directives = logging_directive.findall(SUB_DIRECTIVE_LOGGER_SUBSYS)
        if len(logger_subsys_sub_directives) != 0:
            for logger_subsys_sub_directive in logger_subsys_sub_directives:
                logging.logger_subsyses.append(self._parse_logging_subsys_sub_directive(logger_subsys_sub_directive))

        logging.timestamp = logging_directive.get(LOGGING_TIMESTAMP)
        logging.fileline = logging_directive.get(LOGGING_FILELINE)
        logging.function_name = logging_directive.get(LOGGING_FUNCTION_NAME)
        logging.to_stderr = logging_directive.get(LOGGING_TO_STDERR)
        logging.to_logfile = logging_directive.get(LOGGING_TO_LOGFILE)
        logging.to_syslog = logging_directive.get(LOGGING_TO_SYSLOG)
        logging.logfile = logging_directive.get(LOGGING_LOGFILE)
        logging.logfile_priority = logging_directive.get(LOGGING_LOGFILE_PRIO)
        logging.syslog_facility = logging_directive.get(LOGGING_SYSLOG_FACILITY)
        logging.syslog_priority = logging_directive.get(LOGGING_SYSLOG_PRIORITY)
        logging.debug = logging_directive.get(LOGGING_DEBUG)

        return logging

    @staticmethod
    def _parse_quorum_directive(quorum_directive):
        """ Parse quorum top level directive.
        """

        quorum = Quorum()
        quorum.provider = quorum_directive.get(QUORUM_PROVIDER)
        quorum.two_node = quorum_directive.get(QUORUM_TWO_NODE)

        return quorum

    def _parse_nodelist_directive(self, nodelist_directive):
        """ Parse nodelist top level directive.
        """

        nodelist = Nodelist()

        node_directives = nodelist_directive.findall(SUB_DIRECTIVE_NODE)
        if len(node_directives) != 0:
            for node_directive in node_directives:
                nodelist.nodes.append(self._parse_node_sub_directive(node_directive))

        return nodelist

    @staticmethod
    def _parse_qb_directive(qb_directive):
        """ Parse qb top level directive.
        """

        qb = Qb()
        qb.ipc_type = qb_directive.get(QB_IPC_TYPE)

        return qb

    def parse(self):
        """ Parsing of corosync config file.
        """

        config = CorosyncConfig()

        root_element = xml.etree.ElementTree.parse(self._config_path).getroot()

        totem_directive = root_element.find(TOP_DIRECTIVE_TOTEM)
        if totem_directive is not None:
            totem = self._parse_totem_directive(totem_directive)
            config.totem = totem

        logging_directive = root_element.find(TOP_DIRECTIVE_LOGGING)
        if logging_directive is not None:
            logging = self._parse_logging_directive(logging_directive)
            config.logging = logging

        nodelist_directive = root_element.find(TOP_DIRECTIVE_NODELIST)
        if nodelist_directive is not None:
            nodelist = self._parse_nodelist_directive(nodelist_directive)
            config.nodelist = nodelist

        quorum_directive = root_element.find(TOP_DIRECTIVE_QUORUM)
        if quorum_directive is not None:
            quorum = self._parse_quorum_directive(quorum_directive)
            config.quorum = quorum

        qb_directive = root_element.find(TOP_DIRECTIVE_QB)
        if qb_directive is not None:
            qb = self._parse_qb_directive(qb_directive)
            config.qb = qb

        return config
