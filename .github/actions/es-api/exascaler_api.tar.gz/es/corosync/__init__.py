# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Corosync related EXAScaler API package.
"""

import abc

from es.corosync.commands.keygen import generate_auth_key
from es.corosync.commands.xmlproc import xmlproc
from es.corosync.entities.config import (
    CorosyncConfig,
    Interface,
    Totem,
    Logging,
    Node,
    Nodelist,
    Quorum,
    Member,
)
from es.utils import get_hostname
from scalers.errors import ScalersException


class Corosync(object):
    """ Base corosync entity.
    """

    def __init__(self, system_config):
        """ Basic initialization.
        """

        self._system_config = system_config
        self.config = self._generate_default_config()

    @staticmethod
    def generate_auth_key():
        """ Corosync authkey generation.
        """

        generate_auth_key()

    @abc.abstractmethod
    def _generate_default_config(self):
        """ Generate default corosync conf based on config.
        """

        pass

    def save_config(self, file_name='/etc/corosync/corosync.conf'):
        """ Save config to file.
        :param file_name: path to corosync configuration file, which should be generated.
        """

        generated_file_path = '/etc/corosync/corosync.xml'
        self.config.save_to_xml(generated_file_path)
        xmlproc(generated_file_path, file_name)

    def print_config(self):
        """ Print corosync configuration.
        """

        generated_file_path = '/etc/corosync/corosync.xml'
        self.config.save_to_xml(generated_file_path)
        print xmlproc(generated_file_path)


class EXAScalerCorosync(Corosync):
    """ EXAScaler corosync entity.
    """

    def _generate_default_config(self):
        """ Generate default corosync conf based on EXAScaler config.
        """

        this_host = get_hostname()
        if (this_host not in self._system_config.hosts_settings) or \
                (this_host in self._system_config.global_settings.clients_list):
            raise ScalersException("Unable to configure corosync, because of current host '{0}'"
                                   " is not a part of the cluster.".format(this_host))

        if self._system_config.ha_settings is None:
            raise ScalersException("Unable to configure corosync, HA section is missed"
                                   " in EXAScaler configuration file.")

        if self._system_config.ha_settings.type != 'corosync':
            raise ScalersException("Unable to configure corosync, because of HA type is '{0}', but expected"
                                   " value is '{1}'".format(self._system_config.ha_settings.type, 'corosync'))

        ring0 = self._system_config.hosts_settings[this_host].ring0
        ring1 = self._system_config.hosts_settings[this_host].ring1
        if ring0 is not None and ring1 is not None:
            if self._system_config.hosts_settings[this_host].nics[ring0].netaddr == \
                    self._system_config.hosts_settings[this_host].nics[ring1].netaddr:
                raise ScalersException("Bind network addresses should be different for ring0 and ring1.")

        totem = Totem()
        totem.version = '2'
        totem.secauth = self._system_config.ha_settings.secauth
        totem.netmtu = self._system_config.ha_settings.netmtu
        totem.crypto_cipher = self._system_config.ha_settings.crypto_cipher
        totem.crypto_hash = self._system_config.ha_settings.crypto_hash
        totem.window_size = self._system_config.ha_settings.window_size
        totem.max_messages = self._system_config.ha_settings.max_messages
        totem.token = '10000'
        totem.clear_node_high_bit = 'yes'
        totem.consensus = '12000'
        totem.join = '1000'
        totem.merge = '400'
        totem.downcheck = '2000'
        totem.rrp_mode = self._system_config.ha_settings.rrp_mode

        ring_list = sorted(self._system_config.ha_settings.corosync_nics)
        ring_count = len(ring_list)

        transport = self._system_config.ha_settings.transport
        if transport == 'unicast':
            totem.transport = 'udpu'

        count = self._system_config.hosts_settings[this_host].ha_group_idx * ring_count
        for ring_number, ring in enumerate(ring_list):
            interface = Interface()
            if ring_count > 1:
                interface.ringnumber = ring_number
            nic = getattr(self._system_config.hosts_settings[this_host], ring)
            interface.bindnetaddr = self._system_config.hosts_settings[this_host].nics[nic].netaddr
            interface.mcastaddr = '226.94.1.{0}'.format(count + 1)
            interface.mcastport = self._system_config.ha_settings.mcastport + count * 2
            totem.interfaces.append(interface)
            count += 1

        node_list = Nodelist()
        node_id = 1
        for (host, val) in self._system_config.hosts_settings.iteritems():
            if host in self._system_config.global_settings.clients_list:
                continue
            if self._system_config.hosts_settings[this_host].ha_group_idx != val.ha_group_idx:
                continue

            node = Node()
            node.nodeid = node_id
            node.name = host
            node.ring0_addr = val.nics[val.ring0].ip
            if val.ring1 is not None:
                node.ring1_addr = val.nics[val.ring1].ip
            node_list.nodes.append(node)

            node_id += 1

        quorum = Quorum()
        quorum.provider = 'corosync_votequorum'
        if (node_id - 1) == 2:
            quorum.two_node = '1'

        logging = Logging()
        logging.fileline = 'off'
        logging.to_stderr = 'no'
        logging.to_logfile = 'no'
        logging.to_syslog = 'yes'
        logging.debug = 'off'
        logging.timestamp = 'on'
        logging.syslog_facility = 'local6'

        config = CorosyncConfig()
        config.totem = totem
        config.logging = logging
        config.nodelist = node_list
        config.quorum = quorum

        return config
