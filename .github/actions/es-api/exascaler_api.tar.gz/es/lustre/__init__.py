# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Lustre related EXAScaler API package.
"""

import os
import multiprocessing
from itertools import chain

from es.lustre.entities.targets_storage import TargetsStorageBuilder
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand
from es.utils import load_module, get_file_content, makedirs
from scalers.errors import ScalersException
from es.utils.commands.mount import MountCmdBuilder, mount


class Lustre(object):
    """ Lustre entity.
    """

    class ClientOperationProcess(multiprocessing.Process):
        """ Class for Lustre client operation execution in separate process.
        """

        def __init__(self, function, **kwargs):
            """Basic initialization.
            """

            multiprocessing.Process.__init__(self)

            self.args = kwargs
            self.function = function
            manager = multiprocessing.Manager()
            self.output = manager.Value(str, '')
            self.return_code = manager.Value(int, 0)

        def run(self):
            """ Process execution.
            """

            try:
                self.output.value = self.function(**self.args)
            except Exception as e:
                self.output.value = str(e)
                self.return_code.value = 1

    def __init__(self, exascaler_config):
        """ Basic initialization.
        """

        self._es_config = exascaler_config

    def mkfs_on_local_node(self, wipe, reformat, fs=None, dry_run=False, local=True, failover=False,
                           mdt_indexes=None, ost_indexes=None):
        """ Create and format all devices required for a Lustre filesystem on local node.
        """

        builder = TargetsStorageBuilder(self._es_config)

        if mdt_indexes or ost_indexes:
            if fs is None:
                raise ScalersException('Filesystem is not specified for mkfs operation.')
            storage = builder.get_targets_storage(fs, mdt_indexes, ost_indexes)
        else:
            if failover and not local:
                storage = builder.create_failover_storage(fs)
            elif local and not failover:
                storage = builder.create_local_storage(fs)
            else:
                storage = builder.create_all_storage(fs)
        storage.mkfs(wipe, reformat, dry_run)

    def tunefs_on_local_node(self, writeconf, erase_params, fs=None, dry_run=False, local=True, failover=False,
                             mdt_indexes=None, ost_indexes=None):
        """ Tune all devices required for a Lustre filesystem on local node.
        """

        builder = TargetsStorageBuilder(self._es_config)

        if mdt_indexes or ost_indexes:
            if fs is None:
                raise ScalersException('Filesystem is not specified for tunefs operation.')
            storage = builder.get_targets_storage(fs, mdt_indexes, ost_indexes)
        else:
            if failover and not local:
                storage = builder.create_failover_storage(fs)
            elif local and not failover:
                storage = builder.create_local_storage(fs)
            else:
                storage = builder.create_all_storage(fs)
        storage.tunefs(writeconf, erase_params, dry_run)

    def mount_on_local_node(self, options=None, ignore_mtab=False, fs_type='lustre', dry_run=False, manage_vg=True,
                            local=True, failover=False, fs=None, mdt_indexes=None, ost_indexes=None, force=False):
        """ Mount Lustre filesystem on local node.
        """

        builder = TargetsStorageBuilder(self._es_config)

        if mdt_indexes or ost_indexes:
            if fs is None:
                raise ScalersException('Filesystem is not specified for mount operation.')
            storage = builder.get_targets_storage(fs, mdt_indexes, ost_indexes)
        else:
            if failover and not local:
                storage = builder.create_failover_storage(fs)
            elif local and not failover:
                storage = builder.create_local_storage(fs)
            else:
                storage = builder.create_all_storage(fs)

        storage.mount(options, ignore_mtab, fs_type, dry_run, manage_vg, force)

    def umount_on_local_node(self, dry_run=False, manage_vg=True, local=True, failover=False,
                             fs=None, mdt_indexes=None, ost_indexes=None, force=False):
        """ Umount Lustre filesystem on local node.
        """

        builder = TargetsStorageBuilder(self._es_config)
        if mdt_indexes or ost_indexes:
            if fs is None:
                raise ScalersException('Filesystem is not specified for umount operation.')
            storage = builder.get_targets_storage(fs, mdt_indexes, ost_indexes)
        else:
            if failover and not local:
                storage = builder.create_failover_storage(fs)
            elif local and not failover:
                storage = builder.create_local_storage(fs)
            else:
                storage = builder.create_all_storage(fs)
        storage.umount(dry_run, manage_vg, force)

    def fsck_on_local_node(self, mode, fsck_user_param=None, snapshot=False, dry_run=False, local=True, failover=False,
                           fs=None, mdt_indexes=None, ost_indexes=None):
        """ Perform a fsck on the local host.
        """

        builder = TargetsStorageBuilder(self._es_config)
        if mdt_indexes or ost_indexes:
            if fs is None:
                raise ScalersException('Filesystem is not specified for fsck operation.')
            storage = builder.get_targets_storage(fs, mdt_indexes, ost_indexes)
        else:
            if failover and not local:
                storage = builder.create_failover_storage(fs)
            elif local and not failover:
                storage = builder.create_local_storage(fs)
            else:
                storage = builder.create_all_storage(fs)
        storage.fsck(mode, fsck_user_param, snapshot, dry_run)

    def start_lfsck_on_local_node(self, error_level=None, speed=None, lfsck_type=None, dry_run=False):
        """ Perform a fsck on the local host.
        """

        builder = TargetsStorageBuilder(self._es_config)
        storage = builder.create_local_storage()
        storage.start_lfsck(error_level, speed, lfsck_type, dry_run)

    def stop_lfsck_on_local_node(self, dry_run=False):
        """ Perform a fsck on the local host.
        """

        builder = TargetsStorageBuilder(self._es_config)
        storage = builder.create_local_storage()
        storage.stop_lfsck(dry_run)

    def lfsck_status_on_local_node(self, dry_run=False):
        """ Perform a fsck on the local host.
        """

        builder = TargetsStorageBuilder(self._es_config)
        storage = builder.create_local_storage()
        storage.lfsck_status(dry_run)

    def is_mgs_mounted_locally(self):
        """ Check if MGT target is mounted on local host.
        """

        builder = TargetsStorageBuilder(self._es_config)

        local_storage = builder.create_local_storage()
        for target in local_storage.target_list:
            if target.type == 'mgs':
                return target.is_mounted()

        failover_storage = builder.create_failover_storage()
        for target in failover_storage.target_list:
            if target.type == 'mgs':
                return target.is_mounted()

        raise ScalersException('MGT could not be mounted on this host.')

    def tune(self, dry_run=False):
        """ Set lustre performance tunings.
        """

        if self.is_mgs_mounted_locally():
            if self._es_config.global_settings.conf_param_tunings is not None:
                for (key, value) in self._es_config.global_settings.conf_param_tunings.settings.items():
                    cmd = 'lctl conf_param {0}={1}'.format(key, value)
                    if dry_run:
                        print cmd
                    else:
                        CmdExecutor(StringCommand(cmd)).execute()
            if self._es_config.global_settings.set_param_tunings is not None:
                for (key, value) in self._es_config.global_settings.set_param_tunings.settings.items():
                    cmd = 'lctl set_param -P {0}={1}'.format(key, value)
                    if dry_run:
                        print cmd
                    else:
                        CmdExecutor(StringCommand(cmd)).execute()
        else:
            raise ScalersException('Unable to perform lustre tunings because of MGT is not mounted.')

    def host_list_nids(self, host_list):
        """ Get nods for list of hosts.
        """

        host_nids_list = [self._es_config.hosts_settings[host].host_nids() for host in host_list]
        return [','.join(nids) for nids in host_nids_list]

    def _get_mgs_nids(self, fs):
        """ Get mgs nids.
        """

        if self._es_config.fs_settings[fs].mgs_internal:
            return self.host_list_nids(self._es_config.fs_settings[fs].mgs_list)

        if self._es_config.fs_settings[fs].mgs_fs is not None:
            mgs_fs = self._es_config.fs_settings[fs].mgs_fs
            return self.host_list_nids(self._es_config.fs_settings[mgs_fs].mgs_list)

        raise ScalersException("mgs_internal should be 'yes' or mgs_fs should be set to external MGT host.")

    def mount_name(self, fs):
        """ Get mount name.
        """

        mgs_nids = self._get_mgs_nids(fs)

        return ':'.join(mgs_nids) + ':/' + fs

    def mount_client(self, target_fs=None, dry_run=False, options=None):
        """ Mount lustre client.
        """

        if not dry_run:
            load_module('lustre')

        filesystems = self._es_config.global_settings.fs_list if target_fs is None else [target_fs, ]

        if dry_run:
            for fs in filesystems:
                builder = MountCmdBuilder()
                builder.set_filesystem_type('lustre')
                builder.set_device(self.mount_name(fs))
                builder.set_mount_point(self._es_config.fs_settings[fs].client_mount_point())
                builder.set_mount_options(options)
                print(builder.build_command_line())
        else:

            def mount_func(es_config, fs, options):
                builder = MountCmdBuilder()
                builder.set_filesystem_type('lustre')
                builder.set_device(self.mount_name(fs))
                builder.set_mount_point(es_config.fs_settings[fs].client_mount_point())
                builder.set_mount_options(options)
                makedirs(es_config.fs_settings[fs].client_mount_point())
                pool = multiprocessing.Pool(processes=1)
                result = pool.apply_async(os.path.ismount, (fs, ))
                try:
                    is_mounted = result.get(60)
                except multiprocessing.TimeoutError:
                    if fs in get_file_content('/proc/mounts'):
                        raise ScalersException('Unable to produce operation because of'
                                               ' filesystem {0} is already mounted and hangs.'.format(fs))
                    else:
                        raise ScalersException('Unable to produce operation because of unknown system problems.')
                if not is_mounted:
                    mount(builder)

            self._run_tasks([self.ClientOperationProcess(mount_func, es_config=self._es_config, fs=fs, options=options)
                             for fs in filesystems])

    def umount_client(self, target_fs=None, dry_run=False):
        """ Umount lustre client.
        """

        if not dry_run:
            load_module('lustre')

        filesystems = self._es_config.global_settings.fs_list if target_fs is None else [target_fs, ]

        if dry_run:
            for fs in filesystems:
                cmd = 'umount {0}'.format(self._es_config.fs_settings[fs].client_mount_point())
                print(cmd)
        else:

            def umount_func(es_config, fs):
                cmd = 'umount {0}'.format(es_config.fs_settings[fs].client_mount_point())
                pool = multiprocessing.Pool(processes=1)
                result = pool.apply_async(os.path.ismount, (fs,))
                try:
                    is_mounted = result.get(60)
                except multiprocessing.TimeoutError:
                    if fs in get_file_content('/proc/mounts'):
                        raise ScalersException('Unable to produce operation because of'
                                               ' filesystem {0} and hangs.'.format(fs))
                    else:
                        raise ScalersException('Unable to produce operation because of unknown system problems.')
                if not is_mounted:
                    CmdExecutor(StringCommand(cmd)).execute()

            self._run_tasks([self.ClientOperationProcess(umount_func, es_config=self._es_config, fs=fs)
                             for fs in filesystems])

    def create_local_mount_points(self):
        """ Create local mount points.
        """

        builder = TargetsStorageBuilder(self._es_config)
        storage = builder.create_local_storage()
        for target in storage.target_list:
            target.create_mount_point()
        storage = builder.create_failover_storage()
        for target in storage.target_list:
            target.create_mount_point()

    def get_all_volume_groups(self):
        """ Get the list of all LVM volume groups.
        """

        builder = TargetsStorageBuilder(self._es_config)
        local_targets = builder.create_local_storage().target_list
        failover_targets = builder.create_failover_storage().target_list
        backbone_devs = (t.service_device for t in chain(local_targets, failover_targets) if t.service_device)
        return [d.name for d in backbone_devs if d.device_type == 'vg']

    def local_ost_targets(self):
        """ Get list of local ost targets
        """

        ost_info = []
        builder = TargetsStorageBuilder(self._es_config)
        storage = builder.create_local_storage().target_list
        for target in storage:
            if target.type == 'ost':
                ost_info.append(target)
        return ost_info

    @staticmethod
    def _run_tasks(task_list):
        """ Run tasks in separate processes.
        """
        task_errors = list()

        for task in task_list:
            task.start()

        for task in task_list:
            task.join()
            if task.return_code.value != 0:
                task_errors.append(task.output.value)

        if len(task_errors) > 0:
            raise ScalersException('\n'.join(task_errors))

    def get_targets_status_for_node(self, local=True, failover=False, fs=None, mdt_indexes=None, ost_indexes=None):
        """ Get targets status.
        """

        builder = TargetsStorageBuilder(self._es_config)

        if mdt_indexes or ost_indexes:
            if fs is None:
                raise ScalersException('Filesystem is not specified for status operation.')
            storage = builder.get_targets_storage(fs, mdt_indexes, ost_indexes)
        else:
            if failover and not local:
                storage = builder.create_failover_storage(fs)
            elif local and not failover:
                storage = builder.create_local_storage(fs)
            else:
                storage = builder.create_all_storage(fs)

        return storage.get_targets_status()
