# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing tunefs.lustre command.
"""

from scalers.errors import ScalersException
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand


class TunefsCmdBuilder(object):
    """ Builder of command line arguments for tunefs.lustre command.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self._comment = None
        self._dry_run = False
        self._erase_params = False
        self._fail_nodes = list()
        self._service_nodes = list()
        self._fs = None
        self._index = None
        self._networks = list()
        self._add_mgs = False
        self._mgs_nodes = list()
        self._remove_mgs = False
        self._device = None
        self._write_conf = False
        self._additional_params = None

    def set_comment(self, comment):
        """ Set user comment about this disk, ignored by Lustre.
        """

        self._comment = comment

    def enable_dry_run(self):
        """ Only print what would be done; does not affect the disk.
        """

        self._dry_run = True

    def erase_params(self):
        """ Remove all previous parameter info.
        """

        self._erase_params = True

    def append_fail_node(self, node):
        """ Set the NID of a failover partner.
        """

        self._fail_nodes.append(node)

    def append_service_node(self, node):
        """ Set the NID of all service partner.
        """

        self._service_nodes.append(node)

    def set_fs_name(self, fs):
        """ The Lustre filesystem this service will be part of.
        The maximum filesystem_name length is 8 characters. Required for all targets other than MGT.
        """

        self._fs = fs

    def set_index(self, index):
        """ Specify a particular OST or MDT index. Required for all targets other than the MGT.
        """

        self._index = index

    def add_mgs(self):
        """ Add a configuration management service to this target.
        """

        self._add_mgs = True

    def append_mgs_node(self, node):
        """ Set the NID of the MGT node, required for all targets other than the MGT.
        """

        self._mgs_nodes.append(node)

    def remove_mgs(self):
        """ Remove a configuration management service to this target.
        """

        self._remove_mgs = True

    def set_block_device(self, device):
        """ Set block device.
        """

        self._device = device

    def append_network(self, network):
        """ Network to restrict this ost/mdt to.
        """

        self._networks.append(network)

    def write_conf(self):
        """ Erase the configuration logs for the filesystem that this server is part of, and regenerate them.
        """

        self._write_conf = True

    def add_additional_params_from_str(self, param_str):
        """ Set additional string params.
        """

        self._additional_params = param_str

    def _verify(self):
        """ Verify given parameters.
        """

        if self._fail_nodes and self._service_nodes:
            raise ScalersException("Service nodes and failover nodes are mutually exclusive.")

        if self._device is None:
            raise ScalersException("Block device is missed.")

    def build_command_line(self):
        """ Build command line.
        """

        self._verify()

        parts = ['tunefs.lustre', ]

        if self._comment is not None:
            parts.append('--comment={0}'.format(self._comment))

        if self._dry_run:
            parts.append('--dryrun')

        if self._erase_params:
            parts.append('--erase-params')

        if self._fail_nodes:
            for fail_node in self._fail_nodes:
                parts.append('--failnode={0}'.format(fail_node))

        if self._service_nodes:
            for service_node in self._service_nodes:
                parts.append('--servicenode={0}'.format(service_node))

        if self._fs:
            parts.append('--fsname={0}'.format(self._fs))

        if self._index is not None:
            parts.append('--index={0}'.format(self._index))

        if self._networks:
            for network in self._networks:
                parts.append('--network={0}'.format(network))

        if self._mgs_nodes:
            for mgs_node in self._mgs_nodes:
                parts.append('--mgsnode={0}'.format(mgs_node))

        if self._add_mgs:
            parts.append('--mgs')

        if self._remove_mgs:
            parts.append('--nomgs')

        if self._write_conf:
            parts.append('--writeconf')

        if self._additional_params:
            parts.append(self._additional_params)

        parts.append(self._device)

        return ' '.join(parts)


def tunefs(builder, log_file=None):
    """ Run tunefs.lustre command.
    :param log_file: log file
    :param builder: TunefsCmdBuilder instance
    """

    return CmdExecutor(StringCommand(builder.build_command_line())).execute(log_file=log_file)
