# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Lustre related commands for EXAScaler API package.
"""

import time
from es.utils import load_module
from scalers.utils.command import StringCommand, CommandExecutor
from scalers.utils.cmd import CmdExecutor
from scalers.errors import ScalersException


def load_lustre_modules(config, dry_run=False):
    """ Load all lustre modules.
    """

    modules = ['lnet', 'lustre', 'libcfs', 'ksocklnd', 'obdclass', 'ptlrpc', ]
    if 'ldiskfs' in config.global_settings.used_backfs_types:
        modules.extend(('ldiskfs', 'osd_ldiskfs', ))
    if 'zfs' in config.global_settings.used_backfs_types:
        modules.extend(('zfs', ))

    for module in modules:
        load_module(module, dry_run=dry_run)

    # Do not check return code because of possibility of Infiniband device missing.
    load_module('ko2iblnd', ensure_success=False, dry_run=dry_run)


def if_pool_exists(pool, fs):
    """ Check if pool exists.
    """

    result = CommandExecutor(StringCommand('lctl pool_list {0}.{1}'.format(fs, pool))).run()
    return result.exit_code == 0


def create_pool(pool, fs, dry_run=False):
    """ Create pool for given filesystem.
    """

    if not if_pool_exists(pool, fs):

        cmd = 'lctl pool_new {0}.{1}'.format(fs, pool)
        if not dry_run:
            CmdExecutor(StringCommand(cmd)).execute()
        else:
            print cmd

    if not dry_run:
        count = 0
        while not if_pool_exists(pool, fs):
            time.sleep(5)
            count += 1
            if count == 12:
                raise ScalersException("'Failed to create pool {0} for filesystem {1}'".format(pool, fs))


def delete_pool(pool, fs, dry_run=False):
    """ Delete pool for given filesystem.
    """

    if if_pool_exists(pool, fs):
        cmd = 'lctl pool_destroy {0}.{1}'.format(fs, pool)
        if not dry_run:
            CmdExecutor(StringCommand(cmd)).execute()
        else:
            print cmd


def add_ost_to_pool(ost, pool, fs, dry_run=False):
    """ Add OST to the pool for given filesystem.
    """

    cmd = 'lctl pool_add {0}.{1} {2}'.format(fs, pool, ost)
    if not dry_run:
        if not if_pool_exists(pool, fs):
            raise ScalersException("Failed to add OST to '{0}' pool, which does not exists for filesystem '{1}'".format(
                pool, fs))
        CmdExecutor(StringCommand(cmd)).execute()
    else:
        print cmd


def remove_ost_from_pool(ost, pool, fs, dry_run=False):
    """ Remove OST from  the pool for given filesystem.
    """
    cmd = 'lctl pool_remove {0}.{1} {2}'.format(fs, pool, ost)
    if not dry_run:
        if not if_pool_exists(pool, fs):
            raise ScalersException("Failed to remove OST from '{0}' pool,"
                                   " which does not exists for filesystem '{1}'".format(pool, fs))
        CmdExecutor(StringCommand(cmd)).execute()
    else:
        print cmd


def check_pools_availability(fs, pools):
    """ Check pools availability for given filesystem.
    """

    result = dict(available_pools=list(),
                  unavailable_pools=list())

    for pool in pools:
        if if_pool_exists(pool, fs):
            result['available_pools'].append(pool)
        else:
            result['unavailable_pools'].append(pool)

    return result
