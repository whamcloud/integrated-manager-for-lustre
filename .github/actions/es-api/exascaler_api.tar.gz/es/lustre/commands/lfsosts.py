# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2015, DataDirect Networks, Inc.
#
# ******************************************************************************

"""Functionality for parsing lfs osts command.
"""

from scalers.utils.cmd import CmdOutputParser, CmdExecutor

_COMMAND = 'lfs osts'
_COMMAND_PARSING_ERROR = "Unable to parse osts output."


class LFSOSTsParser(CmdOutputParser):
    """Class for parsing "lfs osts" command output.
    """

    def _parse(self, output):
        """Parse "lfs osts" output.
        """

        if not output:
            self.get_parse_error(_COMMAND_PARSING_ERROR)
        else:
            result = {"health": []}
            output_data = output.split("\n")
            for data in output_data:
                temp = data.split()
                if len(temp) == 3:
                    if "_UUID" in temp[1]:
                        ost = temp[1].replace("_UUID", "")
                        result["health"].append({"node": ost, "state": temp[2]})
            return result

_lfsosts_executor = CmdExecutor(_COMMAND, LFSOSTsParser)


def lfsosts():
    """Run osts command.
    """

    return _lfsosts_executor.execute()
