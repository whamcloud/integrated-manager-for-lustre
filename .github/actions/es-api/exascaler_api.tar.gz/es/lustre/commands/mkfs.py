# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing mkfs.lustre command.
"""

from es.lustre.entities.backbone import get_supported_backfs_list
from scalers.errors import ScalersException
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand

TYPE_MGS = '--mgs'
TYPE_MDT = '--mdt'
TYPE_OST = '--ost'
TYPE_MDT_MGS = '--mdt --mgs'
TYPES = (TYPE_MGS, TYPE_MDT, TYPE_OST, TYPE_MDT_MGS,)
TYPE_BACKFS = ('ldiskfs', 'zfs')


class MkfsCmdBuilder(object):
    """ Builder of command line arguments for mkfs.lustre command.
    """

    def __init__(self, target_type):
        """ Basic initialization.
        """

        if target_type not in TYPES:
            raise ScalersException("Incorrect target type.")

        self._type = target_type
        self._comment = None
        self._device_size = None
        self._dry_run = False
        self._fail_nodes = list()
        self._service_nodes = list()
        self._fs = None
        self._index = None
        self._mgs_nodes = list()
        self._device = None
        self._mkfs_options = None
        self._networks = list()
        self._params = dict()
        self._reformat = False
        self._backfs = 'ldiskfs'

    def set_comment(self, comment):
        """ Set user comment about this disk, ignored by Lustre.
        """

        self._comment = comment

    def set_device_size(self, device_size):
        """ Set device size(in KB) for loop devices.
        """

        self._device_size = device_size

    def set_backfs(self, fs):
        """ Set lustre backend file system type.
        """

        self._backfs = fs

    def enable_dry_run(self):
        """ Only print what would be done; does not affect the disk.
        """

        self._dry_run = True

    def append_fail_node(self, node):
        """ Set the NID of a failover partner.
        """

        self._fail_nodes.append(node)

    def append_service_node(self, node):
        """ Set the NID of all service partner.
        """

        self._service_nodes.append(node)

    def set_fs_name(self, fs):
        """ The Lustre filesystem this service will be part of.
        The maximum filesystem_name length is 8 characters. Required for all targets other than MGT.
        """

        self._fs = fs

    def set_index(self, index):
        """ Specify a particular OST or MDT index. Required for all targets other than the MGT.
        """

        self._index = index

    def append_mgs_node(self, node):
        """ Set the NID of the MGT node, required for all targets other than the MGT.
        """

        self._mgs_nodes.append(node)

    def set_block_device(self, device):
        """ Set block device.
        """

        self._device = device

    def set_mkfs_options(self, options):
        """ Format options for the backing fs.
        """

        self._mkfs_options = options

    def append_network(self, network):
        """ Network to restrict this ost/mdt to.
        """

        self._networks.append(network)

    def add_param(self, param, value):
        """ Set permanent parameter
        """

        self._params[param] = value

    def reformat(self):
        """Reformat fs.
        """

        self._reformat = True

    def _verify(self):
        """ Verify given parameters.
        """

        supported_backfs_types = get_supported_backfs_list()
        if self._backfs not in supported_backfs_types:
            raise ScalersException("Failed to set '{fs}' as a backend file system. Supported types are: {types}."
                                   .format(fs=self._backfs, types=supported_backfs_types))

        if self._fail_nodes and self._service_nodes:
            raise ScalersException("Service nodes and failover nodes are mutually exclusive.")

        if self._type in (TYPE_MDT, TYPE_OST, TYPE_MDT_MGS):
            if self._fs is None:
                raise ScalersException("Filesystem is missed.")
            if len(self._fs) > 8:
                raise ScalersException("The maximum filesystem name length is 8 characters.")
            if self._index is None:
                raise ScalersException("Index is missed.")
            if not self._mgs_nodes:
                raise ScalersException("Mgs nodes are missed.")

        if self._device is None:
            raise ScalersException("Block device is missed.")

    def build_command_line(self):
        """ Build command line.
        """

        self._verify()

        parts = ['mkfs.lustre', self._type, ]

        if self._comment is not None:
            parts.append('--comment={0}'.format(self._comment))

        if self._device_size is not None:
            parts.append('--device-size={0}'.format(self._device_size))

        if self._dry_run:
            parts.append('--dryrun')

        if self._type in (TYPE_MDT, TYPE_OST, TYPE_MDT_MGS):

            if self._fail_nodes:
                for fail_node in self._fail_nodes:
                    parts.append('--failnode={0}'.format(fail_node))

            if self._service_nodes:
                for service_node in self._service_nodes:
                    parts.append('--servicenode={0}'.format(service_node))

            parts.append('--fsname={0}'.format(self._fs))
            parts.append('--index={0}'.format(self._index))

            if self._networks:
                for network in self._networks:
                    parts.append('--network={0}'.format(network))

            for mgs_node in self._mgs_nodes:
                parts.append('--mgsnode={0}'.format(mgs_node))

        if self._mkfs_options is not None:
            parts.append("--mkfsoptions='{0}'".format(self._mkfs_options))

        for param, value in self._params.iteritems():
            parts.append('--param {0}={1}'.format(param, value))

        if self._reformat:
            parts.append('--reformat')

        parts.append('--backfstype={0}'.format(self._backfs))
        parts.append(self._device)

        return ' '.join(parts)


def mkfs(builder, log_file=None):
    """ Run mkfs.lustre command.
    :param log_file: log file
    :param builder:  MkfsCmdBuilder instance
    """

    return CmdExecutor(StringCommand(builder.build_command_line())).execute(log_file=log_file)
