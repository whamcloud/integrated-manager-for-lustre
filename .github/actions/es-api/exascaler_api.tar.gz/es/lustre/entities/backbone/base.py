# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2018, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Base classes for backbone devices used by Lustre.
"""

import abc
import os

from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand
from scalers.errors import ScalersCommandError, ScalersException


class BaseBackfsRelatedActions(object):
    """ Provides default implementations for backbone device methods related to fs.
    """

    def set_mmp_update_interval(self, interval, dry_run=False, log_file=None):
        """ Set interval of fs' Multiple Mount Protection heartbeat block update.
        Should be empty if the device doesn't have fs.
        """

    def check_mmp(self, dry_run=False, log_file=None):
        """ Check Multiple Mount Protection state.
        Should be empty if the device doesn't have fs.
        """

    def fsck(self, mode, fsck_user_param=None, snapshot=False, dry_run=False, log_file=None):
        """ Launch filesystem check.
        Should be empty if the device doesn't have fs.
        """


class LdiskfsRelatedActionsMixin(BaseBackfsRelatedActions):
    """ Provides backbone devices with LDISKFS-related actions."""

    def set_mmp_update_interval(self, interval, dry_run=False, log_file=None):
        """ Set interval of fs' Multiple Mount Protection heartbeat block update.
        """

        cmd = 'tune2fs -E mmp_update_interval={0} {1}'.format(interval, self.path)
        if dry_run:
            print(cmd)
        else:
            try:
                CmdExecutor(StringCommand(cmd)).execute(log_file=log_file)
            except ScalersCommandError:
                print "An error occurred during mmp update interval setup"

    # ToDo: [ES-LDISKFS] Doesn't work as mmp_check utility is lost
    def check_mmp(self, dry_run=False, log_file=None):
        """ Check Multiple Mount Protection state.
        """

        cmd = '/opt/ddn/bin/mmp_check {0}'.format(self.path)
        if dry_run:
            print(cmd)
        else:
            CmdExecutor(StringCommand(cmd)).execute(log_file=log_file)

    def fsck(self, mode, fsck_user_param=None, create_snapshot=False, remove_snapshot=False, dry_run=False,
             log_file=None):
        """ Launch filesystem check.
        """

        if create_snapshot and isinstance(self, SnapshotMixin):
            snapshot_name = '{0}_snap'.format(self.name)
            target_device = self.create_snapshot(snapshot_name, dry_run=dry_run)
        else:
            target_device = self.path

        fsck_cmd = ['e2fsck']
        fsck_cmd.extend(self._get_e2fsck_params(mode))
        if fsck_user_param is not None:
            fsck_cmd.append(fsck_user_param)
        fsck_cmd.append(target_device)
        cmd = ' '. join(fsck_cmd)

        if dry_run:
            print(cmd)
        else:
            # e2fsck always has a non zero-return code, even for simple journal
            # recoveries, so no need to complain about that
            CmdExecutor(StringCommand(cmd)).execute_interactive(log_file=log_file, ensure_success=False)

        if create_snapshot and remove_snapshot and isinstance(self, SnapshotMixin):
            self.destroy_snapshot(snapshot_name, dry_run=dry_run)

    @staticmethod
    def _get_e2fsck_params(mode):
        """ Generate the e2fsck parameters based on the provided mode.
        """

        params = ['-v', '-tt', '-f']
        if mode == 'ro_check':
            params.append('-n')
        elif mode == 'auto_repair':
            params.append('-y')
        elif mode == 'safe_repair':
            params.append('-p')
        return params


# ToDo: [ES-ZFS] Implement ZFS-related methods
class ZfsRelatedActionsMixin(BaseBackfsRelatedActions):
    """ Provides backbone devices with ZFS-related actions."""

    def set_mmp_update_interval(self, interval, dry_run=False, log_file=None):
        """ Set interval of fs' Multiple Mount Protection heartbeat block update.
        """

    def check_mmp(self, dry_run=False, log_file=None):
        """ Check Multiple Mount Protection state.
        """

    def fsck(self, mode, fsck_user_param=None, snapshot=False, dry_run=False, log_file=None):
        """ Launch filesystem check.
        """


class SnapshotMixin(object):
    """ Base class for backbone devices which are able to work with snapshots.
    """

    def _initialize_snapshot_engine(self):
        """ Initializes snapshot creation engine.
        Must be called in backbone device's __init__ method."""

        self._snapshots = dict()

    @abc.abstractmethod
    def _create_snapshot(self, snapshot_name, dry_run=False):
        """ Abstract method for snapshot creation.
        :returns: Absolute path to created snapshot device.
        """

    @abc.abstractmethod
    def _destroy_snapshot(self, snapshot_name, dry_run=False):
        """ Abstract method for snapshot removal.
        """

    def create_snapshot(self, snapshot_name, dry_run=False):
        """ Create snapshot with specified name.
        :returns: Absolute path to created snapshot device.
        """

        if snapshot_name in self._snapshots:
            raise ScalersException("Snapshot '%s' already exists and can't be created." % snapshot_name)
        self._snapshots[snapshot_name] = snapshot = self._create_snapshot(snapshot_name, dry_run=dry_run)
        return snapshot

    def destroy_snapshot(self, snapshot_name, dry_run=False):
        """ Remove snapshot with specified name.
        """

        if snapshot_name not in self._snapshots:
            raise ScalersException("Snapshot '%s' doesn't exist and can't be removed." % snapshot_name)
        self._destroy_snapshot(snapshot_name, dry_run=dry_run)
        del self._snapshots[snapshot_name]


class BaseBackboneDevice(BaseBackfsRelatedActions):
    """ Base class for Lustre background filesystem devices.
    """

    device_type = None

    def __init__(self, name, underlying_dev_path, es_config):
        """
        :param name: Name of the backbone device.
        :param underlying_dev_path: Path where underlying block devices can be found.
        :param es_config: :class:`es.cluster.entities.cfg.EXAScalerConfig` object.
        """

        self._name = name
        self._underlying_storage_dev_path = underlying_dev_path
        self._es_conf = es_config

    def _validate(self):
        """ Validate settings of the device.
        :raises: ScalersException
        """

        pass

    @property
    def name(self):
        """ Name of the device.
        """

        return self._name

    @property
    def path(self):
        """ Absolute path to the device.
        Should raise NotImplementedError if the device doesn't have such a path.
        :raises: NotImplementedError
        """

        raise NotImplementedError

    @property
    def is_exist(self):
        """ Property which indicates the device is created.
        Should return True if the device doesn't support existence checks.
        """

        return True

    def create(self, dry_run=False, force=False):
        """ Creates the device.
        Should be empty if the device doesn't support create/destroy actions.
        """

    def destroy(self, dry_run=False, force=False):
        """ Destroys the device.
        Should be empty if the device doesn't support create/destroy actions.
        """

    @property
    def is_enabled(self):
        """ Property which indicates that device is enabled.
        Should return True if the device doesn't support enable/disable actions.
        """

        return True

    def enable(self, dry_run=False, force=False):
        """ Enables the device.
        Should be empty if the device doesn't support enable/disable actions.
        """

    def disable(self, dry_run=False, force=False):
        """ Disables the device.
        Should be empty if the device doesn't support enable/disable actions.
        """

    def register_underlying_storage_device(self, name):
        """ Register an underlying storage device which must be located at underlying_storage_devices_base_path.
        Should raise NotImplementedError if the device doesn't support underlying devices.
        :param name: Name of the underlying device to add.
        :raises: NotImplementedError
        """

        raise NotImplementedError

    @property
    def underlying_storage_devices(self):
        """ Tuple of underlying storage devices.
        Should return empty tuple if the device doesn't support underlying devices.
        """

        return tuple()

    @property
    def underlying_storage_devices_base_path(self):
        """ Path were underlying storage devices are located.
        Should return None if the device doesn't support underlying devices.
        """

        return self._underlying_storage_dev_path

    @property
    def are_underlying_storage_devices_exist(self):
        """ Property which indicates whether all underlying storage devices are present.
        Should return True if the device doesn't support underlying devices.
        """

        return True

    def register_child_storage_device(self, name, size):
        """ Register a child storage device which will be provided by this device.
        Should raise NotImplementedError if the device doesn't support child devices.
        :param name: Name of the storage device to add.
        :param size: String representing size of the child device like '100g' or '500m'.
        :returns: BaseBackboneDevice ancestor object.
        :raises: NotImplementedError
        """

        raise NotImplementedError

    @property
    def child_storage_devices(self):
        """ Tuple of storage devices this device provides.
        Should returns empty tuple if the device doesn't support child devices.
        """

        return tuple()


class BlockDevice(BaseBackboneDevice, LdiskfsRelatedActionsMixin):
    """ Represents basic block device.
    """

    device_type = 'block'

    def __init__(self, name, underlying_dev_path, es_config):
        super(BlockDevice, self).__init__(name, underlying_dev_path, es_config)
        self._path = os.path.join(self._underlying_storage_dev_path, self._name)
        self._validate()

    @property
    def path(self):
        return self._path

    @property
    def is_exist(self):
        return os.path.exists(self._path)
