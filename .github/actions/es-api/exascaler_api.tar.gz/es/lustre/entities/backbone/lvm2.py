# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" LVM2 implementation of Lustre block device.
"""


import os

from scalers.errors import ScalersException
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand
from .base import BaseBackboneDevice, BlockDevice, LdiskfsRelatedActionsMixin, SnapshotMixin


class Lvm2VolumeGroup(BaseBackboneDevice):
    """ Represents LVM2 volume group device.
    """

    device_type = 'vg'

    def __init__(self, name, underlying_dev_path, es_config):
        """
        :param name: Name of the volume group.
        :param underlying_dev_path: Path where underlying physical volumes can be found.
        :param es_config: :class:`es.cluster.entities.cfg.EXAScalerConfig` object.
        """

        super(Lvm2VolumeGroup, self).__init__(name, underlying_dev_path, es_config)
        self._underlying_storage_devices = set()
        self._logical_volumes = list()
        self._validate()

    @property
    def is_exist(self):
        """ Property which indicates whether volume group is configured.
        """

        cmd = "vgs | sed -e 's/^[[:space:]]*//' | cut -f 1 -d ' '"
        existing_vgs = CmdExecutor(StringCommand(cmd)).execute(shell=True).splitlines()[1:]
        return self._name in existing_vgs

    def create(self, dry_run=False, force=False):
        """ Creates the volume group which consist from registered physical volumes.
        """

        if not (dry_run or self.are_underlying_storage_devices_exist):
            raise ScalersException('Storage devices not detected')
        if self.underlying_storage_devices:
            device_string = ' '.join(d.path for d in self.underlying_storage_devices)
            forced_creation_string = 'echo yes | ' if force else ''
            pv_cmd = '{0}pvcreate {1}'.format(forced_creation_string, device_string)
            vg_cmd = 'vgcreate {0} {1}'.format(self._name, device_string)
            for cmd in (pv_cmd, vg_cmd):
                if dry_run:
                    print(cmd)
                else:
                    CmdExecutor(StringCommand(cmd)).execute(shell=True)

    def destroy(self, dry_run=False, force=False):
        """ Destroys configuration of the volume group and all it's logical volumes.
        """

        if not (dry_run or self.are_underlying_storage_devices_exist):
            raise ScalersException('Storage devices not detected.')
        lvm_config_options = 'activation{volume_list=["%s"]}' % self._name
        cmd = "vgremove -f {0} --config '{1}'".format(self._name, lvm_config_options)
        if dry_run:
            print(cmd)
        else:
            CmdExecutor(StringCommand(cmd)).execute(ensure_success=False)

    @property
    def is_enabled(self):
        """ Property which indicates volume group is activated.
        """

        return all(cd.is_exist for cd in self._logical_volumes)

    def enable(self, dry_run=False, force=False):
        """ Activates volume group and all it's logical volumes.
        """

        lvm_config_options = 'activation{volume_list=["%s"]}' % self._name
        cmd = "vgchange -ay {0} --config '{1}'".format(self._name, lvm_config_options)
        if dry_run:
            print(cmd)
        else:
            CmdExecutor(StringCommand(cmd)).execute()

    def disable(self, dry_run=False, force=False):
        """ Deactivates volume group and all it's logical volumes.
        """

        lvm_config_options = 'activation{volume_list=["%s"]}' % self._name
        cmd = "vgchange -an {0} --config '{1}'".format(self._name, lvm_config_options)
        if dry_run:
            print(cmd)
        else:
            CmdExecutor(StringCommand(cmd)).execute()

    def register_underlying_storage_device(self, name):
        """ Register a physical volume.
        :param name: Name of the physical volume to add.
        """

        device = BlockDevice(name, self._underlying_storage_dev_path, self._es_conf)
        self._underlying_storage_devices.add(device)
        return device

    @property
    def underlying_storage_devices(self):
        """ Tuple of physical volumes this volume group consists of.
        """

        return tuple(self._underlying_storage_devices)

    @property
    def are_underlying_storage_devices_exist(self):
        """ Property which indicates whether all physical volumes this volume group consists of exist.
        """

        return all(os.path.exists(device.path) for device in self._underlying_storage_devices)

    @property
    def child_storage_devices(self):
        """ Tuple of logical volumes this volume group provides.
        """

        return tuple(self._logical_volumes)

    def register_child_storage_device(self, name, size):
        """ Registers a logical volume.
        :param name: Name of the logical volume to add.
        :param size: String representing size of the logical volume like '100g' or '500m'.
        """

        logical_volume = Lvm2LogicalVolume(name, size, self, self._es_conf)
        self._logical_volumes.append(logical_volume)
        return logical_volume


class Lvm2LogicalVolume(BaseBackboneDevice, LdiskfsRelatedActionsMixin, SnapshotMixin):
    """ Represents LVM2 logical volume device.
    """

    device_type = 'lv'

    def __init__(self, name, size, volume_group, es_config):
        """
        :param name: Name of the logical volume.
        :param size: String representing size of the logical volume like '100g' or '500m'.
        :param volume_group: :class:`Lvm2VolumeGroup` object on which this lv is based.
        :param es_config: :class:`es.cluster.entities.cfg.EXAScalerConfig` object.
        """

        super(Lvm2LogicalVolume, self).__init__(name, None, es_config)
        self._vg = volume_group
        self._size = size
        self._path = '/dev/mapper/{0}-{1}'.format(self._vg.name, self._name)
        self._initialize_snapshot_engine()
        self._validate()

    @property
    def path(self):
        """ Absolute path to the device like '/dev/mapper/vg_mgs-mgs'.
        """

        return self._path

    @property
    def is_exist(self):
        """ Property which indicates the logical volume is created.
        """

        return os.path.exists(self._path)

    def create(self, dry_run=False, force=False):
        """ Creates the logical volume.
        """

        lv_cmd = ['lvcreate', '-n', self._name, '-Wy', '-Zy']
        stripes_count = len(self._vg.underlying_storage_devices)
        if stripes_count != 1:
            lv_cmd.extend(['-i', str(stripes_count), '-I', '1024'])
        if self._size[-1] == '%':
            lv_cmd.extend(['-l', '%sPVS' % self._size, self._vg.name])
        else:
            lv_cmd.extend(['-L', self._size, self._vg.name])

        lvm_config_options = 'activation{volume_list=["%s"]}' % self._vg.name
        lv_cmd.extend(['--config', "'%s'" % lvm_config_options])
        cmd = ' '.join(lv_cmd)

        if not dry_run:
            # Send y because of sometimes we could detect filesystem signature and we should wipe it.
            CmdExecutor(StringCommand('echo y | ' + cmd)).execute(shell=True)
        else:
            print(cmd)

    def _create_snapshot(self, snapshot_name, dry_run=False):
        cmd = 'lvcreate -L1G -s -n {0} {1}'.format(snapshot_name, self._path)
        if dry_run:
            print(cmd)
        else:
            CmdExecutor(StringCommand(cmd)).execute()
        return os.path.join('/dev', self._vg.name, snapshot_name)

    def _destroy_snapshot(self, snapshot_name, dry_run=False):
        cmd = 'lvremove -f {0}'.format(snapshot_name)
        if dry_run:
            print(cmd)
        else:
            CmdExecutor(StringCommand(cmd)).execute()
