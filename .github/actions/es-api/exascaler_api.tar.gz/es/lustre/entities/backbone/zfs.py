# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" ZFS implementation of Lustre block device.
"""


import abc
import os
import re

from scalers.errors import ScalersException, ScalersCommandError
from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand
from .base import BaseBackboneDevice, ZfsRelatedActionsMixin


class ZpoolBaseCmdBuilder(object):
    def __init__(self):
        """ Basic initialization.
        """

        self._dry_run = False
        self._pool = None
        self._device = None
        self._params = dict()
        self._force = False

    def enable_dry_run(self):
        """ Only print what would be done; does not affect the disk.
        """

        self._dry_run = True

    def set_pool_name(self, name):
        """ The Lustre filesystem this service will be part of.
        The maximum filesystem_name length is 8 characters. Required for all targets other than MGT.
        """

        self._pool = name

    def set_block_device(self, device):
        """ Set block device.
        """

        self._device = device

    def set_force(self):
        self._force = True

    @abc.abstractmethod
    def _verify(self):
        """ Verify given parameters.
        """

    def add_param(self, param, value):
        """ Set permanent parameter
        """

        self._params[param] = value

    @abc.abstractmethod
    def build_command_line(self):
        """"""


class ZpoolCreateCmdBuilder(ZpoolBaseCmdBuilder):
    """ Builder of command line arguments for mkfs.lustre command.
    """

    PROPERTIES = ('available', 'capacity', 'expandsize', 'fragmentation', 'free',
                  'freeing', 'health', 'guid', 'size', 'unsupported@', 'used', 'altroot',
                  'readonly', 'ashift', 'autoexpand', 'autoreplace', 'bootfs', 'cachefile',
                  'comment', 'dedupditto', 'delegation' 'failmode', 'feature@', 'listsnapshots',
                  'multihost', 'version')

    ALLOWED_PROPS = {'canmount': 'off', 'multihost': 'on'}  # 'cachefile': 'none',

    def __init__(self):
        """ Basic initialization.
        """
        super(ZpoolCreateCmdBuilder, self).__init__()
        self._comment = None
        self._options = None
        self._reformat = False

    def set_pool_options(self, options):
        """ Format options for the backing fs.
        """

        self._options = options

    def reformat(self):
        """Reformat fs.
        """

        self._reformat = True

    def _verify(self):
        """ Verify given parameters.
        """

        if self._pool is None:
            raise ScalersException("Pool device is missed.")

        if self._device is None:
            raise ScalersException("Vdev block device is missed.")

    def build_command_line(self):
        """ Build command line.
        """

        self._verify()

        parts = ['zpool', 'create', ]

        if self._dry_run:
            parts.append('-n')

        if self._force:
            parts.append('-f')

        if self._options is not None:
            for option, value in self.ALLOWED_PROPS.items():
                if option in self._options:
                    if not "{0}={1}".format(option, value) in self._options:
                        raise ScalersException("Only value '{value}' allowed for property '{option}'"
                                               .format(value=value, option=option))
                if option not in self._options:
                    if option == 'canmount':
                        parts.append("-O {0}={1}".format(option, value))
                    else:
                        parts.append("-o {0}={1}".format(option, value))

        if self._options is None:
            self._options = '-o cachefile=none -O canmount=off -o multihost=on'

        if self._options:
            parts.append(self._options)
        parts.append(self._pool)
        for vdev in self._device:
            parts.append(vdev)

        return ' '.join(parts)


class ZpoolImportExportCmdBuilder(ZpoolBaseCmdBuilder):

    def __init__(self):
        """ Basic initialization.
        """

        super(ZpoolImportExportCmdBuilder, self).__init__()
        self._import = False
        self._export = False

    def enable_import(self):
        """
        """

        self._import = True

    def enable_export(self):
        """
        """

        self._export = True

    def _verify(self):
        """ Verify given parameters.
        """

        if self._pool is None:
            raise ScalersException("Pool device is missed.")

        if not self._import and not self._export:
            raise ScalersException("Choose operation to perform (import or export).")

        if self._import and self._export:
            raise ScalersException("Could not perform both actions import and export in the same time.")

    def build_command_line(self):
        """ Build command line.
        """

        self._verify()

        parts = ['zpool', ]

        if self._import:
            parts.append('import')

        if self._export:
            parts.append('export')

        if self._force:
            parts.append('-f')

        parts.append(self._pool)

        return ' '.join(parts)


class ZpoolDestroyCmdBuilder(ZpoolBaseCmdBuilder):
    def __init__(self):
        """ Basic initialization.
        """

        super(ZpoolDestroyCmdBuilder, self).__init__()

    def _verify(self):
        """ Verify given parameters.
        """

        if self._pool is None:
            raise ScalersException("Pool device is missed.")

    def build_command_line(self):
        """ Build command line.
        """

        self._verify()

        parts = ['zpool', 'destroy']

        if self._force:
            parts.append('-f')

        parts.append(self._pool)

        return ' '.join(parts)


class ZpoolOperations(object):
    VDEVS = ('mirror', 'raidz', 'raidz2', 'raidz3', 'cache', 'spare', 'log', )

    def __init__(self, pool_name, es_config):
        self.pool = pool_name
        self.vdevs = es_config.zpool_settings[pool_name].vdevs
        self.pool_opts = es_config.zpool_settings[pool_name].opts
        self.vdev_base_path = es_config.zpool_settings[pool_name].vdev_base_path
        self._vdev_list = list()

    def create_pool(self, dry_run=False, force=False):
        self.validate_vdevs(dry_run)
        if self.check_existence():
            raise ScalersException("Pool {0} already exists in current system".format(self.pool))

        builder = ZpoolCreateCmdBuilder()
        builder.set_pool_name(self.pool)
        builder.set_block_device(self.vdevs)
        builder.set_pool_options(self.pool_opts)
        if force:
            builder.set_force()
        cmd = builder.build_command_line()

        if dry_run:
            print cmd
        else:
            CmdExecutor(StringCommand(cmd)).execute()

    def destroy_pool(self, dry_run=False, force=False):
        builder = ZpoolDestroyCmdBuilder()
        builder.set_pool_name(self.pool)
        if force:
            builder.set_force()
        cmd = builder.build_command_line()

        if dry_run:
            print cmd
        else:
            CmdExecutor(StringCommand(cmd)).execute()

    def import_pool(self, dry_run=False, force=False):
        builder = ZpoolImportExportCmdBuilder()
        builder.set_pool_name(self.pool)
        builder.enable_import()
        if force:
            builder.set_force()
        cmd = builder.build_command_line()

        if dry_run:
            print cmd
        elif not self.check_existence():
            for pool in self.get_exported_pools():
                if pool.has_key(self.pool):
                    if pool['state'] not in ('ONLINE', 'DEGRADED'):
                        raise ScalersException("Current state of zpool '{zpool}' is {state} and it can't be imported."
                                               .format(zpool=pool['pool'], state=pool['state']))
            CmdExecutor(StringCommand(cmd)).execute()

    def export_pool(self, dry_run=False, force=False):
        builder = ZpoolImportExportCmdBuilder()
        builder.set_pool_name(self.pool)
        builder.enable_export()
        if force:
            builder.set_force()
        cmd = builder.build_command_line()
        if dry_run:
            return cmd
        elif self.check_existence() and self.is_pool_imported():
            CmdExecutor(StringCommand(cmd)).execute()

    def get_imported_pools(self):
        """
        NAME             SIZE  ALLOC   FREE  EXPANDSZ   FRAG    CAP  DEDUP  HEALTH  ALTROOT\n
        mgs             9.94G  1.56M  9.94G         -     0%     0%  1.00x  ONLINE  -\n
        testfs_mdt0000  9.94G  2.11M  9.94G         -     0%     0%  1.00x  ONLINE  -\n
        testfs_ost0000  9.94G  2.26M  9.94G         -     0%     0%  1.00x  ONLINE  -\n
        """

        imported_pools = list()
        column_names = ['NAME', 'SIZE', 'ALLOC', 'FREE', 'EXPANDSZ', 'FRAG', 'CAP', 'DEDUP', 'HEALTH', 'ALTROOT']
        try:
            cmd_output = CmdExecutor(StringCommand('zpool list'.format(self.pool))).execute().strip().splitlines()
            if cmd_output.pop(0).split() == column_names:
                for pool_data in (line.split() for line in cmd_output):
                    imported_pools.append({
                        'pool': pool_data[0],
                        'state': pool_data[0],
                    })
        except ScalersCommandError:
            pass  # ToDo: Report to log maybe?
        return imported_pools

    def get_exported_pools(self):
        exported_pools = list()
        try:
            cmd_output = CmdExecutor(StringCommand('zpool import'.format(self.pool))).execute()
            for match in re.finditer(r'pool:(.*)\n.*id:(.*)\n.*state:(.*)', cmd_output):
                exported_pools.append({
                    'pool': match.group(1),
                    'id': match.group(2),
                    'state': match.group(3),
                })
        except ScalersCommandError:
            pass  # ToDo: Report to log maybe?
        return exported_pools

    def is_pool_imported(self):
        return self.pool in (pool['pool'] for pool in self.get_imported_pools())

    def is_pool_exported(self):
        return self.pool in (pool['pool'] for pool in self.get_exported_pools())

    def check_existence(self):
        try:
            # ToDo: Add additional checks
            CmdExecutor(StringCommand('zpool status {0}'.format(self.pool))).execute()
        except ScalersCommandError:
            return False
        return True

    def _check_vdev_existance(self, vdev):
        return os.path.exists(os.path.join(self.vdev_base_path, vdev))

    def validate_vdevs(self, dry_run=False):
        for vdev in self.vdevs:
            if vdev not in self.VDEVS:
                if not dry_run and not self._check_vdev_existance(vdev):
                    raise ScalersException("Failed to validate vdev with path {0}"
                                           .format(os.path.join(self.vdev_base_path, vdev)))
                else:
                    self._vdev_list.append(os.path.join(self.vdev_base_path, vdev))


class ZfsZpool(BaseBackboneDevice, ZfsRelatedActionsMixin):
    """ Represents ZFS ZPool device."""

    device_type = 'zpool'

    def __init__(self, name, underlying_dev_path, es_config):
        """
        :param name: Name of the zpool.
        :param underlying_dev_path: Path where underlying storage devices can be found.
        :param es_config: :class:`es.cluster.entities.cfg.EXAScalerConfig` object.
        """

        super(ZfsZpool, self).__init__(name, underlying_dev_path, es_config)
        self._datasets = list()
        self.runner = ZpoolOperations(self._name, es_config)
        self.vdevs = es_config.zpool_settings[self._name].vdevs
        self.opts = es_config.zpool_settings[self._name].opts
        self._validate()

    def _validate(self):
        if not self.vdevs:
            raise ScalersException("Missed vdev block devices for pool {0}: {1}".format(self._name, self.vdevs))
        self.runner.validate_vdevs(dry_run=True)

    @property
    def is_exist(self):
        """ Property which indicates whether this zpool was configured.
        """

        return self.runner.check_existence()

    def create(self, dry_run=False, force=False):
        """ Creates the zpool.
        """
        # ToDo: [ES-ZFS] Check if this is necessary for ZFS version > 0.7.5
        # force==True to prevent ZFS kernel errors caused by large amount of async operations in case
        # of huge amount of vdevs (formatting of a whole enclosure as example)
        self.runner.create_pool(dry_run, force=True)

    def destroy(self, dry_run=False, force=False):
        """ Destroys the zpool.
        """

        self.enable(dry_run=False, force=False)
        self.runner.destroy_pool(dry_run, force)

    @property
    def is_enabled(self):
        """ Property which indicates this zpool is imported.
        """

        return self.runner.is_pool_imported()

    def enable(self, dry_run=False, force=False):
        """ Imports the zpool.
        """

        self.runner.import_pool(dry_run, force)

    def disable(self, dry_run=False, force=False):
        """ Exports the zpool.
        """

        self.runner.export_pool(dry_run, force)

    @property
    def underlying_storage_devices(self):
        """ Tuple of underlying storage devices.
        """

        return tuple(self.runner._vdev_list)

    @property
    def are_underlying_storage_devices_exist(self):
        """ Property which indicates whether all underlying storage devices are present.
        """

        return all(os.path.exists(d) for d in self.underlying_storage_devices)

    @property
    def child_storage_devices(self):
        """ Tuple of datasets this zpool provides.
        """

        return tuple(self._datasets)

    def register_child_storage_device(self, name, size):
        """ Registers a dataset.
        :param name: Name of the dataset to add.
        :param size: String representing size of the dataset like '100g' or '500m'.
        """

        dataset = ZfsDataset(name, size, self, self._es_conf)
        self._datasets.append(dataset)
        return dataset


class ZfsDataset(BaseBackboneDevice):
    """ Represents ZFS ZPool device."""

    device_type = 'dataset'

    def __init__(self, name, size, zpool, es_config):
        """
        :param name: Name of the dataset.
        :param size: String representing size of the dataset like '100g' or '500m'.
        :param zpool: :class:`ZfsZpool` object on which this dataset is based.
        :param es_config: :class:`es.cluster.entities.cfg.EXAScalerConfig` object.
        """

        super(ZfsDataset, self).__init__(name, None, es_config)
        self._zpool = zpool
        self._size = size
        self._path = '%s/%s' % (self._zpool.name, self._name)
        self._validate()

    @property
    def path(self):
        """ Path to this dataset including zpool like 'es01a_mdt0000/mdt0000'.
        """

        return self._path
