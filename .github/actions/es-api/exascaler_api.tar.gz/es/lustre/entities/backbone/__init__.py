# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2018, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Block devices which are used by Lustre targets.
"""

from scalers.errors import ScalersException
from .zfs import ZfsZpool as _ZfsZpool
from .base import BlockDevice as _BlockDevice
from .lvm2 import (
    Lvm2VolumeGroup as _Lvm2VolumeGroup,
    Lvm2LogicalVolume as _Lvm2LogicalVolume,
)


_BACKBONE_DEVICES_BY_FS_TYPE = {
    'zfs': dict.fromkeys(('mgs', 'mdt', 'ost'), _ZfsZpool),
    'ldiskfs': {
        'mgs': _Lvm2VolumeGroup,
        'mdt': _Lvm2VolumeGroup,
        'ost': _BlockDevice,
    },
}


def get_supported_backfs_list():
    """ Get list of filesystems supported by EXAScaler as background filesystem."""

    return tuple(sorted(_BACKBONE_DEVICES_BY_FS_TYPE.keys()))


def get_backbone_device_cls(backfs_type, target_type):
    """ Return backbone storage device class corresponding to specified backfs type
    used by targets with given type.
    """

    try:
        backfs_bbd_classes = _BACKBONE_DEVICES_BY_FS_TYPE[backfs_type]
    except KeyError:
        raise ScalersException("Background filesystem '{0}' is not supported. List of supported "
                               "filesystems: {1}.".format(backfs_type, get_supported_backfs_list()))
    try:
        return backfs_bbd_classes[target_type]
    except KeyError:
        raise ScalersException("Unknown target type '{0}' was specified.".format(target_type))


def create_backbone_device(backfs_type, target_type, *args, **kwargs):
    """ Create device instance corresponding to specified target and backfs types.
    """

    return get_backbone_device_cls(backfs_type, target_type)(*args, **kwargs)
