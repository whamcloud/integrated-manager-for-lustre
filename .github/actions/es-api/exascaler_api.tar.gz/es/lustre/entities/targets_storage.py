# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Targets storage realization.
"""

import multiprocessing
from collections import defaultdict

from es.lustre.entities.target.mdt import MDT
from es.lustre.entities.target.mgt import MGT
from es.lustre.entities.target.ost import OST
from es.lustre.commands import load_lustre_modules
from scalers.errors import ScalersException


class TargetsStorageBuilder(object):
    """ Builder class for targets storage.
    """

    def __init__(self, es_config):
        """ Basic initialization
        """

        self._es_config = es_config
        self.targets_all = {fs: dict(mgs_targets=list(), mdt_targets=list(), ost_targets=list())
                            for fs in es_config.global_settings.fs_list}

        self.mgs = None

        for fs in es_config.global_settings.fs_list:

            if es_config.fs_settings[fs].mgs_internal:
                self.mgs = MGT(fs, es_config)
                self.targets_all[fs]['mgs_targets'].append(self.mgs)

            for mds_host in es_config.fs_settings[fs].mds_list:
                host_mdt_idx = 0
                for mdt_idx in es_config.fs_settings[fs].get_mdt_list(mds_host):
                    mdt = MDT(self.mgs, fs, mds_host, mdt_idx, host_mdt_idx, es_config)
                    self.targets_all[fs]['mdt_targets'].append(mdt)
                    host_mdt_idx += 1

            if es_config.fs_settings[fs].mgs_internal:
                self.mgs.set_mdt(self.targets_all[fs]['mdt_targets'][0])

            for oss_host in es_config.fs_settings[fs].oss_list:
                host_ost_idx = 0
                for ost_idx in es_config.fs_settings[fs].get_ost_list(oss_host):
                    ost = OST(fs, self.mgs, oss_host, ost_idx, host_ost_idx, es_config)
                    self.targets_all[fs]['ost_targets'].append(ost)
                    host_ost_idx += 1

    def create_local_storage(self,  fs=None, host=None):
        """ Create targets storage for local node.
        """

        target_list = list()
        target_types = ('mdt_targets', 'mgs_targets', 'ost_targets', )

        if fs is not None:
            if fs not in self.targets_all:
                raise ScalersException("Unknown filesystem '{0}'.".format(fs))
            for target_type in target_types:
                for target in self.targets_all[fs][target_type]:
                    if target.is_local(hostname=host):
                        target_list.append(target)
        else:
            for fs in self.targets_all:
                for target_type in target_types:
                    for target in self.targets_all[fs][target_type]:
                        if target.is_local(hostname=host):
                            target_list.append(target)

        return TargetsStorage(self._es_config, target_list)

    def create_failover_storage(self, fs=None, host=None):
        """ Create targets storage which could be failovers for this node.
        """

        target_list = list()
        target_types = ('mdt_targets', 'mgs_targets', 'ost_targets',)

        if fs is not None:
            if fs not in self.targets_all:
                raise ScalersException("Unknown filesystem '{0}'.".format(fs))
            for target_type in target_types:
                for target in self.targets_all[fs][target_type]:
                    if target.is_failover(hostname=host):
                        target_list.append(target)
        else:
            for fs in self.targets_all:
                for target_type in target_types:
                    for target in self.targets_all[fs][target_type]:
                        if target.is_failover(hostname=host):
                            target_list.append(target)

        return TargetsStorage(self._es_config, target_list)

    def create_all_storage(self, fs=None, host=None):
        """ Create storage with all possible targets for this host.
        """

        target_list = list()
        target_types = ('mdt_targets', 'mgs_targets', 'ost_targets',)

        if fs is not None:
            if fs not in self.targets_all:
                raise ScalersException("Unknown filesystem '{0}'.".format(fs))
            for target_type in target_types:
                for target in self.targets_all[fs][target_type]:
                    if target.is_failover(hostname=host) or target.is_local(hostname=host):
                        target_list.append(target)
        else:
            for fs in self.targets_all:
                for target_type in target_types:
                    for target in self.targets_all[fs][target_type]:
                        if target.is_failover(hostname=host) or target.is_local(hostname=host):
                            target_list.append(target)

        return TargetsStorage(self._es_config, target_list)

    def get_mgs_target_storage(self):
        """ Create storage with MGT target.
        """

        return TargetsStorage(self._es_config, [self.mgs])

    def get_targets_storage(self, fs, mdt_indexes=None, ost_indexes=None, host=None):

        target_list = list()

        if fs not in self.targets_all:
            raise ScalersException("Unknown filesystem '{0}'.".format(fs))

        if mdt_indexes:
            mdt_targets = dict()
            for target in self.targets_all[fs]['mdt_targets']:
                if target.is_failover(hostname=host) or target.is_local(hostname=host):
                    mdt_targets[target.idx] = target
            for idx in mdt_indexes:
                if idx not in mdt_targets:
                    raise ScalersException(
                        "Unavailable MDT target index '{0}' for filesystem '{1}'.".format(idx, fs))
                target_list.append(mdt_targets[idx])

        if ost_indexes:
            ost_targets = dict()
            for target in self.targets_all[fs]['ost_targets']:
                if target.is_failover(hostname=host) or target.is_local(hostname=host):
                    ost_targets[target.idx] = target
            for idx in ost_indexes:
                if idx not in ost_targets:
                    raise ScalersException(
                        "Unavailable OST target index '{0}' for filesystem '{1}'.".format(idx, fs))
                target_list.append(ost_targets[idx])

        return TargetsStorage(self._es_config, target_list)

    def create_storage_for_nsd(self, nsd):
        """ Create storage for nsd disk.
        """

        for fs in self.targets_all:
            for target in self.targets_all[fs]['mdt_targets']:
                if nsd == 'mdt%04d-%s' % (target.idx, target.fs):
                    if target.is_failover() or target.is_local():
                        return TargetsStorage(self._es_config, [target, ])
            for target in self.targets_all[fs]['ost_targets']:
                if nsd == 'ost%04d-%s' % (target.idx, target.fs):
                    if target.is_failover() or target.is_local():
                        return TargetsStorage(self._es_config, [target, ])
            for target in self.targets_all[fs]['mgs_targets']:
                if nsd == 'mgs':
                    if target.is_failover() or target.is_local():
                        return TargetsStorage(self._es_config, [target, ])

        raise ScalersException("Unknown disk '{0}' was specified for local host or mentioned disk could"
                               " not be mounted on local host.".format(nsd))


class TargetsStorage(object):
    """ Storage for Lustre targets.
    """

    class TargetOperationProcess(multiprocessing.Process):
        """ Class for target operation execution in separate process.
        """

        def __init__(self, function, **kwargs):
            """Basic initialization.
            """

            multiprocessing.Process.__init__(self)

            self.args = kwargs
            self.function = function
            manager = multiprocessing.Manager()
            self.output = manager.Value(str, '')
            self.return_code = manager.Value(int, 0)

        def run(self):
            """ Process execution.
            """

            try:
                self.output.value = self.function(**self.args)
            except Exception as error:
                self.output.value = str(error)
                self.return_code.value = 1

    def __init__(self, es_config, targets):
        """ Basic initialization.
        """

        self._targets = targets
        self._config = es_config

    @property
    def target_list(self):
        """ Get list of targets.
        """

        return self._targets

    def _setup_backbone_devices(self, dry_run=False, force=False):
        """ Prepare background filesystem devices used by Lustre filesystem."""

        backbone_devs = set(t.service_device for t in self._targets if t.service_device)
        if not (dry_run or all(d.are_underlying_storage_devices_exist for d in backbone_devs)):
            raise ScalersException('Storage devices not detected.')
        for device in backbone_devs:
            device.create(dry_run=dry_run, force=force)
            for child_device in device.child_storage_devices:
                child_device.create(dry_run=dry_run, force=force)

    def _destroy_backbone_devices(self, dry_run=False, force=False):
        """ Wipe existing background filesystem configuration."""

        backbone_devs = set(t.service_device for t in self._targets if t.service_device)
        if not (dry_run or all(d.are_underlying_storage_devices_exist for d in backbone_devs)):
            raise ScalersException('Storage devices not detected.')
        for device in backbone_devs:
            device.destroy(dry_run=dry_run, force=force)

    def _enable_backbone_devices(self, dry_run=False, force=False):
        """ Enable all disabled background filesystem devices."""

        backbone_devs = set(t.service_device for t in self._targets if t.service_device)
        for device in (d for d in backbone_devs if not d.is_enabled):
            device.enable(dry_run=dry_run, force=force)

    def _disable_backbone_devices(self, dry_run=False, force=False):
        """ Disable all enabled background filesystem devices."""

        targets_not_in_use = (t for t in self._targets if not t.is_in_use())
        for device in set(t.service_device for t in targets_not_in_use if t.service_device):
            device.disable(dry_run=dry_run, force=force)

    def mkfs(self, wipe_backfs, reformat, dry_run=False):
        """ Create and format all devices required for a Lustre filesystem.
        """

        load_lustre_modules(self._config, dry_run=dry_run)
        setup_backfs = wipe_backfs or not reformat

        if wipe_backfs:
            self._destroy_backbone_devices(dry_run=dry_run)
        if setup_backfs:
            self._setup_backbone_devices(dry_run=dry_run, force=(wipe_backfs or reformat))

        self._run_tasks(
            [self.TargetOperationProcess(target.mkfs, reformat=reformat, dry_run=dry_run) for target in self._targets],
            dry_run=dry_run, enable_backfs=not setup_backfs)

    def tunefs(self, writeconf, erase_params, dry_run=False):
        """ Tune all devices required for a Lustre filesystem.
        """

        self._run_tasks(
            [self.TargetOperationProcess(
                target.tunefs,
                erase_params=erase_params,
                write_conf=writeconf,
                dry_run=dry_run) for target in self._targets],
            dry_run=dry_run,
            enable_backfs=True,
            disable_backfs=True,
        )

    def check_mmp(self, host=None):
        """ Check MMP.
        """

        self._run_tasks(
            [self.TargetOperationProcess(target.check_mmp, host=host) for target in self._targets],
            enable_backfs=True, disable_backfs=True)

    def mount(self, options=None, ignore_mtab=False, fs_type='lustre', dry_run=False, manage_backfs=True, force=False):
        """ Mount the targets.
        """

        load_lustre_modules(self._config, dry_run=dry_run)

        if manage_backfs:
            self._enable_backbone_devices(dry_run=dry_run, force=force)

        mgs_tasks = list()
        mdt_tasks = list()
        ost_tasks = list()
        for target in self._targets:
            if target.type == 'mgs':
                mgs_tasks.append(
                    self.TargetOperationProcess(
                        target.mount, fs_type=fs_type, options=options, ignore_mtab=ignore_mtab, dry_run=dry_run))
            elif target.type == 'mdt':
                mdt_tasks.append(
                    self.TargetOperationProcess(
                        target.mount, fs_type=fs_type, options=options, ignore_mtab=ignore_mtab, dry_run=dry_run))
            elif target.type == 'ost':
                ost_tasks.append(
                    self.TargetOperationProcess(
                        target.mount, fs_type=fs_type, options=options, ignore_mtab=ignore_mtab, dry_run=dry_run))

        self._run_tasks(mgs_tasks, dry_run=dry_run, enable_backfs=False, disable_backfs=False)
        self._run_tasks(mdt_tasks, dry_run=dry_run, enable_backfs=False, disable_backfs=False)
        self._run_tasks(ost_tasks, dry_run=dry_run, enable_backfs=False, disable_backfs=False)

    def umount(self, dry_run=False, manage_backfs=True, force=False):
        """ Umount the targets.
        """

        mgs_tasks = list()
        mdt_tasks = list()
        ost_tasks = list()
        for target in self._targets:
            if target.type == 'mgs':
                mgs_tasks.append(
                    self.TargetOperationProcess(target.umount, dry_run=dry_run))
            elif target.type == 'mdt':
                mdt_tasks.append(
                    self.TargetOperationProcess(target.umount, dry_run=dry_run))
            elif target.type == 'ost':
                ost_tasks.append(
                    self.TargetOperationProcess(target.umount, dry_run=dry_run))

        self._run_tasks(ost_tasks, dry_run=dry_run, enable_backfs=False, disable_backfs=False)
        self._run_tasks(mdt_tasks, dry_run=dry_run, enable_backfs=False, disable_backfs=False)
        self._run_tasks(mgs_tasks, dry_run=dry_run, enable_backfs=False, disable_backfs=False)

        if manage_backfs:
            self._disable_backbone_devices(dry_run=dry_run, force=force)

    def fsck(self, mode, fsck_user_param=None, snapshot=False, dry_run=False):
        """ Perform a fsck.
        """

        self._run_tasks(
            [self.TargetOperationProcess(
                target.fsck,
                mode=mode,
                fsck_user_param=fsck_user_param,
                snapshot=snapshot,
                dry_run=dry_run) for target in self._targets],
            dry_run=dry_run,
            enable_backfs=True,
            disable_backfs=True
        )

    def start_lfsck(self, error_level=None, speed=None, lfsck_type=None, dry_run=False):
        """ Start lfsck.
        """

        for target in (t for t in self._targets if t.type == 'mdt'):
            target.start_lfsck(error_level, speed, lfsck_type, dry_run)
        self._disable_backbone_devices(dry_run=dry_run)

    def stop_lfsck(self, dry_run=False):
        """ Stop lfsck.
        """

        for target in (t for t in self._targets if t.type == 'mdt'):
            target.stop_lfsck(dry_run)
        self._disable_backbone_devices(dry_run=dry_run)

    def lfsck_status(self, dry_run=False):
        """ Get lfsck status.
        """

        for target in (t for t in self._targets if t.type == 'mdt'):
            target.lfsck_status(dry_run)
        self._disable_backbone_devices(dry_run=dry_run)

    def _run_tasks(self, task_list, enable_backfs=False, disable_backfs=True, dry_run=False, force=False):
        """ Run tasks in separate processes.
        """

        if enable_backfs:
            self._enable_backbone_devices(dry_run=dry_run, force=force)

        task_errors = list()
        if dry_run:
            for task in task_list:
                task.run()
                if task.return_code.value != 0:
                    task_errors.append(task.output.value)
        else:
            for task in task_list:
                task.start()
            for task in task_list:
                task.join()
                if task.return_code.value != 0:
                    task_errors.append(task.output.value)

        try:
            if disable_backfs:
                self._disable_backbone_devices(dry_run=dry_run, force=force)
        except Exception as e:
            task_errors.append(str(e))

        if task_errors:
            raise ScalersException('\n'.join(task_errors))

    def get_targets_status(self):
        """ Get targets status.
        """

        def _key_func(item):
            """ Predicate used in as key param of `sorted` to sort targets info. Desired targets order: MGT > MDT > OST.
            """

            prefixes = defaultdict(lambda: '3', {'mgs': '0', 'mdt': '1', 'ost': '2'})
            return prefixes[item['resource_name'][:3]] + item['resource_name'][3:]

        status = (dict(status=target.is_mounted(),
                       resource_name=target.target_resource_name,
                       mount_point=target.mount_point,
                       device=target.device.path)
                  for target in self._targets)
        return sorted(status, key=_key_func)
