# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing iperf command.
"""

import json

from scalers.errors import ScalersCommandError
from scalers.utils.cmd import CmdExecutor, CmdOutputParser
from scalers.utils.command import StringCommand


# ---------------------------------------------------------------------------------------

_CHK_SSH_IPERF_COMMAND = 'which iperf3'


class _NodeStatusCheckExecutor(CmdExecutor):
    """ Class for node status checking command execution.
    """

    def execute_command(self, from_host=None):
        """Check node status command execution.
        """
        return CmdExecutor.execute(self, node=from_host)


_chk_status_executor = _NodeStatusCheckExecutor(StringCommand(_CHK_SSH_IPERF_COMMAND))


def ck_node_status(from_host=None):
    """Check node status.
    """

    try:
        _chk_status_executor.execute_command(from_host)
        return True
    except ScalersCommandError:
        return False


# ---------------------------------------------------------------------------------------

_RUN_IPERF_SERVER_COMMAND = 'iperf3 -s -D'


class _ServerStartExecutor(CmdExecutor):
    """ Class for run iperf server.
    """

    def execute_command(self, from_host=None):
        """ Run iperf server command execution.
        """

        return CmdExecutor.execute(self, node=from_host)


_run_server_executor = _ServerStartExecutor(StringCommand(_RUN_IPERF_SERVER_COMMAND))


def run_server(from_host=None):
    """ Run iperf server.
    """

    _run_server_executor.execute_command(from_host)


# ---------------------------------------------------------------------------------------

_STOP_IPERF_SERVER_COMMAND = 'pkill iperf3'


class _ServerStopExecutor(CmdExecutor):
    """ Class for run iperf server.
    """

    def execute_command(self, from_host=None):
        """ Run iperf server command execution.
        """

        return CmdExecutor.execute(self, node=from_host)


_stop_server_executor = _ServerStopExecutor(StringCommand(_RUN_IPERF_SERVER_COMMAND))


def stop_server(from_host=None):
    """ Stop iperf server.
    """

    _stop_server_executor.execute_command(from_host)

# -------------------------------------------------------------------------------------

_IPERF_CLIENT_COMMAND = 'iperf3 -J -c %(to_host)s -t %(time)s -P %(streams)s'


class _IperfParser(CmdOutputParser):
    """ Class for parsing iperf command output
    """

    def _parse(self, output):
        """ Parse iperf output
        """

        try:
            data = json.loads(output)

            upload_bits_per_second = data['end']['sum_sent']['bits_per_second']
            download_bits_per_second = data['end']['sum_received']['bits_per_second']

            return {'upload': str(int(upload_bits_per_second / 1024 / 1024)),
                    'download': str(int(download_bits_per_second / 1024 / 1024))}

        except (ValueError, KeyError):
            self.get_parse_error("Unable to parse iperf3 output")


class _IperfExecutor(CmdExecutor):
    """ Class for iperf command execution.
    """

    def __init__(self, shell_command):
        """ Command output parser initialization.
        """

        super(_IperfExecutor, self).__init__(shell_command, _IperfParser)

    def execute_command(self, to_host, time, streams, from_host=None):
        """ Iperf command execution.
        """

        args = dict(to_host=to_host, time=time, streams=streams)
        return self.execute(node=from_host, args=args)


_iperf_executor = _IperfExecutor(StringCommand(_IPERF_CLIENT_COMMAND))


def run_iperf(to_host, time, streams, from_host=None):
    """ Run iperf test for pair of nodes.
    """

    return _iperf_executor.execute_command(to_host, time, streams, from_host)
