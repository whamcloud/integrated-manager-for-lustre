# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing mount command.
"""


from scalers.utils.cmd import CmdExecutor
from scalers.utils.command import StringCommand
from scalers.errors import ScalersException


class MountCmdBuilder(object):
    """ Builder of command line arguments for mount command.
    """

    def __init__(self):
        """ Basic initialization.
        """

        self._fs_type = None
        self._ignore_mtab = False
        self._options = None
        self._device = None
        self._mount_point = None

    def set_filesystem_type(self, fs_type):
        """ Set filesystem type.
        """

        self._fs_type = fs_type

    def set_device(self, device):
        """ Set device.
        """

        self._device = device

    def set_mount_point(self, mount_point):
        """ Set mount point.
        """

        self._mount_point = mount_point

    def set_mount_options(self, options):
        """ Set mount options.
        """

        self._options = options

    def ignore_mtab(self):
        """ Mount without writing in /etc/mtab.
        """

        self._ignore_mtab = True

    def _verify(self):
        """ Verify cmd params.
        """

        if self._fs_type is None:
            raise ScalersException('Filesystem type missed in mount command.')

        if self._device is None:
            raise ScalersException('Device missed in mount command.')

        if self._mount_point is None:
            raise ScalersException('Mount point missed in mount command.')

    def build_command_line(self):
        """ Build command line.
        """

        self._verify()

        parts = ['mount', '-t', self._fs_type, ]
        if self._ignore_mtab:
            parts.append('-n')
        if self._options is not None:
            parts.append('-o {0}'.format(self._options))
        parts.append(self._device)
        parts.append(self._mount_point)

        return ' '.join(parts)


def mount(builder, log_file=None):
    """ Run mount command.
    :param log_file: file for logging
    :param builder:  MountCmdBuilder instance
    """

    return CmdExecutor(StringCommand(builder.build_command_line())).execute(log_file=log_file)
