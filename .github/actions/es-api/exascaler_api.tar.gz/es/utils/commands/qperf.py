# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing qperf command.
"""
import re

from scalers.errors import ScalersCommandError
from scalers.utils.cmd import CmdExecutor, CmdOutputParser
from scalers.utils.command import StringCommand


def is_qperf_test_possible(node=None):
    """ Check node status.
    """

    try:
        CmdExecutor(StringCommand('which qperf')).execute(node=node)
        CmdExecutor(StringCommand('which ddn-ibdev2netdev')).execute(node=node)
        return True
    except ScalersCommandError:
        return False


def run_server(node=None):
    """ Run qperf server.
    """

    CmdExecutor(StringCommand('qperf')).execute_without_waiting(node=node)


def stop_server(node=None):
    """ Stop qperf server.
    """

    CmdExecutor(StringCommand('pkill qperf')).execute(node=node, ensure_success=False)

# -------------------------------------------------------------------------------------

_QPERF_CLIENT_COMMAND = 'qperf %(to_host)s -li %(local_device)s:%(local_port)s' \
                        ' -ri %(remote_device)s:%(remote_port)s -t %(time)s uc_bi_bw'

_RE_NODE = re.compile(r'^\s*uc_bi_bw:\s*\n'
                      r'\s*send_bw\s*=\s*(?P<send>.+)\s*\n'
                      r'\s*recv_bw\s*=\s*(?P<recv>.+)\s*$')


class _QperfParser(CmdOutputParser):
    """ Class for parsing qperf command output
    """

    def _parse(self, output):
        """ Parse qperf output
        """

        results = re.findall(_RE_NODE, output)
        if len(results) != 1:
            self.get_parse_error("Unable to parse qperf command output.")
        else:
            return {'upload': results[0][0], 'download': results[0][1]}


class _QperfExecutor(CmdExecutor):
    """ Class for qperf command execution.
    """

    def __init__(self, shell_command):
        """ Command output parser initialization.
        """

        super(_QperfExecutor, self).__init__(shell_command, _QperfParser)

    def execute_command(self, to_host, to_device, to_port, from_device, from_port, time, from_host=None):
        """ Qperf command execution.
        """

        args = dict(to_host=to_host, time=time, local_device=from_device, local_port=from_port, remote_device=to_device,
                    remote_port=to_port)
        return self.execute(node=from_host, args=args)


_qperf_executor = _QperfExecutor(StringCommand(_QPERF_CLIENT_COMMAND))


def run_qperf(to_host, to_device, to_port, from_device, from_port, time, from_host=None):
    """ Run qperf test for pair of nodes.
    """

    return _qperf_executor.execute_command(to_host, to_device, to_port, from_device, from_port, time, from_host)
