# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2017, DataDirect Networks, Inc.
#
# ******************************************************************************

import re
import json

from scalers.errors import ScalersCommandError, ScalersException
from scalers.utils.command import StringCommand, CommandExecutor
from scalers.utils.cmd import CmdExecutor, CmdOutputParser


CM_MODE = 'cm'
ETH_MODE = 'eth'
IB_MODE = 'ib'
MODES = (CM_MODE, ETH_MODE, IB_MODE, )


def stop_upload_server(node=None):
    CommandExecutor(StringCommand('pkill ib_write_bw')).run(node=node)


def stop_download_server(node=None):
    CommandExecutor(StringCommand('pkill ib_read_bw')).run(node=node)


def add_mode_params(cmd, mode='ib'):

    if mode not in MODES:
        raise ScalersException("Unknown connection mode '{0}' was specified. Possible values are: {1}.". format(
            mode, ','.join(["'{0}'".format(connection_mode) for connection_mode in MODES])
        ))

    if mode == 'eth':
        cmd += ' -x0'
    elif mode == 'cm':
        cmd += ' -R'

    return cmd


def start_upload_server(device, port, connection_type, node=None):
    cmd = 'ib_write_bw -d {0} -i {1} -a'
    CmdExecutor(StringCommand(add_mode_params(cmd, connection_type).format(device, port))).\
        execute_without_waiting(node=node)


def start_download_server(device, port, connection_type, node=None):
    cmd = 'ib_read_bw -d {0} -i {1} -a'
    CmdExecutor(StringCommand(add_mode_params(cmd, connection_type).format(device, port))).\
        execute_without_waiting(node=node)


class IbBandwidthClientParser(CmdOutputParser):

    def _parse(self, output):

        lines = output.split('\n')

        for line in lines:
            results_template = re.compile(r'^\s*(?P<bytes>\d+)\s+'
                                          r'(?P<iterations>\d+)\s+'
                                          r'(?P<peak>\S+)\s+'
                                          r'(?P<average>\S+)(\s+'
                                          r'(?P<rate>\S+))?\s*$')

            results = re.match(results_template, line)
            if results is not None:
                return results.group('average')

        self.get_parse_error("Unable to parse ib_write_bw or ib_read_bw output")


class IbBandwidthClientExecutor(CmdExecutor):
    """ Class for client command execution.
    """

    def __init__(self, shell_command):
        """ Command output parser initialization.
        """

        super(IbBandwidthClientExecutor, self).__init__(shell_command, IbBandwidthClientParser)

    def execute_command(self, to_host, device, port, size, from_host=None):
        """ Command execution.
        """

        args = dict(to_host=to_host, device=device, port=port, size=size)

        return self.execute(node=from_host, args=args)


def start_upload_test(to_host, device, port, size, connection_type='ib', from_host=None):

    cmd = 'ib_write_bw %(to_host)s -d %(device)s -i %(port)s -s %(size)s'

    return IbBandwidthClientExecutor(StringCommand(add_mode_params(cmd, connection_type))).execute_command(
        to_host, device, port, size, from_host)


def start_download_test(to_host, device, port, size, connection_type='ib', from_host=None):

    cmd = 'ib_read_bw %(to_host)s -d %(device)s -i %(port)s -s %(size)s'
    return IbBandwidthClientExecutor(StringCommand(add_mode_params(cmd, connection_type))).execute_command(
        to_host, device, port, size, from_host)


class InfinibandDevice(object):
    """ Infiniband device representation.
    """

    def __init__(self, name, port, interface, status):
        """ Base initialization.
        """

        self.name = name
        self.port = port
        self.interface = interface
        self.status = status

    def is_device_active(self):
        return self.status == 'up'


class IbDev2NetDevParser(CmdOutputParser):

    def _parse(self, output):

        return {ib_device['interface']: InfinibandDevice(
            ib_device['device'], ib_device['port'], ib_device['interface'], ib_device['status'])
                for ib_device in json.loads(output)}


class IbDev2NetDevExecutor(CmdExecutor):
    """ Class for client command execution.
    """

    def __init__(self, shell_command):
        """ Command output parser initialization.
        """

        super(IbDev2NetDevExecutor, self).__init__(shell_command, IbDev2NetDevParser)


def ibdev2netdev(node=None):
    return IbDev2NetDevExecutor(StringCommand('ddn-ibdev2netdev --api')).execute(node=node)


def is_ib_test_possible(node=None):

    try:
        CmdExecutor(StringCommand('which ib_read_bw')).execute(node=node)
        CmdExecutor(StringCommand('which ib_write_bw')).execute(node=node)
        CmdExecutor(StringCommand('which ddn-ibdev2netdev')).execute(node=node)
        return True
    except ScalersCommandError:
        return False
