# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Functionality for executing fping command.
"""


from scalers.utils.cmd import CmdExecutor, CmdOutputParser
from scalers.utils.command import StringCommand


FPING_COMMAND = 'fping -r1 %(to_host)s'


class FpingParser(CmdOutputParser):
    """Class for parsing fping command output
    """

    def _parse(self, output):
        """ Parse fping output
        """

        fping_results = dict()

        for line in output.splitlines():
            # skip blank lines
            if not line.strip():
                continue
            parts = line.split(' ', 2)
            if len(parts) != 3:
                raise self.get_parse_error('Unable to parse fping output.')
            # actual status line
            host = parts[0]
            status = parts[2]
            fping_results[host] = 0 if status == "alive" else 1
            # other lines are error reports and skippable, a status line will come later

        return fping_results


class FpingExecutor(CmdExecutor):
    """ Class for fping command execution.
    """

    def __init__(self, shell_command):
        """ Command output parser initialization.
        """
        super(FpingExecutor, self).__init__(shell_command, FpingParser)

    def execute_command(self, to_host):
        """ Fping command execution.
        """
        args = dict(to_host=to_host)
        return CmdExecutor.execute(self, args=args, ensure_success=False)


_fping_executor = FpingExecutor(StringCommand(FPING_COMMAND))


def fping(to_host):
    """ Run fping.
    """

    return _fping_executor.execute_command(to_host)
