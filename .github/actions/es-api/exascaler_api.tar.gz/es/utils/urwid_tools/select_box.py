# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************


""" Realization of SelectBox for urwid library
"""


import urwid


class SelectBoxContent(urwid.WidgetWrap):
    """ SelectBox panel for display selectable items
    """

    signals = ['close']

    def __init__(self, items, title="", select_item_handler=None):
        """ Initialization of SelectBox panel
        """

        self.__select_item_handler = select_item_handler
        self.__items = items
        self.__title = title

        panel_content = self.__build_panel_content()
        fill = urwid.Filler(urwid.Pile(panel_content))

        super(SelectBoxContent, self).__init__(urwid.AttrWrap(fill, 'popbg'))

    def __build_panel_content(self):
        """ Initialize widgets for select box panel
        """

        panel_content = list()

        panel_content.append(urwid.Text(self.__title, "center"))
        panel_content.append(urwid.Divider("-"))

        for item in self.__items:
            button = urwid.Button(item, self.__get_on_click_handler())

            button = urwid.AttrWrap(button, 'button', 'button_select')
            button = urwid.LineBox(button)
            button = urwid.Padding(button, left=2, right=2)

            panel_content.append(button)

        panel_content.append(urwid.Divider("-"))

        return panel_content

    def __get_on_click_handler(self):
        """ Return on_click handler
        """

        def on_click(*args):
            """ On item click handler
            """

            button_position = 0

            if self.__select_item_handler:
                self.__select_item_handler(args[button_position].label)

            self._emit("close")

        return on_click


class SelectBox(urwid.PopUpLauncher):
    """ SelectBox for urwid library

        SelectBox can be initialize with list of strings:
        select_box = SelectBox(["item1", "item2", "item3"])

        When any item selected, SelectBox call select_item_handler with
        name of selected item, so select_item_handler should be like this:
        def select_item_handler(selected_item)

    """

    def __init__(self, items=None, start_index=0, select_item_handler=None, title=""):
        """ Initialization of SelectBox
        """

        if not items:
            raise AttributeError("Invalid inputs")

        self.__items = items
        self.__title = title

        self.__state = items[0]

        if select_item_handler and not callable(select_item_handler):
            raise AttributeError("select_item_handler should be a callable object")
        self.__select_item_handler = select_item_handler

        self.__current_state = items[start_index]
        self.__select_box_button = urwid.Button(self.__current_state)
        button = urwid.AttrWrap(self.__select_box_button, 'button', 'button_select')
        button = urwid.LineBox(button)

        super(SelectBox, self).__init__(button)
        urwid.connect_signal(self.__select_box_button, 'click', lambda _: self.open_pop_up())

    def __get_select_item_handler(self):
        """ Return select_item_handler
        """

        def select_item_handler(label):
            """ Handler for selected item
            """

            self.__state = label
            self.__select_box_button.set_label(label)

            if self.__select_item_handler is not None:
                self.__select_item_handler(label)

            self.close_pop_up()

        return select_item_handler

    def create_pop_up(self):
        """ Create panel with buttons for selecting
        """

        pop_up = SelectBoxContent(self.__items, self.__title, select_item_handler=self.__get_select_item_handler())
        urwid.connect_signal(pop_up, 'close', lambda button: self.close_pop_up())
        return pop_up

    def get_pop_up_parameters(self):
        """ Parameters for panel
        """

        return {'left': 1, 'top': 1, 'overlay_width': 30, 'overlay_height': 20}
