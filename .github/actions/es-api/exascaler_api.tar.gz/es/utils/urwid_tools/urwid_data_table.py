# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************


""" Realization of UrwidDataTable widget
"""

import urwid
from urwid_widget_builder import UrwidWidgetBuilder
from enum import Enum
from scalers.errors import ScalersInternalError


class DisplayOptions(Enum):
    editable = 1
    label = 2
    widget = 3
    empty = 4


class UrwidDataTable(object):
    """ DataTable widget that represents data from UrwidFilteredDataGrid
    """

    palette = [
        ('body', 'black', 'light gray', 'underline'),
        ('header', 'white', 'dark blue', 'bold'),
        ('button', 'white', 'dark gray'),
        ('old_style_text', 'dark red', 'light gray'),
        ('new_style_text', 'light green', 'light gray'),
        ('button_select', 'white', 'dark blue', 'bold'),
        ('error_footer', 'white', 'dark red'),
        ('successful_footer', 'white', 'dark blue', 'bold'),
        ('input', 'black', 'dark cyan', 'bold'),
        ('disable_widget', 'dark gray', 'light gray'),
        ('normal_widget', 'black', 'light gray', 'underline'),
        ('line', 'black', 'dark gray')
    ]

    def __init__(self, data_grid, table_column_names=None, display_options=None, proportions=None, table_title=""):
        """ Initialization of urwid data table widget
        """

        if not data_grid:
            raise AttributeError("Empty grid")

        # Data grids initialization
        self._data_grid = data_grid
        self._data_grid_to_display = data_grid

        self._data_grid_to_display.add_listener(self.get_update_info_in_cell())

        # Widgets initialization
        self._widgets = list()
        self._table_lines = None
        self._sorted_table_lines_indexes = None
        self._table_widgets = None

        self._table_header_line = None

        self._edit_cell_listener = None
        self._edit_validator = None

        # Table info
        self._table_column_names = table_column_names if table_column_names else self._data_grid.get_column_names()
        self._display_options = [DisplayOptions.label for index in xrange(len(self._table_column_names))] \
            if not display_options else display_options

        self._table_title = table_title
        self._proportions = proportions

        # Widget Builder
        self.builder = UrwidWidgetBuilder()

    # Methods for updating data

    def set_attr_to_cell(self, x, y, attr):
        """ Set attr to cell by coordinates
        """

        line = self._table_lines[x]
        widget_index = 0
        line.contents[y][widget_index].set_attr(attr)

    def get_widget_from_cell(self, line_number, column_number):
        """ Get widget by coordinates
        """

        line = self._table_lines[line_number]
        widget_index = 0

        return line.contents[column_number][widget_index].original_widget

    def fill_column_data(self, column_index, column_content=None):
        """ Fill column in table
        """

        if self._table_header_line is None:
            self._build_table()

        for position_index, table_line_index in enumerate(self._sorted_table_lines_indexes):

            if column_content is not None:
                new_cell = self._build_widget_by_display_option(self._display_options[column_index],
                                                                column_content[position_index])
            else:
                new_cell = urwid.Text(" ")

            widget = urwid.AttrWrap(new_cell, "body")
            self._table_lines[table_line_index].widget_list[column_index] = widget

    def set_widget_in_cell(self, line_number, column_number, widget):
        """ Set widget in cell by coordinates
        """

        line = self._table_lines[line_number]
        widget_position = 0
        line.contents[column_number][widget_position].original_widget = widget

    def display_lines(self, indexes_of_lines):
        """ Shows lines in table by indexes in list indexes_of_lines
        """

        lines = [self._table_lines[index] for index in indexes_of_lines]

        table_widgets = list()
        for table_line in lines:
            table_widgets.append(table_line)
            table_widgets.append(urwid.Divider("-"))

        self._table_widgets.widget_list = table_widgets
        self._data_grid_to_display = self._data_grid.get_subgrid_by_indexes_of_lines(indexes_of_lines)

    def display_all_lines(self):
        """ Shows all lines
        """

        table_widgets = list()
        for table_line in self._sorted_table_lines_indexes:
            table_widgets.append(table_line)
            table_widgets.append(urwid.Divider("-"))

        self._table_widgets.widget_list = table_widgets
        self._data_grid_to_display = self._data_grid

    # Method for data grid operations

    def get_displayed_lines_indexes(self):
        """ Returns list of displayed lines
        """

        return self._data_grid_to_display.get_line_indexes()

    def get_displayed_data(self):
        """ Returns original data that displayed on data_table in current moment
        """

        return self._data_grid_to_display.get_original_data()

    def get_displayed_grid(self):
        """ Returns displayed grid
        """

        return self._data_grid_to_display

    # Methods for building widgets

    def build_table_widget(self):
        """ Returns urwid table widget
        """

        if self._table_lines is None:
            self._build_table()

        return self.builder.build_widget()

    def _build_table_lines(self):
        """ Builds table lines according to data_grid
        """

        table_lines = list()
        for line_number, line in self._data_grid_to_display:
            line_content = list()

            data_grid_names = self._data_grid_to_display.get_column_names()
            data_grid_column_index = 0
            for column_index, column_name in enumerate(self._table_column_names):
                if column_name in data_grid_names:
                    name = line[data_grid_column_index]
                    data_grid_column_index += 1
                else:
                    name = None
                widget = self._build_widget_by_display_option(self._display_options[column_index],
                                                              name, (line_number, column_index))

                widget_with_options = ('weight', self._proportions[column_index], widget) \
                                        if self._proportions else widget
                line_content.append(widget_with_options)

            line_widget = urwid.Columns(line_content, dividechars=3)
            table_lines.append(line_widget)

        return table_lines

    def _build_table(self):
        """ Builds table widgets with UrwidWidgetBuilder
        """

        if self._table_header_line is None:
            self._build_table_header_line()

        self.builder \
            .add_divider() \
            .add_widget(self._table_header_line) \
            .add_divider("=")

        table_lines = self._build_table_lines()
        self._sorted_table_lines_indexes = self._data_grid.get_line_indexes()
        self._table_lines = dict(zip(self._sorted_table_lines_indexes, table_lines))

        table_widgets = list()
        for table_line_index in self._sorted_table_lines_indexes:
            table_widgets.append(self._table_lines[table_line_index])
            table_widgets.append(urwid.Divider("-"))

        self._table_widgets = urwid.Pile(table_widgets)
        self.builder.add_widget(self._table_widgets)
        self.builder.create_line_box_for_previous_elements(title=self._table_title)

    def _build_table_header_line(self):
        """ Creates table header line
        """

        column_names = self._table_column_names
        if len(column_names) == 0:
            raise ScalersInternalError("Data grid is empty")

        line_content = list()

        for index, column_name in enumerate(column_names):
            column_name_widget = urwid.Text(column_name, 'center')
            column_name_widget = urwid.AttrWrap(column_name_widget, 'input')

            widget_with_options = ('weight', self._proportions[index], column_name_widget) \
                                    if self._proportions else column_name_widget
            line_content.append(widget_with_options)

        self._table_header_line = urwid.Columns(line_content, dividechars=3)

    def _build_widget_by_display_option(self, display_option, content, position_in_table=None):
        """ Builds and returns new widget according to display_option

            if display_option == editable -> urwid.Edit
            if display_option == label    -> urwid.Text
            if display_option == widget   -> set widget, that send as argument (content)
            if display_option == empty    -> urwid.Text(" ") (no effect on table, just empty space)
        """

        if display_option == DisplayOptions.editable:
            widget = urwid.Edit(edit_text=content)
            urwid.connect_signal(widget, 'change', self.get_edit_cell_handler())
            attr = "input"

        elif display_option == DisplayOptions.label:
            widget = urwid.Text(content)
            attr = "body"

        elif display_option == DisplayOptions.widget:
            widget = content if content is not None else urwid.Text(" ")

            attr = "body"

        elif display_option == DisplayOptions.empty:
            widget = urwid.Text("")
            attr = "body"
        else:
            raise AttributeError("Unknown display option {0}".format(display_option))

        if position_in_table is not None:
            widget.position_in_table = position_in_table

        widget = urwid.AttrWrap(widget, attr)

        return widget

    # Handlers and listeners

    def get_update_info_in_cell(self):
        """ Returns update_info_in_cell
        """

        def update_info_in_cell(line_number, cell_name, value):
            """ Update text in widget by coordinates
            """

            cell_index = self._table_column_names.index(cell_name)

            line = self._table_lines[line_number]
            cell = line.contents[cell_index]

            widget_position = 0

            if self._display_options[cell_index] == DisplayOptions.editable:
                cell[widget_position].original_widget.edit_text = value
            elif self._display_options[cell_index] == DisplayOptions.label:
                cell[widget_position].original_widget.set_text(value)
            else:
                raise AttributeError("Uneditable widget")

        return update_info_in_cell

    def get_edit_cell_handler(self):
        """ Returns edit_cell_handler
        """

        def edit_cell_handler(edit, new_text):
            """ Event handler for changing disk name
            """

            coords = edit.position_in_table
            widget_line, widget_column = coords
            column_name = self._table_column_names[widget_column]

            grid_column_names = self._data_grid_to_display.get_column_names()
            grid_column_index = grid_column_names.index(column_name)

            self._data_grid_to_display.set_item_without_callback((widget_line, grid_column_index), new_text)
            self._data_grid.set_item_without_callback((widget_line, grid_column_index), new_text)

            if self._edit_cell_listener is not None:
                self._edit_cell_listener(coords, new_text)

        return edit_cell_handler

    def set_edit_cell_listener(self, listener):
        """ Set listener for disk name changing
        """

        self._edit_cell_listener = listener
