# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Realization of UrwidWidgetBuilder
"""

import urwid
from select_box import SelectBox
from scalers.errors import ScalersInternalError


class UrwidWidgetBuilder(object):
    """ UI builder for urwid library
    """

    palette = [
        ('body', 'black', 'light gray', 'underline'),
        ('header', 'white', 'dark blue', 'bold'),
        ('button', 'white', 'dark gray'),
        ('old_style_text', 'dark red', 'light gray'),
        ('new_style_text', 'light green', 'light gray'),
        ('button_select', 'white', 'dark blue', 'bold'),
        ('error_footer', 'white', 'dark red'),
        ('successful_footer', 'white', 'dark blue', 'bold'),
        ('input', 'black', 'dark cyan', 'bold'),
        ('disable_widget', 'dark gray', 'light gray'),
        ('normal_widget', 'black', 'light gray', 'underline'),
        ('line', 'black', 'dark gray')
    ]

    def __init__(self):
        """ Initialization of builder
        """

        self._content = list()
        self.__header = None
        self.__bound_widgets = dict()
        self.__last_added_clear_widget = None

    def add_button(self, label, on_press=None, user_data=None):
        """ Create and add new button to builder content
        """

        button = urwid.Button(label, on_press, user_data)
        self.__last_added_clear_widget = button

        button = urwid.AttrWrap(button, 'button', 'button_select')
        button = urwid.LineBox(button)
        button = urwid.Padding(button, left=2, right=2)

        self._content.append(button)

        return self

    def add_radio_button(self, group, label, state=False, on_state_change=None, user_data=None):
        """ Create and add new radio button to builder content
        """

        radio_button = urwid.RadioButton(group, label, on_state_change=on_state_change,
                                         user_data=user_data)

        radio_button.set_state(state, do_callback=False)
        self.__last_added_clear_widget = radio_button

        self._content.append(radio_button)
        return self

    def add_check_box(self, label, attr=None, on_state_change=None, is_button_like=False):
        """ Create and add new check box to builder content
        """

        check_box = urwid.CheckBox(label, on_state_change=on_state_change)
        self.__last_added_clear_widget = check_box

        if is_button_like:
            check_box = urwid.LineBox(check_box)
            check_box = urwid.Padding(check_box, left=2, right=2)

        if attr is not None:
            check_box = urwid.AttrWrap(check_box, attr)

        self._content.append(check_box)
        return self

    def add_select_box(self, items, start_index=0, select_item_handler=None, title=""):
        """ Create and add new select box to builder content
        """

        select_box = SelectBox(items, start_index, select_item_handler, title)
        self.__last_added_clear_widget = select_box

        self._content.append(select_box)
        return self

    def add_divider(self, div_char=u"-", top=0, bottom=0):
        """ Create and add new divider to builder content
        """

        divider = urwid.Divider(div_char, top, bottom)
        self.__last_added_clear_widget = divider
        self._content.append(divider)

        return self

    def add_text(self, text, align='left', attr=None):
        """ Create and add new Text to builder content
        """

        text = urwid.Text(text, align=align)
        self.__last_added_clear_widget = text
        if attr is not None:
            text = urwid.AttrWrap(text, attr)
        self._content.append(text)

        return self

    def add_widget(self, widget):
        """ Add widget to builder content
        """

        self._content.append(widget)
        self.__last_added_clear_widget = widget
        return self

    def add_edit(self, edit_text="", edit_text_handler=None, attr="input", user_data=None, caption=""):
        """ Create and add new edit field to builder content
        """

        edit = urwid.Edit(caption=caption, edit_text=edit_text)
        self.__last_added_clear_widget = edit

        if user_data is not None:
            edit.index = user_data

        if edit_text_handler is not None:
            urwid.connect_signal(edit, 'change', edit_text_handler)

        if attr is not None:
            edit = urwid.AttrWrap(edit, attr)

        self._content.append(edit)
        return self

    def add_int_edit(self, caption="", default=0, edit_number_handler=None, attr="input"):
        """ Create and add new IntEdit field to builder content
        """

        int_edit = urwid.IntEdit(caption=caption, default=default)
        self.__last_added_clear_widget = int_edit

        if edit_number_handler is not None:
            urwid.connect_signal(int_edit, 'change', edit_number_handler)

        if attr is not None:
            int_edit = urwid.AttrWrap(int_edit, attr)

        self._content.append(int_edit)
        return self

    def attr_wrap_for_last_widget(self, attr):
        """ Wrap last widget into urwid.AttrWrap
        """

        if not self._content:
            raise ScalersInternalError("Builder content is empty")

        widget = self._content.pop()
        widget = urwid.AttrWrap(widget, attr)

        self.__last_added_clear_widget = widget
        self._content.append(widget)

        return self

    def bound_last_widget_with_name(self, bound_name):
        """
            Bound last widget in content with name.
            Need for access to widget by name like this:

            builder\
                .add_edit().bound_last_widget_with_name("age_edit")\
                .add_button()

            edit_widget = builder.get_bound_widget("age_edit")

        """

        if not self._content:
            raise ScalersInternalError("Builder content is empty")

        if bound_name in self.__bound_widgets:
            raise ScalersInternalError("Bound name {0} already exists".format(bound_name))

        self.__bound_widgets[bound_name] = self.__last_added_clear_widget
        return self

    def get_bound_widget(self, widget_name):
        """ Return widget by bound name
        """

        if widget_name not in self.__bound_widgets:
            raise ScalersInternalError("Bound name {0} not found".format(widget_name))

        return self.__bound_widgets[widget_name]

    def insert_into_line_previous_elements(self, number_of_widgets=None, dividechars=0, attr=None):
        """ Takes widgets from content and wrap this widgets into urwid.Columns

            If number_of_widgets is None, wrap all widgets in content
        """

        if not self._content:
            raise ScalersInternalError("Builder content is empty")

        if number_of_widgets is None:
            number_of_widgets = len(self._content)

        if number_of_widgets < 0:
            raise ScalersInternalError("Negative number of widgets to wrap")

        if len(self._content) < number_of_widgets:
            raise ScalersInternalError("Widgets to wrap more then urwid builder contain ({0} < {1})"
                                        .format(len(self._content), number_of_widgets))

        index = len(self._content) - number_of_widgets
        widgets_to_wrap = self._content[index:]

        line = urwid.Columns(widgets_to_wrap, dividechars=dividechars)

        self.__last_added_clear_widget = line

        if attr:
            line = urwid.AttrWrap(line, attr)

        self._content = self._content[:index]
        self._content.append(line)

        return self

    def create_line_box_for_previous_elements(self, number_of_widgets=None, title=""):
        """ Takes widgets from content and wrap this widgets into line box

            If number_of_widgets is None, wrap all widgets in content
        """

        if not self._content:
            raise ScalersInternalError("Builder content is empty")

        if number_of_widgets is None:
            number_of_widgets = len(self._content)

        if number_of_widgets < 0:
            raise ScalersInternalError("Negative number of widgets to wrap")

        if len(self._content) < number_of_widgets:
            raise ScalersInternalError("Widgets to wrap more then urwid builder contain ({0} < {1})"
                                        .format(len(self._content), number_of_widgets))

        index = len(self._content) - number_of_widgets
        widgets_to_wrap = self._content[index:]
        widgets_to_wrap = urwid.LineBox(urwid.Pile(widgets_to_wrap), title=title)

        self._content = self._content[:index]
        self._content.append(widgets_to_wrap)

        return self

    def set_header(self, header_text, attr='header'):
        """ Create header
        """

        header_text = urwid.Text(header_text, align='center')
        self.__header = urwid.AttrWrap(header_text, attr)

        return self

    def get_content(self):
        """ Returns builder content
        """

        return self._content

    def build_frame(self):
        """ Create frame with builder content
        """

        if not self._content:
            raise ScalersInternalError("Builder content is empty")

        frame_content = urwid.ListBox(urwid.SimpleFocusListWalker(self._content))
        frame_content.set_focus = 'above'
        frame_content = urwid.AttrWrap(frame_content, 'body')

        return urwid.Frame(body=frame_content, header=self.__header)

    def build_widget(self):
        """ Create urwid.Pile with builder content
        """

        if not self._content:
            raise ScalersInternalError("Builder content is empty")

        return urwid.Pile(self._content)
