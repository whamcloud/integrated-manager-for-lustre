# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" UrwidFilteredDataGrid realization
"""

from urwid_data_grid import UrwidDataGrid


DEFAULT_FILTER_LABEL = "Show all"


class UrwidFilteredDataGrid(UrwidDataGrid):
    """ DataGrid fit filtering functionality
    """

    def __init__(self, data, names):
        """ Initialization grid
        """

        super(UrwidFilteredDataGrid, self).__init__(data, names)

        # Set default filter, that display all lines by first column
        self.__filters = {DEFAULT_FILTER_LABEL: (names[0], lambda cell: True)}

    def add_filter(self, filter_label, column_name, filter_func):
        """
        Args:
            filter_label: Filter name that can be selected on displayed frame for filter content in table
            column_name: Column for which filter is designed
            filter_func: Filter function for filter content

            Filter function should look like this:
            def filter_name(cell) -> bool

        """

        if column_name not in self._names:
            raise AttributeError("Column '{0}' doesn't exists in table".format(column_name))

        if not callable(filter_func):
            raise AttributeError("filter_func should be a callable object")

        if filter_label in self.__filters:
            raise AttributeError("Filter {0} already exists".format(filter_label))

        self.__filters[filter_label] = (column_name, filter_func,)

    def get_filters(self):
        """ Returns filters
        """

        return self.__filters

    def get_indexes_of_filtered_data(self, filter_name):
        """ Returns indexes of lines that passed filtering
        """

        if filter_name not in self.__filters:
            raise AttributeError("Filter {0} not found".format(filter_name))

        column_name, filter_func = self.__filters[filter_name]
        column_index = self._names.index(column_name)

        valid_indexes = [index for index in self._index_data if filter_func(self.__getitem__((index, column_index)))]

        return valid_indexes
