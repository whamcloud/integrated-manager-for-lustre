# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************


""" Realization of UrwidDataTable widget
"""

import urwid
from urwid_data_table import UrwidDataTable
from select_box import SelectBox


class UrwidFilteredDataTable(UrwidDataTable):
    """ Realization of DataTable widget with filtered functionality
    """

    def __init__(self, data_grid, table_column_names=None, display_options=None, proportions=None, table_title=""):
        """ Initialization of urwid data table widget with filtered functionality
        """

        super(UrwidFilteredDataTable, self).__init__(data_grid, table_column_names, display_options,
                                                     proportions, table_title)

        self._filter_selector = None

    def __build_filter_selector(self):
        """ Creates SelectBox for filtering data in table
        """

        filters = self._data_grid.get_filters()
        filter_names = list()
        filter_names.extend(filters.keys())

        select_box = SelectBox(filter_names, select_item_handler=self.get_filter_selected_handler(),
                               title="Select filter", )

        self._filter_selector = select_box

    def get_filter_selected_handler(self):
        """ Returns filter_selected_handler
        """

        def filter_selected_handler(selected_item_label):
            """ Handler for selected item in SelectBox with filters
            """

            indexes = self._data_grid.get_indexes_of_filtered_data(selected_item_label)
            self.display_lines(indexes)

        return filter_selected_handler

    def _build_table(self):
        """ Builds table widgets with UrwidWidgetBuilder
        """

        if self._table_header_line is None:
            self._build_table_header_line()

        if self._filter_selector is None:
            self.__build_filter_selector()

        self.builder \
            .add_widget(self._filter_selector) \
            .add_divider() \
            .add_widget(self._table_header_line) \
            .add_divider("=")

        table_lines = self._build_table_lines()
        self._sorted_table_lines_indexes = self._data_grid.get_line_indexes()
        self._table_lines = dict(zip(self._sorted_table_lines_indexes, table_lines))

        table_widgets = list()
        for table_line_index in self._sorted_table_lines_indexes:
            table_widgets.append(self._table_lines[table_line_index])
            table_widgets.append(urwid.Divider("-"))

        self._table_widgets = urwid.Pile(table_widgets)
        self.builder.add_widget(self._table_widgets)
        self.builder.create_line_box_for_previous_elements(title=self._table_title)
