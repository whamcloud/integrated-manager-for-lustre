# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" UrwidDataGrid realization
"""

from scalers.errors import ScalersInternalError


class UrwidDataGrid(object):
    """ Class to contain data
        UrwidDataGrid can be initialize by names of columns and list of lists or
        indexing dict like this:
        {
            1: ["item1", "item2"],
            3: ["item5", "item6"],
            6: ["item11", "item12"],
        }
    """

    def __init__(self, data, names):
        """ Data grid initialization
        """

        self._names = names
        self._listeners = list()

        self._index_data = data if type(data) == dict else {index: line for index, line in enumerate(data)}

        first_line = self._index_data.values()[0]
        if len(first_line) != len(names):
            raise ScalersInternalError("Number of names not equals with number of data columns ({0} != {1})"
                                       .format(len(first_line), len(names)))

        # Need for iteration by grid
        self._iter_index = 0

        self._sorted_indexes = self._index_data.keys()
        self._sorted_indexes.sort()

    def get_subgrid_by_indexes_of_lines(self, indexes_of_lines, copy_listeners=False):
        """ Create UrwidDataGrid by indexes from list 'indexes_of_lines'
        """

        data = {key: self._index_data[key] for key in indexes_of_lines}
        grid = UrwidDataGrid(data, self._names)

        if copy_listeners and self._listeners:
            for listener in self._listeners:
                grid.add_listener(listener)

        return grid

    def get_line_indexes(self):
        """ Returns indexes that contains in this grid
        """

        return self._sorted_indexes

    def add_listener(self, event_function):
        """ Add listener

            Listener function will call, when new item will set in
            grid with __setitem__

            Event_handler that listens grid changing event:
            def event_handler(number_of_line, grid_column_name, new_value)

        """

        if not callable(event_function):
            raise AttributeError("event_function should be a callable object")

        self._listeners.append(event_function)

    def clear_listeners(self):
        """ Clear list with listeners
        """

        self._listeners = list()

    def get_column_names(self):
        """ Returns grid column names
        """

        return self._names[:]

    def get_original_data(self):
        """ Returns grid data (list of lists)
        """

        return [self._index_data[index] for index in self._sorted_indexes]

    def get_indexing_data(self):
        """ Returns index data
        """

        return self._index_data

    def get_position_index_by_line_number(self, index):
        """ Returns position index of list, which contains lines that exist in the grid
        """

        return self._sorted_indexes.index(index)

    def set_item_without_callback(self, key, value):
        """ Set data into cell without callback
            Key is tuple (number_of_line, number_of_column)
        """

        number_of_line, number_of_column = key
        self._index_data[number_of_line][number_of_column] = value

    def add_line(self, index, line):
        """ Add new line into data
        """

        if index in self._index_data:
            raise ScalersInternalError("Index already exists")

        self._index_data[index] = line

    def update_grid(self, data_grid, with_callback=True):
        """ Update the grid with the key/value pairs from other, overwriting existing keys
        """

        for line_index, new_line in data_grid:

            current_line = self._index_data.get(line_index)
            if current_line is None:
                self.add_line(line_index, new_line)
                continue

            for cell_index, cell in enumerate(new_line):

                if current_line[cell_index] != new_line[cell_index]:
                    setter_function = self.__setitem__ if with_callback else self.set_item_without_callback
                    setter_function((line_index, cell_index), cell)

    def __iter__(self):
        """ Returns iterable object
        """

        self._iter_index = 0
        return self

    def __len__(self):
        """ Returns number of elements in the grid
        """

        return len(self._index_data)

    def next(self):
        """ Returns tuple that contain (line_number, line_content)
        """

        if self._iter_index >= len(self._sorted_indexes):
            raise StopIteration
        else:
            grid_index = self._sorted_indexes[self._iter_index]
            return_value = (grid_index, self._index_data[grid_index], )
            self._iter_index += 1
            return return_value

    def __getitem__(self, item):
        """
            Return line of cells If item is int
            Return cell If item is tuple (x, y)
        """

        if type(item) == int:
            return self._index_data[item]
        else:
            x, y = item
            line = self._index_data[x]
            return line[y]

    def __setitem__(self, key, new_value):
        """ Set data into cell
            Key is tuple (number_of_line, number_of_column)
        """

        number_of_line, number_of_column = key
        self._index_data[number_of_line][number_of_column] = new_value
        for event_function in self._listeners:
            grid_column_name = self._names[number_of_column]
            event_function(number_of_line, grid_column_name, new_value)
