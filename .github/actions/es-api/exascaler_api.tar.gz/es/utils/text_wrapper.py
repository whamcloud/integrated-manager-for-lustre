# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************


class TextWrapper(object):
    """ Class for modifying output text style.
    """

    PINK = '\033[95m'
    BLUE = '\033[94m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    ENDC = '\033[0m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'

    def __init__(self, text):
        """ Base initialization.
        """

        self._text = text
        self._color = None
        self._is_bold = False
        self._is_header = False
        self._is_underline = False

    def set_red_color(self):
        """ Set red text color.
        """

        self._color = self.RED
        return self

    def set_blue_color(self):
        """ Set blue text color.
        """

        self._color = self.BLUE
        return self

    def set_green_color(self):
        """ Set green text color.
        """

        self._color = self.GREEN
        return self

    def set_yellow_color(self):
        """ Set yellow text color.
        """

        self._color = self.YELLOW
        return self

    def set_pink_color(self):
        """ Set pink text color.
        """

        self._color = self.PINK
        return self

    def set_underline(self):
        """ Enable text underline style.
        """

        self._is_underline = True
        return self

    def set_bold(self):
        """ Enable text bold style.
        """

        self._is_bold = True
        return self

    def build(self):
        """ Return wrapped string.
        """

        output_str = ''

        if self._is_underline:
            output_str += self.UNDERLINE

        if self._is_bold:
            output_str += self.BOLD

        if self._color is not None:
            output_str += self._color

        output_str += self._text
        output_str += self.ENDC

        return output_str


def success_style(text):
    """ Text wrapper for success messages.
    """

    return TextWrapper(text).set_green_color().build()


def warning_style(text):
    """ Text wrapper for warning messages.
    """

    return TextWrapper(text).set_yellow_color().build()


def error_style(text):
    """ Text wrapper for error messages.
    """

    return TextWrapper(text).set_red_color().build()
