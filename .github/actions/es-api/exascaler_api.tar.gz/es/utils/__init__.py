# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Utilities for EXAScaler API package.
"""

import socket
import os
import time

from scalers.utils.command import StringCommand, CommandExecutor
from scalers.utils.cmd import CmdExecutor
from scalers.errors import ScalersException


def get_hostname():
    """ Get current hostname.
    """

    return socket.gethostname()


def rename_backup(filename):
    """ Rename backup.
    """

    if os.path.exists(filename):
        buf = os.stat(filename)
        ts = buf.st_mtime
        time_fmt = '%Y_%b_%e_%R'
        time_str = time.strftime(time_fmt, time.gmtime(ts))
        os.rename(filename, filename + '-' + time_str)


def get_file_content(filename):
    """ Get file content.
    """

    with open(filename, 'r') as f:
        return f.read()


def load_module(module, ensure_success=True, dry_run=False):
    """ Check if a kernel module is loaded and load it if it isn't.
    """

    if not os.path.exists(os.path.join('/sys', 'module', module)):
        cmd = 'modprobe {0}'.format(module)
        if dry_run:
            print cmd
        else:
            executor = CmdExecutor(StringCommand(cmd))
            executor.timeout(60)
            executor.execute(ensure_success=ensure_success)


def get_oid():
    """ Get OID.
    """

    result = CommandExecutor('sfactrl i').run()
    if result.exit_code != 0:
        return
    cmd_out = result.stdout
    sfactl_oid = cmd_out.split('\n')[0].rsplit('My Stack OID = ')[1]
    return sfactl_oid


def relative_path(path, start=os.path.curdir):
    """ Get a relative version of a path.
    """

    start_list = os.path.abspath(start).split(os.path.sep)
    path_list = os.path.abspath(path).split(os.path.sep)
    i = len(os.path.commonprefix([start_list, path_list]))
    rel_list = [os.path.pardir] * (len(start_list) - i) + path_list[i:]
    if not rel_list:
        return os.path.curdir
    return os.path.join(*rel_list)


def makedirs(path):
    """ Try to create dir.
    """

    if not os.path.exists(path):
        try:
            os.makedirs(path)
        except OSError:
            pass

    if not os.path.exists(path):
        raise ScalersException('Unable to create path: {0}'.format(path))


def write_file(fname, contents):
    """Write contents to file (binary mode)

    :param fname: path to file
    :param contents: contents to be written
    :raise IOError
    """

    with open(fname, 'wb') as fobj:
        fobj.write(contents)


def is_embedded():
    """ Check id current system is embedded.
    """

    return 'SKU' in CmdExecutor(StringCommand('dmidecode')).execute()
