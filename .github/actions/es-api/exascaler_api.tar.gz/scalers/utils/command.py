# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Classes for commands execution.
"""

import shlex
import threading
import os

from subprocess import Popen, PIPE, list2cmdline
from scalers.errors import ScalersCommandError


class CommandResult(object):
    """ Command execution result.
    """

    def __init__(self, cmd, exit_code=None, stdout=None, stderr=None):
        """ Basic initialization.
        """

        self.cmd = cmd
        self.exit_code = exit_code
        self.stdout = stdout
        self.stderr = stderr

    def __str__(self):
        """ String representation.
        """

        lines = ['Command: {0}'.format(self.cmd), ]

        if self.exit_code is not None:
            lines.append('Exit code: {0}'.format(self.exit_code))
        if self.stdout:
            lines.append('Stdout: {0}'.format(self.stdout.rstrip()))
        if self.stderr:
            lines.append('Stderr:  {0}'.format(self.stderr.rstrip()))

        return '\n'.join(lines)


class Command(object):
    """ Class for command object.
    """

    def __init__(self, cmd):
        """ Basic initialization.
        """
        self.cmd = cmd

    def to_string(self, args=None):
        """ Return command as string.
        """

        if isinstance(self.cmd, str):
            return self.cmd

        return list2cmdline(self.cmd)

    def to_list(self, args=None):
        """ Return command as list.
        """

        if not isinstance(self.cmd, str):
            return self.cmd

        return shlex.split(self.cmd)


class StringCommand(Command):
    """ Class for command object, where command is string.
    """

    def to_string(self, args=None):
        """ Return command as string.
        """

        if args is not None:
            return self.cmd % args

        return self.cmd

    def to_list(self, args=None):
        """ Return command as list.
        """

        string = self.to_string(args)
        return shlex.split(string)


def _merge_environment_variables(env):
    """Merge environment variables into one dict()

    If env provided is None, return None

    :param env: dict() of env variables or None
    :return: dict() of environment variable or None
    """

    if env:

        env_dict = dict(os.environ)
        env_dict.update(env)

        return env_dict

    return None


class CommandExecutor(object):
    """ Executor for commands.
    """

    def __init__(self, cmd, input_data=None):
        """ Basic initialization.
        """

        self.cmd = cmd if isinstance(cmd, Command) else Command(cmd)
        self.input_data = input_data
        self._wait = True
        self._timeout = 0
        self._process = None
        self._output = None

    def timeout(self, seconds=10):
        """
        Setup a timeout for execute cmd
        :param seconds:
        :return: self
        """
        self._timeout = seconds
        return self

    def wait(self, status=True):
        """
        Wait for child process to terminate
        :param status: True | False
        :return: self
        """
        self._wait = status
        return self

    def run(self, node=None, args=None, out=PIPE, err=PIPE, env=None,
            shell=False, interactive=False, ssh_user=None, log_file=None):
        def target():
            cmd, cmd_string = self._get_command(node, ssh_user, args)
            sp_env = _merge_environment_variables(env)

            cmd = cmd_string if shell else cmd
            stdin = PIPE if self.input_data else None

            try:
                self._process = Popen(cmd, stdout=out, stderr=err,
                                      stdin=stdin, env=sp_env, shell=shell, close_fds=True)
            except OSError as e:
                msg = '{0} (errno: {1})'.format(e.args[1], e.args[0])
                result = CommandResult(cmd_string)
                raise ScalersCommandError(msg, result)

            if self._wait:
                if not interactive:
                    std_out, std_err = self._process.communicate(self.input_data)
                    exit_code = self._process.poll()

                    self._output = CommandResult(cmd_string, exit_code, std_out,
                                                 std_err)
                else:
                    if log_file is not None:
                        with open(log_file, 'w+b') as log:
                            stdout = list()
                            while self._process.poll() is None:
                                line = self._process.stdout.readline()
                                if line.rstrip():
                                    stdout.append(line)
                                    log.write(line)
                    else:
                        stdout = list()
                        while self._process.poll() is None:
                            line = self._process.stdout.readline()
                            if line.rstrip():
                                stdout.append(line)
                                print line.rstrip()
                    exit_code = self._process.returncode
                    std_err = self._process.communicate()[1]
                    self._output = CommandResult(cmd_string, exit_code, ''.join(stdout), std_err)
            else:
                self.wait()

            return self._output

        if self._timeout:
            response = self._run_target(target, self._timeout)
            self._timeout = 0
        else:
            response = target()

        return response

    def _run_target(self, target, timeout):
        """
        Runs a command with timeout
        :param target:
        :param timeout:
        :return: CommandResult object
        """
        thread = threading.Thread(target=target)
        thread.start()
        thread.join(timeout)

        if thread.is_alive():
            self._process.terminate()
            thread.join()
            cmd = self.cmd.to_string()
            self._output = CommandResult(
                cmd, self._process.returncode, '',
                '"{0}" command timeout exceeded {1} second(s)'.format(cmd,
                                                                      timeout)
            )

        return self._output

    def _get_command(self, ssh_host=None, ssh_user=None, args=None):
        """ Wrap command into ssh call if ssh_host specified
        """

        if ssh_host is None:
            return self.cmd.to_list(args), self.cmd.to_string(args)

        cmd_list = ['ssh', ssh_host, '-o', 'PasswordAuthentication=no', ]

        if ssh_user is not None:
            cmd_list.extend(['-l', ssh_user, ])

        cmd_list.append(self.cmd.to_string(args))

        cmd_string = list2cmdline(cmd_list)

        return cmd_list, cmd_string
