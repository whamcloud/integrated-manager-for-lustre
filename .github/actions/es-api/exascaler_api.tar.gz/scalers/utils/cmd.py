# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Classes for commands execution and parsing.
"""
import re
import os

from scalers.errors import ScalersCommandParseError, ScalersCommandError
from scalers.utils.command import CommandExecutor


class CmdOutputParser(object):
    """ Base class for command output parser.
    """

    def __init__(self, cmd, args=None):
        """ Basic initialization.
        :param cmd: command as string
        :param args: command named args
        """

        self.cmd = cmd
        self.cmd_args = args
        self.re_empty = re.compile(r'^\s*$')
        self.output = None

    def parse_output(self, output):
        """ Parse command output.
        """

        self.output = output

        return self._parse(self.output)

    def _parse(self, output):
        """ Parse command output.
        """

        return output

    def get_parse_error(self, msg):
        """ Return ScalersCommandParseError instance.
        """

        raise ScalersCommandParseError(self.cmd, self.output, msg)

    def remove_header(self, output, re_splitter):
        """Remove header from command output

        :param output: command output as string
        :param re_splitter: regex object as header splitter
        :return: string (output without header)
        :raises ScalersCommandParseError for incorrect output
        """

        lines = output.split("\n")
        for i, line in enumerate(lines):
            if re_splitter.match(line):
                return "\n".join(lines[i + 1:])

        raise self.get_parse_error("Unable to remove header")


class CmdExecutor(CommandExecutor):
    """ Base command executor.
    Example:
        executor = CmdExecutor(...)
        executor.execute*(...)
    To execute particular command with timeout:
        executor.timeout(300).execute*(...)
    """

    def __init__(self, cmd, parser_cls=None, input_data=None):
        """ Basic initialization.
        """

        super(CmdExecutor, self).__init__(cmd, input_data)
        self.parser_cls = parser_cls

    def execute(self, node=None, ensure_success=True, args=None, env=None,
                shell=False, log_file=None, ssh_user=None):
        """
        Execute command
        """

        result = self.run(node, args, env=env, shell=shell, ssh_user=ssh_user)

        if log_file is not None:
            with open(log_file, 'a') as log:
                log.write(str(result))

        self.check_error(ensure_success, result)

        return self._parse(result, args)

    def execute_and_save_stdout_to_file(self, filename, node=None,
                                        ensure_success=True, args=None):
        """
        Execute command and save stdout to file.
        """
        with open(filename, 'w+b') as out:
            result = self.run(node, args, out=out)
            self.check_error(ensure_success, result)

    def execute_without_waiting(self, node=None, args=None):
        """
        Execute command without waiting result
        """
        with open(os.devnull, 'w') as devnull:
            self.wait(False).run(node, args, out=devnull, err=devnull,
                                 shell=True)

    def execute_interactive(self, node=None, ensure_success=True, args=None, env=None, shell=False, log_file=None):
        """ Execute command in interactive mode.
        """
        result = self.run(node, args, env=env, shell=shell, interactive=True, log_file=log_file)

        self.check_error(ensure_success, result)

        return self._parse(result, args)

    @staticmethod
    def check_error(ensure_success, result):
        if ensure_success and result.exit_code != 0:
            raise ScalersCommandError('Command failed', result)

    def _create_parser(self, cmd, args):
        """ Create parser instance.
        """
        return self.parser_cls(cmd, args)

    def _parse(self, result, args):
        """ Parse command output.
        """
        if self.parser_cls is None:
            return result.stdout

        parser = self._create_parser(result.cmd, args)
        return parser.parse_output(result.stdout)
