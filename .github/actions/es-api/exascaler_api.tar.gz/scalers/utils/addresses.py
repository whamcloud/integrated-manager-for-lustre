# -*- coding: utf-8 -*-

# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Classes for binary address parsing.
"""

import abc


class ByteAddress(object):  # pylint: disable=too-few-public-methods
    """ Abstract base class for any byte-represented addresses.
    """

    __metaclass__ = abc.ABCMeta
    __slots__ = ('composition', 'address')

    def __init__(self, address):
        self.composition = {}
        self.address = address
        self._decomposition()

    @abc.abstractmethod
    def _decomposition(self):
        """ Parse binary address distinguishing it's fields.
        """


class SasAddress(ByteAddress):  # pylint: disable=too-few-public-methods
    """ SAS address representation.
    """

    __slots__ = ('naa_address_format', 'addr_format', 'ieee_company_id',
                 'enclosure_type_id', 'rolling_number', 'expander_location')

    def __init__(self, address):
        """ :param address: '0x50001ff23440c77f'
        """

        super(SasAddress, self).__init__(address)
        self.naa_address_format = 'sas'

    def _decomposition(self):
        """ SAS address decomposition.
        """

        bits_reversed = bin(int(self.address, 16))[:1:-1]
        self.composition.update(
            bits_05_00=bits_reversed[5::-1],  # SATA drive ID / SSP / SMP
            bits_09_06=bits_reversed[9:5:-1],  # EXPander Location
            bits_11_10=bits_reversed[11:9:-1],  # Reserved for future use
            bits_27_12=bits_reversed[27:11:-1],  # 16-bit rolling number
            bits_35_28=bits_reversed[35:27:-1],  # Enclosure type identifier
            bits_59_36=bits_reversed[59:35:-1],  # IEEE Company ID
            bits_63_60=bits_reversed[63:59:-1],  # NAA address format - SAS
        )
        self.addr_format = self.bits_to_hex(self.composition['bits_63_60'])
        self.ieee_company_id = self.bits_to_hex(self.composition['bits_59_36'])
        self.enclosure_type_id = self.bits_to_hex(self.composition['bits_35_28'])
        self.rolling_number = self.bits_to_hex(self.composition['bits_27_12'])
        self.expander_location = self.composition['bits_09_06']

    @staticmethod
    def bits_to_hex(bits):
        """ Convert bin string to hex string.
        """

        return hex(int(bits, 2))[2:]
