# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Utils module.
"""

from functools import wraps as _wraps


def call_once(func):
    """ Cache the result of the callable.
    """

    @_wraps(func)
    def _wrapper(*args, **kwargs):
        result = getattr(func, '_result', None)
        if result is None:
            result = func._result = func(*args, **kwargs)
        return result

    return _wrapper


def get_value_from_file(file_path):
    """ Return the first line of the file stripped.
    """

    with open(file_path) as value_file:
        return value_file.readline().strip()
