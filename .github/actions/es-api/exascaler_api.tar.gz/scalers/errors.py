# ******************************************************************************
#
#                                --- WARNING ---
#
#   This work contains trade secrets of DataDirect Networks, Inc.  Any
#   unauthorized use or disclosure of the work, or any part thereof, is
#   strictly prohibited.  Copyright in this work is the property of DataDirect.
#   Networks, Inc. All Rights Reserved. In the event of publication, the.
#   following notice shall apply: (C) 2016, DataDirect Networks, Inc.
#
# ******************************************************************************

""" Exception and errors for Scalers API.
"""


class ScalersBaseException(Exception):
    """ Base exception for scalers.
    """

    pass


class ScalersInternalError(ScalersBaseException):
    """ Exception for scalers internal errors.
    """

    def __init__(self, msg):
        """ Basic initialization.
        """

        ScalersBaseException.__init__(self, msg)

        self.msg = msg

    def __str__(self):
        """ String representation.
        """

        return 'Internal error occurred: {0}'.format(self.msg)


class ScalersException(ScalersBaseException):
    """ Common exception for scalers.
    """

    def __init__(self, msg, *args):
        """ Basic initialization.
        """

        ScalersBaseException.__init__(self, msg, *args)

        self.msg = msg
        self.args = args

    def __str__(self):
        """ String representation.
        """

        if self.args:
            return 'Error occurred: {0}\n{1}'.format(self.msg, self.args)
        else:
            return 'Error occurred: {0}'.format(self.msg)


class ScalersCommandError(ScalersException):
    """ Exception for scalers commands execution errors.
    """

    def __init__(self, msg, result):
        """ Basic initialization.
        """

        ScalersException.__init__(self, msg, result)

        self.result = result

    def __str__(self):
        """ String representation.
        """

        return 'Error occurred during command execution: {0}\n{1}'.format(self.msg, self.result)


class ScalersCommandParseError(ScalersException):
    """ Exception for scalers commands parsing errors.
    """

    def __init__(self, cmd, output, msg):
        """ Basic initialization.
        """

        ScalersException.__init__(self, msg, cmd, output)

        self.cmd = cmd
        self.output = output

    def __str__(self):
        """ String representation.
        """

        return "Error occurred during command '{0}' output parsing: {1}\nOutput:\n{2}".format(
            self.cmd, self.msg, self.output)


class ScalersVersionError(ScalersException):
    """ Exception for incorrect scalers versions.
    """

    def __init__(self, msg, descr):
        """ Basic initialization.
        """

        ScalersException.__init__(self, msg, descr)

        self.descr = descr

    def __str__(self):
        """ String representation.
        """

        return 'Error occurred: {0}\n{1}'.format(self.msg, self.descr)
