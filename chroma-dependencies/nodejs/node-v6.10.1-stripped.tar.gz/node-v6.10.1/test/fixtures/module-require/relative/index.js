exports.value = 42;
