JSON.parse(undefined);

