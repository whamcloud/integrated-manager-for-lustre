exports.dep1 = require('dep1');
exports.dep2 = exports.dep1.dep2;
