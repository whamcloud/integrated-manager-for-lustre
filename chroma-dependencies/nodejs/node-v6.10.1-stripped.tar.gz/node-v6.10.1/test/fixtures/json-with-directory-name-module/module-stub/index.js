module.exports = "hello from module-stub!"
