require('fs').readFile('/');  // throws EISDIR
