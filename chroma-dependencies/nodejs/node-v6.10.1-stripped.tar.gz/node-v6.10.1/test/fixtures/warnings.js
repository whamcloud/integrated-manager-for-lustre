'use strict';

process.emitWarning('a bad practice warning');
