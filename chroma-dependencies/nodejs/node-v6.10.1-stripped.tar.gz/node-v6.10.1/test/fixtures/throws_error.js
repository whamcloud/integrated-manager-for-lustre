throw new Error('blah');
