var foo = 'bar';
