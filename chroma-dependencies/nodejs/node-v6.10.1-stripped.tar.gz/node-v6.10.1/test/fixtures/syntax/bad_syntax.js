var foo bar;
