exports.file6 = 'file6/index.js';
