exports.file2 = 'file2.js';
