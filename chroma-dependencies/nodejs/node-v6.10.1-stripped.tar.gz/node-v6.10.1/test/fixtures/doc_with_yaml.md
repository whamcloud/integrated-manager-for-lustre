# Sample Markdown with YAML info

## Foobar
<!-- YAML
added: v1.0.0
-->

Describe `Foobar` in more detail here.

## Foobar II
<!-- YAML
added:
  - v5.3.0
  - v4.2.0
-->

Describe `Foobar II` in more detail here.

## Deprecated thingy
<!-- YAML
added: v1.0.0
deprecated: v2.0.0
-->

Describe `Deprecated thingy` in more detail here.

## Something
<!-- This is not a metadata comment -->

Describe `Something` in more detail here.
