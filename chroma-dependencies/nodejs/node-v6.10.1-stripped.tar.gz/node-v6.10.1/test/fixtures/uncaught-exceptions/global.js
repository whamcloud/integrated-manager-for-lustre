console.log('going to throw an error');
throw new Error('global');
