console.log('parse error on next line');
var a = ';
