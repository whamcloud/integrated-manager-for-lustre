console.log('require fails on next line');
require('./parse-error-mod.js');
