@include doc_inc_1
@include doc_inc_2.md
