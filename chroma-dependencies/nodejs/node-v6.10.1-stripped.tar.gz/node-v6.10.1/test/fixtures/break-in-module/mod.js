exports.hello = function() {
  return 'hello from module';
};
