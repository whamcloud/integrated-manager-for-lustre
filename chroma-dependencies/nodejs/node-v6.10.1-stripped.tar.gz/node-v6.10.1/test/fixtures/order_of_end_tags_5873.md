# Title

## Subsection

### Class Method: Buffer.from(array)
* `array` {Array}
