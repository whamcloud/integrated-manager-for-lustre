
process.send('hello');
process.exit(0);
