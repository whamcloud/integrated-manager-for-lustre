/* eslint-disable required-modules */
'use strict';

Object.prototype.xadsadsdasasdxx = function() {
};

console.log('puts after');
